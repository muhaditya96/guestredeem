<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';

use PDO;
use PDOException;

$errors = [];
$successMessage = null;
$createdVoucher = null;
$bulkReport = [
    'inserted' => [],
    'skipped' => [],
];

function generateVoucherCode(PDO $pdo): string
{
    $stmt = $pdo->query("SELECT voucher_code FROM users WHERE voucher_code REGEXP '^tds[0-9]{4}$' ORDER BY voucher_code DESC LIMIT 1");
    $lastCode = $stmt->fetchColumn();
    $counter = 0;

    if (is_string($lastCode) && strlen($lastCode) >= 7) {
        $counter = (int) substr(strtolower($lastCode), 3);
    }

    $counter++;
    return 'tds' . str_pad((string) $counter, 4, '0', STR_PAD_LEFT);
}

$bulkData = isset($_POST['bulk_data']) ? trim((string) $_POST['bulk_data']) : '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($bulkData !== '') {
        try {
            $pdo = getDbConnection();
            $lines = preg_split('/\r\n|\r|\n/', $bulkData);
            $insertCount = 0;

            foreach ($lines as $index => $line) {
                $line = trim($line);
                if ($line === '') {
                    continue;
                }

                $parts = preg_split('/\t+|\|+/', $line);
                $parts = array_values(array_filter(array_map('trim', $parts), static fn ($value) => $value !== ''));

                if (count($parts) < 2) {
                    $bulkReport['skipped'][] = "Baris " . ($index + 1) . ': format minimal Nama | Cabang.';
                    continue;
                }

                $idValue = null;
                $name = '';
                $branch = '';

                $noHp = '';
                if (count($parts) >= 3 && ctype_digit($parts[0])) {
                    $idValue = (int) $parts[0];
                    $name = $parts[1];
                    $branch = $parts[2];
                    $noHp = isset($parts[3]) ? $parts[3] : '';
                } else {
                    $name = $parts[0];
                    $branch = $parts[1];
                    $noHp = isset($parts[2]) ? $parts[2] : '';
                }

                if ($name === '' || $branch === '') {
                    $bulkReport['skipped'][] = "Baris " . ($index + 1) . ': nama atau cabang kosong.';
                    continue;
                }

                if ($idValue !== null) {
                    if ($idValue <= 0) {
                        $bulkReport['skipped'][] = "Baris " . ($index + 1) . ': ID harus lebih dari 0.';
                        continue;
                    }
                    $check = $pdo->prepare('SELECT COUNT(*) FROM users WHERE id = :id LIMIT 1');
                    $check->execute([':id' => $idValue]);
                    if ((int) $check->fetchColumn() > 0) {
                        $bulkReport['skipped'][] = "Baris " . ($index + 1) . ': ID sudah dipakai.';
                        continue;
                    }
                }

                $voucherCode = generateVoucherCode($pdo);

                if ($idValue === null) {
                    $stmt = $pdo->prepare('INSERT INTO users (name, branch, attendance_status, voucher_code, no_hp) VALUES (:name, :branch, "belum hadir", :voucher, :no_hp)');
                    $stmt->execute([
                        ':name' => $name,
                        ':branch' => $branch,
                        ':voucher' => $voucherCode,
                        ':no_hp' => $noHp ?: null,
                    ]);
                    $newId = (int) $pdo->lastInsertId();
                } else {
                    $stmt = $pdo->prepare('INSERT INTO users (id, name, branch, attendance_status, voucher_code, no_hp) VALUES (:id, :name, :branch, "belum hadir", :voucher, :no_hp)');
                    $stmt->execute([
                        ':id' => $idValue,
                        ':name' => $name,
                        ':branch' => $branch,
                        ':voucher' => $voucherCode,
                        ':no_hp' => $noHp ?: null,
                    ]);
                    $newId = $idValue;
                }

                // Insert ke tabel vouchers
                $voucherStmt = $pdo->prepare('INSERT INTO vouchers (code, value, owner_user_id, status) VALUES (:code, :value, :owner_id, "unused")');
                $voucherStmt->execute([
                    ':code' => $voucherCode,
                    ':value' => 70000,
                    ':owner_id' => $newId,
                ]);

                $insertCount++;
                $bulkReport['inserted'][] = sprintf('%s (ID #%d, voucher %s)', $name, $newId, $voucherCode);
            }

            if ($insertCount > 0) {
                $successMessage = sprintf('Berhasil menambahkan %d tamu dari textarea.', $insertCount);
                $createdVoucher = null;
                $_POST['bulk_data'] = '';
            } else {
                $errors[] = 'Tidak ada baris valid yang ditambahkan dari textarea.';
            }
        } catch (PDOException $exception) {
            $errors[] = 'Gagal memproses data: ' . $exception->getMessage();
        }
    } else {
        $manualIds = isset($_POST['manual_id']) && is_array($_POST['manual_id']) ? $_POST['manual_id'] : [];
        $manualNames = isset($_POST['manual_name']) && is_array($_POST['manual_name']) ? $_POST['manual_name'] : [];
        $manualBranches = isset($_POST['manual_branch']) && is_array($_POST['manual_branch']) ? $_POST['manual_branch'] : [];
        $manualNoHps = isset($_POST['manual_no_hp']) && is_array($_POST['manual_no_hp']) ? $_POST['manual_no_hp'] : [];

        $totalRows = max(count($manualIds), count($manualNames), count($manualBranches), count($manualNoHps));

        if ($totalRows === 0) {
            $errors[] = 'Isi minimal satu baris manual atau gunakan textarea.';
        } else {
            try {
                $pdo = getDbConnection();
                $insertCount = 0;

                for ($i = 0; $i < $totalRows; $i++) {
                    $idRaw = isset($manualIds[$i]) ? trim((string) $manualIds[$i]) : '';
                    $name = isset($manualNames[$i]) ? trim((string) $manualNames[$i]) : '';
                    $branch = isset($manualBranches[$i]) ? trim((string) $manualBranches[$i]) : '';
                    $noHp = isset($manualNoHps[$i]) ? trim((string) $manualNoHps[$i]) : '';

                    if ($name === '' && $branch === '' && $idRaw === '' && $noHp === '') {
                        continue;
                    }

                    if ($name === '' || $branch === '') {
                        $errors[] = sprintf('Baris %d: nama dan cabang wajib diisi.', $i + 1);
                        continue;
                    }

                    $userId = null;
                    if ($idRaw !== '') {
                        if (!ctype_digit($idRaw) || (int) $idRaw <= 0) {
                            $errors[] = sprintf('Baris %d: ID harus angka positif.', $i + 1);
                            continue;
                        }
                        $userId = (int) $idRaw;
                        $check = $pdo->prepare('SELECT COUNT(*) FROM users WHERE id = :id LIMIT 1');
                        $check->execute([':id' => $userId]);
                        if ((int) $check->fetchColumn() > 0) {
                            $errors[] = sprintf('Baris %d: ID sudah dipakai.', $i + 1);
                            continue;
                        }
                    }

                    $voucherCode = generateVoucherCode($pdo);

                    if ($userId === null) {
                        $stmt = $pdo->prepare('INSERT INTO users (name, branch, attendance_status, voucher_code, no_hp) VALUES (:name, :branch, "belum hadir", :voucher, :no_hp)');
                        $stmt->execute([
                            ':name' => $name,
                            ':branch' => $branch,
                            ':voucher' => $voucherCode,
                            ':no_hp' => $noHp ?: null,
                        ]);
                        $newId = (int) $pdo->lastInsertId();
                    } else {
                        $stmt = $pdo->prepare('INSERT INTO users (id, name, branch, attendance_status, voucher_code, no_hp) VALUES (:id, :name, :branch, "belum hadir", :voucher, :no_hp)');
                        $stmt->execute([
                            ':id' => $userId,
                            ':name' => $name,
                            ':branch' => $branch,
                            ':voucher' => $voucherCode,
                            ':no_hp' => $noHp ?: null,
                        ]);
                        $newId = $userId;
                    }

                    // Insert ke tabel vouchers
                    $voucherStmt = $pdo->prepare('INSERT INTO vouchers (code, value, owner_user_id, status) VALUES (:code, :value, :owner_id, "unused")');
                    $voucherStmt->execute([
                        ':code' => $voucherCode,
                        ':value' => 70000,
                        ':owner_id' => $newId,
                    ]);

                    $insertCount++;
                    $bulkReport['inserted'][] = sprintf('%s (ID #%d, voucher %s)', $name, $newId, $voucherCode);
                }

                if ($insertCount > 0) {
                    $successMessage = sprintf('Berhasil menambahkan %d tamu manual.', $insertCount);
                    $createdVoucher = null;
                    $_POST['manual_id'] = [];
                    $_POST['manual_name'] = [];
                    $_POST['manual_branch'] = [];
                    $_POST['manual_no_hp'] = [];
                } elseif (empty($errors)) {
                    $errors[] = 'Tidak ada baris valid pada form manual.';
                }
            } catch (PDOException $exception) {
                $errors[] = 'Gagal menyimpan data: ' . $exception->getMessage();
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Tambah Tamu Baru</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="page narrow">
        <header class="hero hero-compact">
            <div>
                <p class="eyebrow">New Guest</p>
                <h1>Tambah Tamu Secara Manual</h1>
                <p class="subtitle">
                    Isi data nama dan cabang. Voucher akan dibuat otomatis dengan format tds0001, tds0002, dan seterusnya.
                </p>
            </div>
            <div class="hero-card">
                <p>Status</p>
                <strong>Form</strong>
                <small>Tambah sekali klik</small>
            </div>
        </header>

        <section class="form-card">
            <?php if (!empty($errors)) : ?>
                <?php foreach ($errors as $error) : ?>
                    <div class="feedback error"><?= htmlspecialchars($error) ?></div>
                <?php endforeach; ?>
            <?php endif; ?>

            <?php if ($successMessage !== null) : ?>
                <div class="feedback success">
                    <strong><?= htmlspecialchars($successMessage) ?></strong>
                    <?php if ($createdVoucher !== null) : ?>
                        <div>Voucher tamu: <code><?= htmlspecialchars($createdVoucher) ?></code></div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <?php if (!empty($bulkReport['inserted']) || !empty($bulkReport['skipped'])) : ?>
                <div class="bulk-report">
                    <?php if (!empty($bulkReport['inserted'])) : ?>
                        <h4>Berhasil</h4>
                        <ul>
                            <?php foreach ($bulkReport['inserted'] as $item) : ?>
                                <li><?= htmlspecialchars($item) ?></li>
                            <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>
                    <?php if (!empty($bulkReport['skipped'])) : ?>
                        <h4>Dilewati</h4>
                        <ul>
                            <?php foreach ($bulkReport['skipped'] as $item) : ?>
                                <li><?= htmlspecialchars($item) ?></li>
                            <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <form method="post" class="form-grid" id="manualForm">
                <div class="form-group">
                    <label for="bulk_data">Paste dari Excel (opsional)</label>
                    <textarea
                        id="bulk_data"
                        name="bulk_data"
                        class="form-control textarea-control"
                        placeholder="Contoh format:&#10;Andi Pratama|Jakarta|081234567890&#10;101|Bunga Lestari|Bandung|081987654321"
                    ><?= isset($_POST['bulk_data']) ? htmlspecialchars($_POST['bulk_data']) : '' ?></textarea>
                    <small>Gunakan pemisah tab atau karakter <code>|</code>. Format: Nama|Cabang|No HP atau ID|Nama|Cabang|No HP. No HP opsional. Jika textarea diisi, data di bawah akan diabaikan.</small>
                </div>

                <div class="form-divider">
                    <span>atau isi manual</span>
                </div>

                <div class="manual-table" data-manual-table>
                    <div class="manual-header">
                        <span>ID Tamu</span>
                        <span>Nama</span>
                        <span>Cabang</span>
                        <span>No HP</span>
                        <span>Aksi</span>
                    </div>
                    <?php
                    $manualIdsPosted = isset($_POST['manual_id']) && is_array($_POST['manual_id']) ? $_POST['manual_id'] : [''];
                    $manualNamesPosted = isset($_POST['manual_name']) && is_array($_POST['manual_name']) ? $_POST['manual_name'] : [''];
                    $manualBranchesPosted = isset($_POST['manual_branch']) && is_array($_POST['manual_branch']) ? $_POST['manual_branch'] : [''];
                    $manualNoHpsPosted = isset($_POST['manual_no_hp']) && is_array($_POST['manual_no_hp']) ? $_POST['manual_no_hp'] : [''];
                    $rowCount = max(count($manualIdsPosted), count($manualNamesPosted), count($manualBranchesPosted), count($manualNoHpsPosted));
                    if ($rowCount === 0) {
                        $rowCount = 1;
                    }
                    for ($i = 0; $i < $rowCount; $i++) :
                        $manualIdValue = $manualIdsPosted[$i] ?? '';
                        $manualNameValue = $manualNamesPosted[$i] ?? '';
                        $manualBranchValue = $manualBranchesPosted[$i] ?? '';
                        $manualNoHpValue = $manualNoHpsPosted[$i] ?? '';
                    ?>
                        <div class="manual-row" data-manual-row>
                            <input type="number" min="1" class="form-control" name="manual_id[]" placeholder="Opsional" value="<?= htmlspecialchars($manualIdValue) ?>">
                            <input type="text" class="form-control" name="manual_name[]" placeholder="Nama tamu" value="<?= htmlspecialchars($manualNameValue) ?>">
                            <input type="text" class="form-control" name="manual_branch[]" placeholder="Cabang" value="<?= htmlspecialchars($manualBranchValue) ?>">
                            <input type="text" class="form-control" name="manual_no_hp[]" placeholder="No HP (opsional)" value="<?= htmlspecialchars($manualNoHpValue) ?>">
                            <div class="manual-actions">
                                <button type="button" class="remove-row" onclick="removeManualRow(this)">Hapus</button>
                            </div>
                        </div>
                    <?php endfor; ?>
                </div>
                <button class="btn btn-secondary add-row-btn" type="button" onclick="addManualRow()">Tambah Baris</button>

                <div class="form-actions">
                    <a class="btn btn-secondary" href="index.php">Kembali</a>
                    <button class="btn btn-primary" type="submit">Simpan Tamu</button>
                </div>
            </form>
        </section>
    </div>
    <template id="manualRowTemplate">
        <div class="manual-row" data-manual-row>
            <input type="number" min="1" class="form-control" name="manual_id[]" placeholder="Opsional">
            <input type="text" class="form-control" name="manual_name[]" placeholder="Nama tamu">
            <input type="text" class="form-control" name="manual_branch[]" placeholder="Cabang">
            <input type="text" class="form-control" name="manual_no_hp[]" placeholder="No HP (opsional)">
            <div class="manual-actions">
                <button type="button" class="remove-row" onclick="removeManualRow(this)">Hapus</button>
            </div>
        </div>
    </template>
    <button class="fab" id="fabButton" type="button">+</button>
    <div class="fab-menu" id="fabMenu">
        <a class="fab-item dashboard" href="index.php" title="Dashboard">🏠</a>
        <a class="fab-item new-guest" href="new_guest.php" title="New Guest">➕</a>
        <a class="fab-item products" href="new_product.php" title="New Product">🛍️</a>
    </div>
    <script>
        (function () {
            var fabButton = document.getElementById('fabButton');
            var fabMenu = document.getElementById('fabMenu');

            var toggleMenu = function () {
                if (!fabMenu || !fabButton) {
                    return;
                }
                fabMenu.classList.toggle('open');
                fabButton.classList.toggle('open');
            };

            if (fabButton) {
                fabButton.addEventListener('click', toggleMenu);
            }
        })();
        function addManualRow() {
            var template = document.getElementById('manualRowTemplate');
            var table = document.querySelector('[data-manual-table]');
            if (!template || !table) {
                return;
            }
            var clone = template.content.cloneNode(true);
            table.appendChild(clone);
        }

        function removeManualRow(button) {
            var rows = document.querySelectorAll('[data-manual-row]');
            if (rows.length <= 1) {
                Array.prototype.forEach.call(button.closest('[data-manual-row]').querySelectorAll('input'), function (input) {
                    input.value = '';
                });
                return;
            }
            var row = button.closest('[data-manual-row]');
            if (row) {
                row.remove();
            }
        }
    </script>
</body>
</html>

