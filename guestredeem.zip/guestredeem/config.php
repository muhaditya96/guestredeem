<?php
declare(strict_types=1);

/**
 * Konfigurasi koneksi database.
 * Sesuaikan kredensial di bawah ini dengan pengaturan MySQL lokal Anda.
 */
const DB_HOST = '127.0.0.1';
const DB_NAME = 'guestredeem';
const DB_USER = 'root';
const DB_PASS = '';

/**
 * Mengembalikan instance PDO tunggal untuk seluruh aplikasi.
 */
function getDbConnection(): PDO
{
    static $pdo = null;

    if ($pdo === null) {
        $dsn = sprintf('mysql:host=%s;dbname=%s;charset=utf8mb4', DB_HOST, DB_NAME);
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);
    }

    return $pdo;
}

