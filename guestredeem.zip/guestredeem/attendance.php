<?php
declare(strict_types=1);

header('Content-Type: application/json');

require_once __DIR__ . '/config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Metode tidak diizinkan.']);
    exit;
}

$userId = isset($_POST['user_id']) ? (int) $_POST['user_id'] : 0;

if ($userId <= 0) {
    http_response_code(422);
    echo json_encode(['success' => false, 'message' => 'ID tamu tidak valid.']);
    exit;
}

try {
    $pdo = getDbConnection();
    $update = $pdo->prepare('UPDATE users SET attendance_status = "hadir", attendance_at = NOW() WHERE id = :id');
    $update->execute(['id' => $userId]);

    if ($update->rowCount() === 0) {
        echo json_encode(['success' => false, 'message' => 'Tamu tidak ditemukan atau sudah hadir.']);
        exit;
    }

    $query = $pdo->prepare('SELECT id, name FROM users WHERE id = :id');
    $query->execute(['id' => $userId]);
    $user = $query->fetch();

    echo json_encode([
        'success' => true,
        'message' => 'Kehadiran berhasil dicatat.',
        'user' => $user,
    ]);
} catch (PDOException $exception) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Terjadi kesalahan server: ' . $exception->getMessage()]);
}

