<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';

$transactions = [];
$groupedTransactions = [];
$dbError = null;
$search = isset($_GET['q']) ? trim($_GET['q']) : '';
$userId = isset($_GET['user_id']) ? (int) $_GET['user_id'] : 0;
$currentPage = 'transactions';

try {
    $pdo = getDbConnection();
    
    // Query untuk mengambil transaksi dengan join ke users dan products
    $sql = 'SELECT 
                t.id,
                t.user_id,
                t.product_id,
                t.variant_id,
                t.total_price,
                t.voucher_covered,
                t.extra_charge,
                t.notes,
                t.created_at,
                u.name as user_name,
                u.branch as user_branch,
                u.no_hp as user_no_hp,
                p.name as product_name,
                p.price as product_price,
                p.gambar as product_image,
                pv.variant_name,
                pv.price as variant_price
            FROM transactions t
            INNER JOIN users u ON t.user_id = u.id
            INNER JOIN products p ON t.product_id = p.id
            LEFT JOIN product_variants pv ON t.variant_id = pv.id';
    
    $params = [];
    $conditions = [];
    
    // Filter berdasarkan user_id jika ada
    if ($userId > 0) {
        $conditions[] = 't.user_id = :user_id';
        $params[':user_id'] = $userId;
    }
    
    // Filter berdasarkan search (nama user, produk, atau branch)
    if ($search !== '') {
        $conditions[] = '(u.name LIKE :search OR p.name LIKE :search OR u.branch LIKE :search OR CAST(t.id AS CHAR) LIKE :search)';
        $params[':search'] = '%' . $search . '%';
    }
    
    if (!empty($conditions)) {
        $sql .= ' WHERE ' . implode(' AND ', $conditions);
    }
    
    $sql .= ' ORDER BY t.created_at DESC';
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $transactions = $stmt->fetchAll();
    
    // Ambil voucher yang digunakan untuk setiap transaksi
    foreach ($transactions as &$transaction) {
        $voucherStmt = $pdo->prepare('
            SELECT v.code, v.value, tv.amount_applied
            FROM transaction_vouchers tv
            INNER JOIN vouchers v ON tv.voucher_id = v.id
            WHERE tv.transaction_id = :transaction_id
        ');
        $voucherStmt->execute([':transaction_id' => (int) $transaction['id']]);
        $transaction['vouchers'] = $voucherStmt->fetchAll();
    }
    unset($transaction);
    
    // Kelompokkan transaksi berdasarkan user_id
    $groupedTransactions = [];
    foreach ($transactions as $transaction) {
        $userId = (int) $transaction['user_id'];
        if (!isset($groupedTransactions[$userId])) {
            $groupedTransactions[$userId] = [
                'user_id' => $userId,
                'user_name' => $transaction['user_name'],
                'user_branch' => $transaction['user_branch'],
                'user_no_hp' => $transaction['user_no_hp'] ?? null,
                'transactions' => [],
                'total_transactions' => 0,
                'total_amount' => 0,
                'total_voucher' => 0,
                'total_extra' => 0,
            ];
        }
        $groupedTransactions[$userId]['transactions'][] = $transaction;
        $groupedTransactions[$userId]['total_transactions']++;
        $groupedTransactions[$userId]['total_amount'] += (int) $transaction['total_price'];
        $groupedTransactions[$userId]['total_voucher'] += (int) $transaction['voucher_covered'];
        $groupedTransactions[$userId]['total_extra'] += (int) $transaction['extra_charge'];
    }
    
    // Siapkan data statistik chart berdasarkan user yang memiliki transaksi
    $chartStats = [];
    foreach ($groupedTransactions as $group) {
        $chartStats[] = [
            'label' => $group['user_name'],
            'user_name' => $group['user_name'],
            'user_id' => $group['user_id'],
            'total_transactions' => (int) $group['total_transactions'],
            'total_amount' => (int) $group['total_amount'],
            'total_voucher_used' => (int) $group['total_voucher'],
            'total_extra_charge' => (int) $group['total_extra'],
            'has_transaction' => true,
        ];
    }
    
    // Urutkan berdasarkan total transaksi terbesar agar chart lebih informatif
    usort($chartStats, function (array $a, array $b): int {
        return $b['total_amount'] <=> $a['total_amount'];
    });
    
    // Hitung total keseluruhan
    $totalStats = [
        'total_users' => count($groupedTransactions),
        'total_vouchers_used' => 0,
        'total_extra_charge' => 0,
    ];
    
    foreach ($groupedTransactions as $group) {
        $totalStats['total_vouchers_used'] += $group['total_voucher'];
        $totalStats['total_extra_charge'] += $group['total_extra'];
    }
    
} catch (PDOException $exception) {
    $dbError = $exception->getMessage();
    $groupedTransactions = [];
    $chartStats = [];
    $totalStats = ['total_users' => 0, 'total_vouchers_used' => 0, 'total_extra_charge' => 0];
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Data Transaksi</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    <style>
        .transactions-page {
            max-width: 1400px;
            margin: 0 auto;
            padding: 2rem;
        }
        
        .transactions-header {
            background: linear-gradient(135deg, #1d4ed8, #3b82f6);
            color: #fff;
            padding: 2rem;
            border-radius: 1.25rem;
            margin-bottom: 2rem;
            box-shadow: 0 20px 45px rgba(3, 7, 18, 0.35);
        }
        
        .transactions-header h1 {
            margin: 0 0 0.5rem;
            font-size: 2rem;
        }
        
        .subnav {
            display: flex;
            gap: 0.75rem;
            margin: 0 auto 2rem;
            flex-wrap: wrap;
            max-width: 1400px;
            padding: 0 2rem;
        }
        
        .subnav-link {
            padding: 0.65rem 1.25rem;
            border-radius: 999px;
            background: #e2e8f0;
            color: #1e293b;
            font-weight: 600;
            text-decoration: none;
            transition: background 0.2s ease, color 0.2s ease;
        }
        
        .subnav-link:hover {
            background: #cbd5f5;
        }
        
        .subnav-link.active {
            background: #1d4ed8;
            color: #fff;
            box-shadow: 0 10px 20px rgba(30, 64, 175, 0.25);
        }
        
        .transaction-card {
            background: #fff;
            border-radius: 1rem;
            padding: 1.5rem;
            margin-bottom: 1rem;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }
        
        .transaction-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.15);
        }
        
        .transaction-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 1rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid var(--border, #e2e8f0);
        }
        
        .transaction-info {
            flex: 1;
        }
        
        .transaction-id {
            font-size: 0.875rem;
            color: var(--muted, #64748b);
            margin-bottom: 0.25rem;
        }
        
        .transaction-user {
            font-size: 1.1rem;
            font-weight: 600;
            margin-bottom: 0.25rem;
        }
        
        .transaction-branch {
            font-size: 0.9rem;
            color: var(--muted, #64748b);
        }
        
        .transaction-date {
            text-align: right;
            font-size: 0.875rem;
            color: var(--muted, #64748b);
        }
        
        .transaction-details {
            display: grid;
            grid-template-columns: auto 1fr;
            gap: 1rem;
            margin-bottom: 1rem;
        }
        
        .transaction-product-image {
            width: 80px;
            height: 80px;
            object-fit: cover;
            border-radius: 0.5rem;
            background: #f1f5f9;
        }
        
        .transaction-product-info {
            display: flex;
            flex-direction: column;
            justify-content: center;
        }
        
        .transaction-product-name {
            font-weight: 600;
            margin-bottom: 0.25rem;
        }
        
        .transaction-product-price {
            font-size: 0.9rem;
            color: var(--muted, #64748b);
        }
        
        .transaction-summary {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 1rem;
            padding: 1rem;
            background: #f8fafc;
            border-radius: 0.75rem;
            margin-top: 1rem;
        }
        
        .summary-item {
            display: flex;
            flex-direction: column;
        }
        
        .summary-label {
            font-size: 0.875rem;
            color: var(--muted, #64748b);
            margin-bottom: 0.25rem;
        }
        
        .summary-value {
            font-size: 1.1rem;
            font-weight: 600;
        }
        
        .summary-value.positive {
            color: var(--success, #10b981);
        }
        
        .summary-value.negative {
            color: var(--danger, #ef4444);
        }
        
        .voucher-list {
            margin-top: 0.5rem;
            padding-top: 0.5rem;
            border-top: 1px solid var(--border, #e2e8f0);
        }
        
        .voucher-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0.5rem 0;
            font-size: 0.875rem;
        }
        
        .voucher-code {
            font-family: monospace;
            background: #f1f5f9;
            padding: 0.25rem 0.5rem;
            border-radius: 0.25rem;
        }
        
        .empty-state {
            text-align: center;
            padding: 4rem 2rem;
            color: var(--muted, #64748b);
        }
        
        .empty-state img {
            width: 120px;
            height: 120px;
            margin-bottom: 1rem;
            opacity: 0.5;
        }
        
        .print-btn {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.5rem 1rem;
            background: var(--primary, #3b82f6);
            color: #fff;
            border: none;
            border-radius: 0.5rem;
            font-weight: 500;
            cursor: pointer;
            text-decoration: none;
            transition: background 0.2s ease;
        }
        
        .print-btn:hover {
            background: var(--primary-dark, #1d4ed8);
        }
        
        .chart-section {
            background: #fff;
            border-radius: 1rem;
            padding: 1.5rem;
            margin-bottom: 2rem;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }
        
        .chart-header {
            margin-bottom: 1.5rem;
        }
        
        .chart-header h3 {
            margin: 0 0 0.5rem;
            font-size: 1.25rem;
        }
        
        .chart-wrapper {
            overflow-x: auto;
            overflow-y: hidden;
            margin-bottom: 1rem;
            -webkit-overflow-scrolling: touch;
            width: 100%;
            max-width: 100%;
        }
        
        .chart-wrapper::-webkit-scrollbar {
            height: 12px;
        }
        
        .chart-wrapper::-webkit-scrollbar-track {
            background: #f1f5f9;
            border-radius: 6px;
        }
        
        .chart-wrapper::-webkit-scrollbar-thumb {
            background: #cbd5e1;
            border-radius: 6px;
        }
        
        .chart-wrapper::-webkit-scrollbar-thumb:hover {
            background: #94a3b8;
        }
        
        .chart-container {
            position: relative;
            height: 600px;
            min-width: 1200px;
            width: auto;
        }
        
        .chart-container canvas {
            width: 100% !important;
            height: 100% !important;
        }
        
        .stats-summary {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin-top: 1.5rem;
        }
        
        .stat-card {
            background: #f8fafc;
            padding: 1rem;
            border-radius: 0.75rem;
            border-left: 4px solid var(--primary, #3b82f6);
        }
        
        .stat-card.success {
            border-left-color: var(--success, #10b981);
        }
        
        .stat-card.danger {
            border-left-color: var(--danger, #ef4444);
        }
        
        .stat-label {
            font-size: 0.875rem;
            color: var(--muted, #64748b);
            margin-bottom: 0.5rem;
        }
        
        .stat-value {
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--text, #1e293b);
        }
        
        @media print {
            @page {
                size: A4;
                margin: 0.5cm;
            }
            
            body {
                background: #fff;
                padding: 0;
                margin: 0;
                font-size: 10px;
            }
            
            .transactions-header,
            .panel-header,
            .fab,
            .fab-menu,
            .search,
            .alert,
            .chart-section {
                display: none !important;
            }
            
            .transactions-page {
                max-width: 100%;
                padding: 0;
                margin: 0;
            }
            
            .panel {
                margin: 0;
                padding: 0;
                background: transparent;
                box-shadow: none;
                border-radius: 0;
            }
            
            .transaction-card {
                page-break-inside: avoid;
                break-inside: avoid;
                margin-bottom: 0.6rem;
                box-shadow: none;
                border: 1px solid #ccc;
                padding: 0.5rem;
                background: #fff;
            }
            
            .transaction-header {
                border-bottom: 1px solid #ccc;
                padding-bottom: 0.3rem;
                margin-bottom: 0.4rem;
            }
            
            .transaction-user {
                font-size: 0.9rem;
                font-weight: 700;
                margin-bottom: 0.1rem;
            }
            
            .transaction-branch {
                font-size: 0.75rem;
            }
            
            .transaction-id {
                font-size: 0.7rem;
            }
            
            .transaction-summary {
                background: #f8fafc !important;
                border: 1px solid #e2e8f0;
                padding: 0.4rem !important;
                margin-top: 0.4rem !important;
                gap: 0.5rem !important;
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }
            
            .summary-label {
                font-size: 0.7rem !important;
                margin-bottom: 0.1rem !important;
            }
            
            .summary-value {
                font-size: 0.85rem !important;
            }
            
            /* Optimasi item transaksi untuk print */
            .transaction-card > div {
                gap: 0.3rem !important;
                margin-top: 0.3rem !important;
            }
            
            .transaction-card > div > div {
                page-break-inside: avoid;
                break-inside: avoid;
                padding: 0.3rem !important;
                margin-bottom: 0.3rem !important;
            }
            
            /* Kurangi gap di flex container */
            .transaction-card > div > div[style*="display: flex"] {
                gap: 0.4rem !important;
            }
            
            .transaction-card > div > div > div[style*="display: flex"] {
                gap: 0.3rem !important;
            }
            
            /* Kurangi margin bottom */
            .transaction-card div[style*="margin-bottom: 0.25rem"] {
                margin-bottom: 0.1rem !important;
            }
            
            .transaction-card div[style*="margin-bottom: 0.75rem"] {
                margin-bottom: 0.3rem !important;
            }
            
            /* Gambar lebih kecil */
            img, svg {
                width: 40px !important;
                height: 40px !important;
                max-width: 40px !important;
                max-height: 40px !important;
            }
            
            /* Font size untuk item transaksi - override inline styles */
            .transaction-card > div > div {
                font-size: 0.7rem !important;
            }
            
            .transaction-card > div > div > div > div,
            .transaction-card > div > div > div > div > div {
                font-size: 0.7rem !important;
            }
            
            /* Product name dan info */
            .transaction-card div[style*="font-weight: 600"] {
                font-size: 0.75rem !important;
                margin-bottom: 0.1rem !important;
            }
            
            .transaction-card div[style*="font-size: 0.875rem"] {
                font-size: 0.65rem !important;
            }
            
            .transaction-card div[style*="font-size: 1.1rem"] {
                font-size: 0.8rem !important;
            }
            
            /* Voucher section */
            .transaction-card div[style*="margin-top: 0.75rem"] {
                margin-top: 0.3rem !important;
                padding-top: 0.3rem !important;
            }
            
            .transaction-card div[style*="margin-bottom: 0.5rem"] {
                margin-bottom: 0.2rem !important;
            }
            
            .transaction-card span[style*="font-size: 0.8rem"] {
                font-size: 0.6rem !important;
            }
            
            /* Voucher list lebih kecil */
            .voucher-list {
                margin-top: 0.3rem !important;
                padding-top: 0.3rem !important;
            }
            
            .voucher-item {
                padding: 0.2rem 0 !important;
                font-size: 0.65rem !important;
            }
            
            .voucher-code {
                font-size: 0.65rem !important;
                padding: 0.15rem 0.3rem !important;
            }
            
            /* Print header untuk setiap halaman */
            .print-header {
                display: block !important;
                text-align: center;
                margin-bottom: 0.5rem;
                padding-bottom: 0.3rem;
                border-bottom: 1px solid #000;
            }
            
            .print-header h1 {
                margin: 0 0 0.2rem;
                font-size: 1rem;
            }
            
            .print-header p {
                margin: 0;
                font-size: 0.7rem;
                color: #666;
            }
            
            /* Pastikan konten transaksi terlihat */
            .transaction-card > div {
                page-break-inside: avoid;
            }
            
            /* Optimasi untuk print */
            * {
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }
            
            /* Kurangi spacing umum */
            h1, h2, h3, h4, h5, h6 {
                margin: 0.3rem 0;
            }
            
            p {
                margin: 0.2rem 0;
            }
        }
    </style>
</head>
<body>
    <div class="transactions-page">
        <div class="transactions-header">
            <h1>Data Transaksi</h1>
            <p>Daftar semua transaksi redeem voucher</p>
        </div>
        <nav class="subnav">
            <a class="subnav-link" href="recap.php">Rekapitulasi</a>
            <a class="subnav-link <?= $currentPage === 'transactions' ? 'active' : '' ?>" href="transactions.php">Transaksi</a>
            <a class="subnav-link" href="referral.php">Voucher Referral</a>
        </nav>
        
        <!-- Chart Section -->
        <section class="chart-section">
            <div class="chart-header">
                <h3>Statistik Transaksi</h3>
                <p>Grafik perkembangan transaksi berdasarkan user</p>
            </div>
            <div class="chart-wrapper">
                <div class="chart-container">
                    <canvas id="transactionChart"></canvas>
                </div>
            </div>
            <div class="stats-summary">
                <div class="stat-card">
                    <div class="stat-label">Total User yang Belanja</div>
                    <div class="stat-value"><?= number_format($totalStats['total_users'], 0, ',', '.') ?></div>
                </div>
                <div class="stat-card success">
                    <div class="stat-label">Total Voucher Digunakan</div>
                    <div class="stat-value">Rp <?= number_format($totalStats['total_vouchers_used'], 0, ',', '.') ?></div>
                </div>
                <div class="stat-card danger">
                    <div class="stat-label">Total Kekurangan</div>
                    <div class="stat-value">Rp <?= number_format($totalStats['total_extra_charge'], 0, ',', '.') ?></div>
                </div>
            </div>
        </section>
        
        <section class="panel">
            <div class="panel-header">
                <div>
                    <h2>Daftar Transaksi</h2>
                    <p>Total: <strong><?= count($groupedTransactions) ?></strong> user, <strong><?= count($transactions) ?></strong> transaksi</p>
                </div>
                <div style="display: flex; gap: 1rem; align-items: center;">
                    <form class="search" method="get">
                        <?php if ($userId > 0) : ?>
                            <input type="hidden" name="user_id" value="<?= $userId ?>">
                        <?php endif; ?>
                        <input type="text" name="q" placeholder="Cari nama, produk, atau ID transaksi..." value="<?= htmlspecialchars($search) ?>">
                        <?php if ($search !== '') : ?>
                            <a class="btn btn-secondary" href="transactions.php<?= $userId > 0 ? '?user_id=' . $userId : '' ?>">Reset</a>
                        <?php endif; ?>
                        <button class="btn btn-primary" type="submit">Cari</button>
                    </form>
                    <button type="button" class="print-btn" onclick="window.print()">
                        🖨️ Print
                    </button>
                </div>
            </div>
            
            <!-- Print Header (hanya muncul saat print) -->
            <div class="print-header" style="display: none;">
                <h1>Data Transaksi</h1>
                <p>Dicetak pada: <?= date('d/m/Y H:i:s') ?> | Total: <?= count($groupedTransactions) ?> user, <?= count($transactions) ?> transaksi</p>
            </div>
            
            <?php if ($dbError !== null) : ?>
                <div class="alert alert-error">
                    <strong>Gagal terkoneksi database.</strong>
                    <span><?= htmlspecialchars($dbError) ?></span>
                </div>
            <?php elseif (empty($groupedTransactions)) : ?>
                <div class="empty-state">
                    <p style="font-size: 1.1rem; margin-bottom: 0.5rem;">Tidak ada transaksi</p>
                    <p style="font-size: 0.9rem;">Belum ada transaksi yang tercatat.</p>
                </div>
            <?php else : ?>
                <div style="display: flex; flex-direction: column; gap: 1rem;">
                    <?php foreach ($groupedTransactions as $userGroup) : ?>
                        <div class="transaction-card">
                            <div class="transaction-header">
                                <div class="transaction-info">
                                    <div class="transaction-user"><?= htmlspecialchars($userGroup['user_name']) ?></div>
                                    <div class="transaction-branch"><?= htmlspecialchars($userGroup['user_branch']) ?></div>
                                    <?php if (!empty($userGroup['user_no_hp'])) : ?>
                                        <div style="font-size: 0.9rem; color: #64748b; margin-top: 0.25rem;">
                                            📱 <?= htmlspecialchars($userGroup['user_no_hp']) ?>
                                        </div>
                                    <?php endif; ?>
                                    <div class="transaction-id" style="margin-top: 0.5rem;">
                                        <?= $userGroup['total_transactions'] ?> transaksi
                                    </div>
                                </div>
                            </div>
                            
                            <div style="display: flex; flex-direction: column; gap: 1rem; margin-top: 1rem;">
                                <?php foreach ($userGroup['transactions'] as $transaction) : ?>
                                    <div style="padding: 1rem; background: #f8fafc; border-radius: 0.75rem; border-left: 3px solid var(--primary, #3b82f6);">
                                        <div style="display: flex; gap: 1rem; margin-bottom: 0.75rem;">
                                            <!-- Product Image -->
                                            <div style="flex-shrink: 0;">
                                                <?php if ($transaction['product_image']) : ?>
                                                    <img src="<?= htmlspecialchars($transaction['product_image']) ?>" alt="<?= htmlspecialchars($transaction['product_name']) ?>" style="width: 80px; height: 80px; object-fit: cover; border-radius: 0.5rem; background: #f1f5f9;">
                                                <?php else : ?>
                                                    <svg style="width: 80px; height: 80px; border-radius: 0.5rem; background: #e2e8f0; padding: 0.5rem;" viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
                                                        <rect width="200" height="200" fill="#e2e8f0"/>
                                                        <path d="M60 60h80v80H60z" fill="#cbd5e1" stroke="#94a3b8" stroke-width="2"/>
                                                        <path d="M70 70l30 30 40-40" fill="none" stroke="#64748b" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
                                                        <circle cx="85" cy="85" r="8" fill="#64748b"/>
                                                    </svg>
                                                <?php endif; ?>
                                            </div>
                                            
                                            <!-- Product Info -->
                                            <div style="flex: 1; display: flex; justify-content: space-between; align-items: flex-start;">
                                                <div>
                                                    <div style="font-size: 0.875rem; color: var(--muted); margin-bottom: 0.25rem;">
                                                        ID: #<?= (int) $transaction['id'] ?>
                                                    </div>
                                                    <div style="font-weight: 600; margin-bottom: 0.25rem;">
                                                        <?= htmlspecialchars($transaction['product_name']) ?>
                                                        <?php if (!empty($transaction['variant_name'])) : ?>
                                                            <span style="color: var(--primary, #3b82f6); font-size: 0.9em; font-weight: 500;"> - <?= htmlspecialchars($transaction['variant_name']) ?></span>
                                                        <?php endif; ?>
                                                    </div>
                                                    <?php if (!empty($transaction['notes'])) : ?>
                                                        <div style="margin-top: 0.5rem; padding: 0.5rem; background: #fef3c7; border-radius: 0.375rem; border-left: 3px solid #f59e0b;">
                                                            <div style="font-size: 0.75rem; color: #92400e; font-weight: 600; margin-bottom: 0.25rem;">
                                                                📝 Catatan:
                                                            </div>
                                                            <div style="font-size: 0.875rem; color: #78350f; word-wrap: break-word;">
                                                                <?= htmlspecialchars($transaction['notes']) ?>
                                                            </div>
                                                        </div>
                                                    <?php endif; ?>
                                                    <div style="font-size: 0.875rem; color: var(--muted); margin-top: 0.5rem;">
                                                        <?= date('d/m/Y H:i', strtotime($transaction['created_at'])) ?>
                                                    </div>
                                                </div>
                                                <div style="text-align: right;">
                                                    <div style="font-size: 1.1rem; font-weight: 600; color: var(--primary);">
                                                        Rp <?= number_format((int) $transaction['total_price'], 0, ',', '.') ?>
                                                    </div>
                                                    <?php if ((int) $transaction['voucher_covered'] > 0) : ?>
                                                        <div style="font-size: 0.875rem; color: var(--success);">
                                                            Voucher: - Rp <?= number_format((int) $transaction['voucher_covered'], 0, ',', '.') ?>
                                                        </div>
                                                    <?php endif; ?>
                                                    <?php if ((int) $transaction['extra_charge'] > 0) : ?>
                                                        <div style="font-size: 0.875rem; color: var(--danger);">
                                                            Kekurangan: Rp <?= number_format((int) $transaction['extra_charge'], 0, ',', '.') ?>
                                                        </div>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <?php if (!empty($transaction['vouchers'])) : ?>
                                            <div style="margin-top: 0.75rem; padding-top: 0.75rem; border-top: 1px solid var(--border, #e2e8f0);">
                                                <div style="font-size: 0.875rem; color: var(--muted); margin-bottom: 0.5rem;">Voucher:</div>
                                                <div style="display: flex; flex-wrap: wrap; gap: 0.5rem;">
                                                    <?php foreach ($transaction['vouchers'] as $voucher) : ?>
                                                        <span class="voucher-code" style="font-size: 0.8rem;">
                                                            <?= htmlspecialchars($voucher['code']) ?> (Rp <?= number_format((int) $voucher['amount_applied'], 0, ',', '.') ?>)
                                                        </span>
                                                    <?php endforeach; ?>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                            
                            <div class="transaction-summary" style="margin-top: 1rem;">
                                <div class="summary-item">
                                    <span class="summary-label">Total Transaksi</span>
                                    <span class="summary-value"><?= $userGroup['total_transactions'] ?></span>
                                </div>
                                <div class="summary-item">
                                    <span class="summary-label">Total Harga</span>
                                    <span class="summary-value">Rp <?= number_format($userGroup['total_amount'], 0, ',', '.') ?></span>
                                </div>
                                <div class="summary-item">
                                    <span class="summary-label">Total Voucher</span>
                                    <span class="summary-value positive">- Rp <?= number_format($userGroup['total_voucher'], 0, ',', '.') ?></span>
                                </div>
                                <?php if ($userGroup['total_extra'] > 0) : ?>
                                    <div class="summary-item">
                                        <span class="summary-label">Total Kekurangan</span>
                                        <span class="summary-value negative">Rp <?= number_format($userGroup['total_extra'], 0, ',', '.') ?></span>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </section>
    </div>
    
    <button class="fab" id="fabButton" type="button">+</button>
    <div class="fab-menu" id="fabMenu">
        <a class="fab-item dashboard" href="index.php" title="Dashboard">🏠</a>
        <a class="fab-item new-guest" href="new_guest.php" title="New Guest">➕</a>
        <a class="fab-item products" href="new_product.php" title="New Product">🛍️</a>
        <a class="fab-item recap" href="recap.php" title="Rekapitulasi">📊</a>
        <a class="fab-item referral" href="referral.php" title="Voucher Referral">🎫</a>
    </div>
    <script>
        // Chart Data
        var chartData = <?= json_encode($chartStats) ?>;
        
        // Prepare data for chart
        var labels = [];
        var totalAmountData = [];
        var voucherData = [];
        var extraChargeData = [];
        
        if (chartData && chartData.length > 0) {
            chartData.forEach(function(item) {
                labels.push(item.label || '');
                totalAmountData.push(parseInt(item.total_amount) || 0);
                voucherData.push(parseInt(item.total_voucher_used) || 0);
                extraChargeData.push(parseInt(item.total_extra_charge) || 0);
            });
        } else {
            // Jika tidak ada data, tampilkan placeholder
            labels.push('Tidak ada data');
            totalAmountData.push(0);
            voucherData.push(0);
            extraChargeData.push(0);
        }
        
        // Set chart container width based on number of users
        var chartContainer = document.querySelector('.chart-container');
        var calculatedWidth = 1200;
        if (chartContainer && labels.length > 0) {
            // Minimum 1200px, but expand based on number of users
            // Each user needs approximately 120-140px width (reduced spacing for closer labels)
            calculatedWidth = Math.max(1200, labels.length * 120);
            chartContainer.style.width = calculatedWidth + 'px';
        }
        
        // Create Chart
        var ctx = document.getElementById('transactionChart');
        if (ctx && typeof Chart !== 'undefined') {
            // Set canvas size explicitly before creating chart
            ctx.width = calculatedWidth;
            ctx.height = 600;
            
            var chartInstance = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: labels,
                    datasets: [
                        {
                            label: 'Total Transaksi (Rp)',
                            data: totalAmountData,
                            borderColor: 'rgb(59, 130, 246)',
                            backgroundColor: 'rgba(59, 130, 246, 0.1)',
                            borderWidth: 4,
                            pointRadius: 8,
                            pointHoverRadius: 10,
                            pointBorderWidth: 3,
                            tension: 0.4,
                            fill: true,
                            yAxisID: 'y',
                        },
                        {
                            label: 'Voucher Digunakan (Rp)',
                            data: voucherData,
                            borderColor: 'rgb(16, 185, 129)',
                            backgroundColor: 'rgba(16, 185, 129, 0.1)',
                            borderWidth: 4,
                            pointRadius: 8,
                            pointHoverRadius: 10,
                            pointBorderWidth: 3,
                            tension: 0.4,
                            fill: true,
                            yAxisID: 'y',
                        },
                        {
                            label: 'Total Kekurangan (Rp)',
                            data: extraChargeData,
                            borderColor: 'rgb(239, 68, 68)',
                            backgroundColor: 'rgba(239, 68, 68, 0.1)',
                            borderWidth: 4,
                            pointRadius: 8,
                            pointHoverRadius: 10,
                            pointBorderWidth: 3,
                            tension: 0.4,
                            fill: true,
                            yAxisID: 'y',
                        }
                    ]
                },
                options: {
                    responsive: false,
                    maintainAspectRatio: false,
                    devicePixelRatio: 1,
                    layout: {
                        padding: {
                            top: 20,
                            right: 30,
                            bottom: 20,
                            left: 20
                        }
                    },
                    interaction: {
                        mode: 'index',
                        intersect: false,
                    },
                    plugins: {
                        legend: {
                            position: 'top',
                            labels: {
                                font: {
                                    size: 16,
                                    weight: 'bold'
                                },
                                padding: 20,
                                boxWidth: 20,
                                boxHeight: 20
                            }
                        },
                        tooltip: {
                            titleFont: {
                                size: 16,
                                weight: 'bold'
                            },
                            bodyFont: {
                                size: 15
                            },
                            padding: 15,
                            callbacks: {
                                title: function(context) {
                                    var index = context[0].dataIndex;
                                    if (chartData && chartData[index] && chartData[index].user_name) {
                                        return chartData[index].user_name;
                                    }
                                    return context[0].label || '';
                                },
                                label: function(context) {
                                    var label = context.dataset.label || '';
                                    if (label) {
                                        label += ': ';
                                    }
                                    label += 'Rp ' + context.parsed.y.toLocaleString('id-ID');
                                    return label;
                                }
                            }
                        }
                    },
                    scales: {
                        x: {
                            title: {
                                display: true,
                                text: 'User',
                                font: {
                                    size: 18,
                                    weight: 'bold'
                                },
                                padding: { top: 15, bottom: 0 }
                            },
                            ticks: {
                                maxRotation: 45,
                                minRotation: 45,
                                autoSkip: false,
                                font: {
                                    size: 14,
                                    weight: '500'
                                },
                                padding: 12,
                                callback: function(value, index) {
                                    // Tampilkan semua label
                                    if (index < labels.length) {
                                        return labels[index];
                                    }
                                    return '';
                                }
                            }
                        },
                        y: {
                            type: 'linear',
                            display: true,
                            position: 'left',
                            title: {
                                display: true,
                                text: 'Jumlah (Rp)',
                                font: {
                                    size: 18,
                                    weight: 'bold'
                                },
                                padding: { top: 0, bottom: 15 }
                            },
                            ticks: {
                                font: {
                                    size: 14,
                                    weight: '500'
                                },
                                padding: 12,
                                callback: function(value) {
                                    return 'Rp ' + value.toLocaleString('id-ID');
                                }
                            }
                        }
                    }
                }
            });
        }
        
        (function () {
            var fabButton = document.getElementById('fabButton');
            var fabMenu = document.getElementById('fabMenu');

            var toggleMenu = function () {
                if (!fabMenu || !fabButton) {
                    return;
                }
                fabMenu.classList.toggle('open');
                fabButton.classList.toggle('open');
            };

            if (fabButton) {
                fabButton.addEventListener('click', toggleMenu);
            }
        })();
    </script>
</body>
</html>

