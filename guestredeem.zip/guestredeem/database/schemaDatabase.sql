-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Waktu pembuatan: 21 Nov 2025 pada 03.37
-- Versi server: 10.4.28-MariaDB
-- Versi PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `guestredeem`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `products`
--

CREATE TABLE `products` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(150) NOT NULL,
  `gambar` varchar(255) DEFAULT NULL,
  `price` int(10) UNSIGNED NOT NULL,
  `qty` int(11) DEFAULT NULL,
  `kode_product` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `products`
--

INSERT INTO `products` (`id`, `name`, `gambar`, `price`, `qty`, `kode_product`, `is_active`, `created_at`) VALUES
(28, 'Stand HP', 'uploads/products/prd_691d8061db010.jpg', 80000, NULL, 'PRD-3B1F11', 1, '2025-11-19 08:31:29'),
(35, 'Albianto 2', NULL, 8000, NULL, 'PRD-A55E22', 1, '2025-11-20 08:35:35');

-- --------------------------------------------------------

--
-- Struktur dari tabel `product_variants`
--

CREATE TABLE `product_variants` (
  `id` int(10) UNSIGNED NOT NULL,
  `product_id` int(10) UNSIGNED NOT NULL,
  `variant_name` varchar(150) NOT NULL,
  `price` int(10) UNSIGNED DEFAULT NULL,
  `sku` varchar(100) DEFAULT NULL,
  `stock` int(11) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `transactions`
--

CREATE TABLE `transactions` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `product_id` int(10) UNSIGNED NOT NULL,
  `total_price` int(15) UNSIGNED NOT NULL,
  `voucher_covered` int(10) UNSIGNED NOT NULL,
  `extra_charge` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `transactions`
--

INSERT INTO `transactions` (`id`, `user_id`, `product_id`, `total_price`, `voucher_covered`, `extra_charge`, `created_at`) VALUES
(7, 115, 28, 80000, 80000, 0, '2025-11-19 08:33:33'),
(8, 113, 28, 80000, 70000, 10000, '2025-11-19 08:35:08'),
(9, 45, 28, 80000, 70000, 10000, '2025-11-19 08:35:28'),
(10, 70, 28, 4294967295, 70000, 4294967295, '2025-11-19 08:39:48'),
(11, 90, 28, 4294967295, 70000, 4294967295, '2025-11-19 08:41:12'),
(12, 54, 28, 4294967295, 70000, 4294967295, '2025-11-19 08:43:28'),
(13, 106, 28, 64000000, 70000, 63930000, '2025-11-19 08:43:55'),
(14, 100, 28, 1600000000, 70000, 1599930000, '2025-11-19 08:44:37');

-- --------------------------------------------------------

--
-- Struktur dari tabel `transaction_vouchers`
--

CREATE TABLE `transaction_vouchers` (
  `transaction_id` int(10) UNSIGNED NOT NULL,
  `voucher_id` int(10) UNSIGNED NOT NULL,
  `amount_applied` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `transaction_vouchers`
--

INSERT INTO `transaction_vouchers` (`transaction_id`, `voucher_id`, `amount_applied`) VALUES
(7, 102, 10000),
(7, 103, 70000),
(8, 101, 70000),
(9, 33, 70000),
(10, 58, 70000),
(11, 78, 70000),
(12, 42, 70000),
(13, 94, 70000),
(14, 88, 70000);

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(120) NOT NULL,
  `branch` varchar(120) DEFAULT NULL,
  `no_hp` varchar(255) DEFAULT NULL,
  `attendance_status` enum('belum hadir','hadir') NOT NULL DEFAULT 'belum hadir',
  `attendance_at` datetime DEFAULT NULL,
  `voucher_code` varchar(60) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `name`, `branch`, `no_hp`, `attendance_status`, `attendance_at`, `voucher_code`, `created_at`) VALUES
(40, 'Era Agnesia Hotmauly', 'TK KOWI', '081288993937', 'belum hadir', NULL, 'tds0001', '2025-11-19 08:30:48'),
(41, 'Juanitagl Greselia Sabuna', 'TK KOWI', '088223800581', 'belum hadir', NULL, 'tds0002', '2025-11-19 08:30:48'),
(42, 'Dede Novita ( Ms Vita )', 'TK KOWI', '082116217187', 'belum hadir', NULL, 'tds0003', '2025-11-19 08:30:48'),
(43, 'Gita Meta Ramayana Br Saragih', 'TK KOWI', '081211053925', 'belum hadir', NULL, 'tds0004', '2025-11-19 08:30:48'),
(44, 'Lina Rahmayani', 'SMP DDN', '085694462701', 'belum hadir', NULL, 'tds0005', '2025-11-19 08:30:48'),
(45, 'ARYANTI PRATIWI', 'SMP DDN', '081311589661', 'hadir', '2025-11-19 00:35:21', 'tds0006', '2025-11-19 08:30:48'),
(46, 'Muhammad Zakie Walad', 'SMP KOWI', '081286498086', 'belum hadir', NULL, 'tds0007', '2025-11-19 08:30:48'),
(47, 'Dorty Elisabet', 'SD DDN', '082311937919', 'belum hadir', NULL, 'tds0008', '2025-11-19 08:30:48'),
(48, 'Indri Putri Hapsari', 'SD DDN', '08568584732', 'belum hadir', NULL, 'tds0009', '2025-11-19 08:30:48'),
(49, 'Harizka Erlifiana', 'SD DDN', '088210162862', 'belum hadir', NULL, 'tds0010', '2025-11-19 08:30:48'),
(50, 'Rizki Nur Ainy', 'SD DDN', '085810141076', 'belum hadir', NULL, 'tds0011', '2025-11-19 08:30:48'),
(51, 'Andri Setyawan', 'SD DDN', '08119805506', 'belum hadir', NULL, 'tds0012', '2025-11-19 08:30:48'),
(52, 'Pera Priantini', 'SD DDN', '0895417311069', 'belum hadir', NULL, 'tds0013', '2025-11-19 08:30:48'),
(53, 'Norma Anisa Prihatini', 'SD DDN', '088227811306', 'belum hadir', NULL, 'tds0014', '2025-11-19 08:30:48'),
(54, 'Adnovria Felani', 'SD DDN', '0818772156', 'hadir', '2025-11-19 00:42:54', 'tds0015', '2025-11-19 08:30:48'),
(55, 'Dahayu Putri Shabira (Ms ayu)', 'TK KOWI', '081295844264', 'belum hadir', NULL, 'tds0016', '2025-11-19 08:30:48'),
(56, 'Reza Fani Palevi', 'SD DDN', '085215878213', 'belum hadir', NULL, 'tds0017', '2025-11-19 08:30:48'),
(57, 'Tri Arti Esianna Dabukke', 'SD DDN', '082180517828', 'belum hadir', NULL, 'tds0018', '2025-11-19 08:30:48'),
(58, 'Nabilah Sahda Larissa', 'SD DDN', '0895412940268', 'belum hadir', NULL, 'tds0019', '2025-11-19 08:30:48'),
(59, 'Yurida', 'SD DDN', '088210797009', 'belum hadir', NULL, 'tds0020', '2025-11-19 08:30:48'),
(60, 'Singgih Pratiwi', 'SD DDN', '081292852223', 'belum hadir', NULL, 'tds0021', '2025-11-19 08:30:48'),
(61, 'Siswo Sunarso', 'SD DDN', '085780777807', 'belum hadir', NULL, 'tds0022', '2025-11-19 08:30:48'),
(62, 'Bernadus Seik, S.Sos', 'SD DDN', '081288162240', 'belum hadir', NULL, 'tds0023', '2025-11-19 08:30:48'),
(63, 'Badari Arta Vivana', 'SD DDN', '085162648825', 'belum hadir', NULL, 'tds0024', '2025-11-19 08:30:48'),
(64, 'Elfrida Eufraziana Botta', 'SMP DDN', '085718356910', 'belum hadir', NULL, 'tds0025', '2025-11-19 08:30:48'),
(65, 'Ulfa Azizah', 'SD DDN', '085718799335', 'belum hadir', NULL, 'tds0026', '2025-11-19 08:30:48'),
(66, 'Gisella Tioriva Br Bangun', 'SMP DDN', '085156014553', 'belum hadir', NULL, 'tds0027', '2025-11-19 08:30:48'),
(67, 'Nia Sriawati', 'SD DDN', '08998252792', 'belum hadir', NULL, 'tds0028', '2025-11-19 08:30:48'),
(68, 'Rita Ratnaningsih', 'TK Address', '085778810512', 'belum hadir', NULL, 'tds0029', '2025-11-19 08:30:48'),
(69, 'Antok Lisdirianta', 'Departemen Akademik', '087888245556', 'belum hadir', NULL, 'tds0030', '2025-11-19 08:30:48'),
(70, 'Adelia Bella Luthfia', 'SD DDN', '087772781967', 'hadir', '2025-11-19 00:38:58', 'tds0031', '2025-11-19 08:30:48'),
(71, 'Ratih Purwasih', 'SD DDN', '08999158909', 'belum hadir', NULL, 'tds0032', '2025-11-19 08:30:48'),
(72, 'Nabil', 'Departemen Akademik', '081318333831', 'belum hadir', NULL, 'tds0033', '2025-11-19 08:30:48'),
(73, 'Mutiara Indah Lestari', 'SD DDN', '08883917022', 'belum hadir', NULL, 'tds0034', '2025-11-19 08:30:48'),
(74, 'Lian Apriyani', 'SD DDN', '0895384106076', 'belum hadir', NULL, 'tds0035', '2025-11-19 08:30:48'),
(75, 'Ani Suhartini', 'TK CG', '081906348151', 'belum hadir', NULL, 'tds0036', '2025-11-19 08:30:48'),
(76, 'Nurlaila', 'TK CG', '081212792275', 'belum hadir', NULL, 'tds0037', '2025-11-19 08:30:48'),
(77, 'Suyati', 'SD DDN', '082110369700', 'belum hadir', NULL, 'tds0038', '2025-11-19 08:30:48'),
(78, 'Permata Imelda Veronika', 'TK CG', '081380863280', 'belum hadir', NULL, 'tds0039', '2025-11-19 08:30:48'),
(79, 'Trinita Hestiana', 'Departemen Akademik', '081283305764', 'belum hadir', NULL, 'tds0040', '2025-11-19 08:30:48'),
(80, 'M faishal maulana', 'SMP KOWI', '089504165025', 'belum hadir', NULL, 'tds0041', '2025-11-19 08:30:48'),
(81, 'Meisyella Nina Nola Padang', 'TK KOWI', '081385057963', 'belum hadir', NULL, 'tds0042', '2025-11-19 08:30:48'),
(82, 'Ms dhea gita', 'TK KOWI', '085156319148', 'belum hadir', NULL, 'tds0043', '2025-11-19 08:30:48'),
(83, 'Dian Agustini', 'TK CG', '081511593401', 'belum hadir', NULL, 'tds0044', '2025-11-19 08:30:48'),
(84, 'Larry Tua Hasiholan', 'SD DDN', '08561055844', 'belum hadir', NULL, 'tds0045', '2025-11-19 08:30:48'),
(85, 'Demi Winna Sirait', 'TK KOWI', '082210028218', 'belum hadir', NULL, 'tds0046', '2025-11-19 08:30:48'),
(86, 'Tri Puspita sari', 'TK CG', '081908662233', 'belum hadir', NULL, 'tds0047', '2025-11-19 08:30:48'),
(87, 'Ridar Kurnia Pratama', 'SMP DDN', '081295652510', 'belum hadir', NULL, 'tds0048', '2025-11-19 08:30:48'),
(88, 'Febriansyah Airlangga, S.Pd', 'SD DDN', '088809437395', 'belum hadir', NULL, 'tds0049', '2025-11-19 08:30:48'),
(89, 'Fajrul Rahman', 'SMP DDN', '081280935426', 'belum hadir', NULL, 'tds0050', '2025-11-19 08:30:48'),
(90, 'Adjeng Putri Yani', 'SMP DDN', '0812 8341 9377', 'hadir', '2025-11-19 00:40:41', 'tds0051', '2025-11-19 08:30:48'),
(91, 'Sahrul Gunawan', 'SMP KOWI', '089667918008', 'belum hadir', NULL, 'tds0052', '2025-11-19 08:30:48'),
(92, 'Kezia Alicia Geraldine', 'TK Address', '087888011538', 'belum hadir', NULL, 'tds0053', '2025-11-19 08:30:48'),
(93, 'Nabillah Pangesti Rahayu', 'SMP KOWI', '089609038010', 'belum hadir', NULL, 'tds0054', '2025-11-19 08:30:48'),
(94, 'Irene Rosalin', 'SMP DDN', '085781038776', 'belum hadir', NULL, 'tds0055', '2025-11-19 08:30:48'),
(95, 'Viska Amelia Larasati', 'SMP DDN', '081286226421', 'belum hadir', NULL, 'tds0056', '2025-11-19 08:30:48'),
(96, 'Nur Apriyani', 'SMP DDN', '085959851064', 'belum hadir', NULL, 'tds0057', '2025-11-19 08:30:48'),
(97, 'Dwi Anjani Lestari', 'SMP DDN', '081284114632', 'belum hadir', NULL, 'tds0058', '2025-11-19 08:30:48'),
(98, 'Anita', 'SMP KOWI', '085189756298', 'belum hadir', NULL, 'tds0059', '2025-11-19 08:30:48'),
(99, 'Teguh widodo', 'SMP KOWI', '082114563912', 'belum hadir', NULL, 'tds0060', '2025-11-19 08:30:48'),
(100, 'Agus Sumarta', 'TK Raffles', '085720543077', 'hadir', '2025-11-19 00:44:07', 'tds0061', '2025-11-19 08:30:48'),
(101, 'Jessica Yokhebed', 'TK KOWI', '088213860366', 'belum hadir', NULL, 'tds0062', '2025-11-19 08:30:48'),
(102, 'YOSI ANDRIAWAN', 'TK KOWI', '0895405947974', 'belum hadir', NULL, 'tds0063', '2025-11-19 08:30:48'),
(103, 'Satik Vinita', 'SMP KOWI', '089627134419', 'belum hadir', NULL, 'tds0064', '2025-11-19 08:30:48'),
(104, 'Ismi Yuan Putri', 'SMP KOWI', '085720691216', 'belum hadir', NULL, 'tds0065', '2025-11-19 08:30:48'),
(105, 'Sari Dewi Laraswati', 'SMP KOWI', '081398102812', 'belum hadir', NULL, 'tds0066', '2025-11-19 08:30:48'),
(106, 'Agus Rozani', 'SMP KOWI', '082388003906', 'hadir', '2025-11-19 00:43:44', 'tds0067', '2025-11-19 08:30:48'),
(107, 'Septa Dwi Guna', 'SMP KOWI', '082125670400', 'belum hadir', NULL, 'tds0068', '2025-11-19 08:30:48'),
(108, 'Lintang Ratri Merryska Putri (Ms. Lintang)', 'TK KOWI', '085740192062', 'belum hadir', NULL, 'tds0069', '2025-11-19 08:30:48'),
(109, 'Sinta Yuliastuti', 'SMP KOWI', '08981602005', 'belum hadir', NULL, 'tds0070', '2025-11-19 08:30:48'),
(110, 'Yohana Natalia Rahayaan', 'SMP KOWI', '081384755010', 'belum hadir', NULL, 'tds0071', '2025-11-19 08:30:48'),
(111, 'Umi Rodiyatun', 'TK DDN', '085742566138', 'belum hadir', NULL, 'tds0072', '2025-11-19 08:30:48'),
(112, 'Aryasi wita noviana', 'TK DDN', '085760592117', 'hadir', '2025-11-19 15:57:15', 'tds0073', '2025-11-19 08:30:48'),
(113, 'Albi', 'IT', NULL, 'hadir', '2025-11-19 00:32:25', 'tds0074', '2025-11-19 08:31:58'),
(114, 'Ryan', 'IT', NULL, 'hadir', '2025-11-19 00:32:26', 'tds0075', '2025-11-19 08:31:58'),
(115, 'Adit', 'IT', NULL, 'hadir', '2025-11-19 00:32:21', 'tds0076', '2025-11-19 08:31:58'),
(116, 'Aldi', 'IT', NULL, 'belum hadir', NULL, 'tds0077', '2025-11-19 08:32:14');

-- --------------------------------------------------------

--
-- Struktur dari tabel `vouchers`
--

CREATE TABLE `vouchers` (
  `id` int(10) UNSIGNED NOT NULL,
  `code` varchar(60) NOT NULL,
  `value` int(10) UNSIGNED NOT NULL DEFAULT 70000,
  `owner_user_id` int(10) UNSIGNED NOT NULL,
  `status` enum('unused','reserved','used','expired') NOT NULL DEFAULT 'unused',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `vouchers`
--

INSERT INTO `vouchers` (`id`, `code`, `value`, `owner_user_id`, `status`, `created_at`) VALUES
(28, 'tds0001', 70000, 40, 'unused', '2025-11-19 08:30:48'),
(29, 'tds0002', 70000, 41, 'unused', '2025-11-19 08:30:48'),
(30, 'tds0003', 70000, 42, 'unused', '2025-11-19 08:30:48'),
(31, 'tds0004', 70000, 43, 'unused', '2025-11-19 08:30:48'),
(32, 'tds0005', 70000, 44, 'unused', '2025-11-19 08:30:48'),
(33, 'tds0006', 70000, 45, 'used', '2025-11-19 08:30:48'),
(34, 'tds0007', 70000, 46, 'unused', '2025-11-19 08:30:48'),
(35, 'tds0008', 70000, 47, 'unused', '2025-11-19 08:30:48'),
(36, 'tds0009', 70000, 48, 'unused', '2025-11-19 08:30:48'),
(37, 'tds0010', 70000, 49, 'unused', '2025-11-19 08:30:48'),
(38, 'tds0011', 70000, 50, 'unused', '2025-11-19 08:30:48'),
(39, 'tds0012', 70000, 51, 'unused', '2025-11-19 08:30:48'),
(40, 'tds0013', 70000, 52, 'unused', '2025-11-19 08:30:48'),
(41, 'tds0014', 70000, 53, 'unused', '2025-11-19 08:30:48'),
(42, 'tds0015', 70000, 54, 'used', '2025-11-19 08:30:48'),
(43, 'tds0016', 70000, 55, 'unused', '2025-11-19 08:30:48'),
(44, 'tds0017', 70000, 56, 'unused', '2025-11-19 08:30:48'),
(45, 'tds0018', 70000, 57, 'unused', '2025-11-19 08:30:48'),
(46, 'tds0019', 70000, 58, 'unused', '2025-11-19 08:30:48'),
(47, 'tds0020', 70000, 59, 'unused', '2025-11-19 08:30:48'),
(48, 'tds0021', 70000, 60, 'unused', '2025-11-19 08:30:48'),
(49, 'tds0022', 70000, 61, 'unused', '2025-11-19 08:30:48'),
(50, 'tds0023', 70000, 62, 'unused', '2025-11-19 08:30:48'),
(51, 'tds0024', 70000, 63, 'unused', '2025-11-19 08:30:48'),
(52, 'tds0025', 70000, 64, 'unused', '2025-11-19 08:30:48'),
(53, 'tds0026', 70000, 65, 'unused', '2025-11-19 08:30:48'),
(54, 'tds0027', 70000, 66, 'unused', '2025-11-19 08:30:48'),
(55, 'tds0028', 70000, 67, 'unused', '2025-11-19 08:30:48'),
(56, 'tds0029', 70000, 68, 'unused', '2025-11-19 08:30:48'),
(57, 'tds0030', 70000, 69, 'unused', '2025-11-19 08:30:48'),
(58, 'tds0031', 70000, 70, 'used', '2025-11-19 08:30:48'),
(59, 'tds0032', 70000, 71, 'unused', '2025-11-19 08:30:48'),
(60, 'tds0033', 70000, 72, 'unused', '2025-11-19 08:30:48'),
(61, 'tds0034', 70000, 73, 'unused', '2025-11-19 08:30:48'),
(62, 'tds0035', 70000, 74, 'unused', '2025-11-19 08:30:48'),
(63, 'tds0036', 70000, 75, 'unused', '2025-11-19 08:30:48'),
(64, 'tds0037', 70000, 76, 'unused', '2025-11-19 08:30:48'),
(65, 'tds0038', 70000, 77, 'unused', '2025-11-19 08:30:48'),
(66, 'tds0039', 70000, 78, 'unused', '2025-11-19 08:30:48'),
(67, 'tds0040', 70000, 79, 'unused', '2025-11-19 08:30:48'),
(68, 'tds0041', 70000, 80, 'unused', '2025-11-19 08:30:48'),
(69, 'tds0042', 70000, 81, 'unused', '2025-11-19 08:30:48'),
(70, 'tds0043', 70000, 82, 'unused', '2025-11-19 08:30:48'),
(71, 'tds0044', 70000, 83, 'unused', '2025-11-19 08:30:48'),
(72, 'tds0045', 70000, 84, 'unused', '2025-11-19 08:30:48'),
(73, 'tds0046', 70000, 85, 'unused', '2025-11-19 08:30:48'),
(74, 'tds0047', 70000, 86, 'unused', '2025-11-19 08:30:48'),
(75, 'tds0048', 70000, 87, 'unused', '2025-11-19 08:30:48'),
(76, 'tds0049', 70000, 88, 'unused', '2025-11-19 08:30:48'),
(77, 'tds0050', 70000, 89, 'unused', '2025-11-19 08:30:48'),
(78, 'tds0051', 70000, 90, 'used', '2025-11-19 08:30:48'),
(79, 'tds0052', 70000, 91, 'unused', '2025-11-19 08:30:48'),
(80, 'tds0053', 70000, 92, 'unused', '2025-11-19 08:30:48'),
(81, 'tds0054', 70000, 93, 'unused', '2025-11-19 08:30:48'),
(82, 'tds0055', 70000, 94, 'unused', '2025-11-19 08:30:48'),
(83, 'tds0056', 70000, 95, 'unused', '2025-11-19 08:30:48'),
(84, 'tds0057', 70000, 96, 'unused', '2025-11-19 08:30:48'),
(85, 'tds0058', 70000, 97, 'unused', '2025-11-19 08:30:48'),
(86, 'tds0059', 70000, 98, 'unused', '2025-11-19 08:30:48'),
(87, 'tds0060', 70000, 99, 'unused', '2025-11-19 08:30:48'),
(88, 'tds0061', 70000, 100, 'used', '2025-11-19 08:30:48'),
(89, 'tds0062', 70000, 101, 'unused', '2025-11-19 08:30:48'),
(90, 'tds0063', 70000, 102, 'unused', '2025-11-19 08:30:48'),
(91, 'tds0064', 70000, 103, 'unused', '2025-11-19 08:30:48'),
(92, 'tds0065', 70000, 104, 'unused', '2025-11-19 08:30:48'),
(93, 'tds0066', 70000, 105, 'unused', '2025-11-19 08:30:48'),
(94, 'tds0067', 70000, 106, 'used', '2025-11-19 08:30:48'),
(95, 'tds0068', 70000, 107, 'unused', '2025-11-19 08:30:48'),
(96, 'tds0069', 70000, 108, 'unused', '2025-11-19 08:30:48'),
(97, 'tds0070', 70000, 109, 'unused', '2025-11-19 08:30:48'),
(98, 'tds0071', 70000, 110, 'unused', '2025-11-19 08:30:48'),
(99, 'tds0072', 70000, 111, 'unused', '2025-11-19 08:30:48'),
(100, 'tds0073', 70000, 112, 'unused', '2025-11-19 08:30:48'),
(101, 'tds0074', 70000, 113, 'used', '2025-11-19 08:31:58'),
(102, 'tds0075', 70000, 114, 'used', '2025-11-19 08:31:58'),
(103, 'tds0076', 70000, 115, 'used', '2025-11-19 08:31:58'),
(104, 'tds0077', 70000, 116, 'unused', '2025-11-19 08:32:14');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `product_variants`
--
ALTER TABLE `product_variants`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indeks untuk tabel `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indeks untuk tabel `transaction_vouchers`
--
ALTER TABLE `transaction_vouchers`
  ADD PRIMARY KEY (`transaction_id`,`voucher_id`),
  ADD KEY `voucher_id` (`voucher_id`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `voucher_code` (`voucher_code`);

--
-- Indeks untuk tabel `vouchers`
--
ALTER TABLE `vouchers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`),
  ADD KEY `owner_user_id` (`owner_user_id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `products`
--
ALTER TABLE `products`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT untuk tabel `product_variants`
--
ALTER TABLE `product_variants`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=117;

--
-- AUTO_INCREMENT untuk tabel `vouchers`
--
ALTER TABLE `vouchers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=105;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `product_variants`
--
ALTER TABLE `product_variants`
  ADD CONSTRAINT `product_variants_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);

--
-- Ketidakleluasaan untuk tabel `transactions`
--
ALTER TABLE `transactions`
  ADD CONSTRAINT `transactions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `transactions_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);

--
-- Ketidakleluasaan untuk tabel `transaction_vouchers`
--
ALTER TABLE `transaction_vouchers`
  ADD CONSTRAINT `transaction_vouchers_ibfk_1` FOREIGN KEY (`transaction_id`) REFERENCES `transactions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `transaction_vouchers_ibfk_2` FOREIGN KEY (`voucher_id`) REFERENCES `vouchers` (`id`) ON DELETE CASCADE;

--
-- Ketidakleluasaan untuk tabel `vouchers`
--
ALTER TABLE `vouchers`
  ADD CONSTRAINT `vouchers_ibfk_1` FOREIGN KEY (`owner_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
