-- Migration: Tambah kolom notes ke tabel transactions
-- Tanggal: 2025-11-24

-- Tambah kolom notes (nullable, karena transaksi lama mungkin tidak punya notes)
ALTER TABLE `transactions` 
ADD COLUMN `notes` text DEFAULT NULL AFTER `extra_charge`;

