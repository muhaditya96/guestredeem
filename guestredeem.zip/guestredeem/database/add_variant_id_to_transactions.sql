-- Migration: Tambah kolom variant_id ke tabel transactions
-- Tanggal: 2025-11-21

-- Tambah kolom variant_id (nullable, karena transaksi lama mungkin tidak punya variant)
ALTER TABLE `transactions` 
ADD COLUMN `variant_id` int(10) UNSIGNED DEFAULT NULL AFTER `product_id`;

-- Tambah foreign key constraint ke product_variants
ALTER TABLE `transactions`
ADD CONSTRAINT `transactions_ibfk_variant` 
FOREIGN KEY (`variant_id`) REFERENCES `product_variants` (`id`) 
ON DELETE SET NULL ON UPDATE CASCADE;

-- Tambah index untuk performa query
ALTER TABLE `transactions`
ADD INDEX `idx_variant_id` (`variant_id`);

