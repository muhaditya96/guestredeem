<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';

$errors = [];
$successMessage = null;
$importSummary = null;
$uploadDir = __DIR__ . '/uploads/products';

/**
 * Mengecek apakah kode produk sudah digunakan.
 */
function productCodeExists(PDO $pdo, string $code): bool
{
    static $stmt = null;

    if ($stmt === null) {
        $stmt = $pdo->prepare('SELECT COUNT(*) FROM products WHERE kode_product = :code LIMIT 1');
    }

    $stmt->execute([':code' => $code]);

    return (int) $stmt->fetchColumn() > 0;
}

/**
 * Membuat kode produk otomatis yang dijamin unik.
 */
function generateAutomaticProductCode(PDO $pdo): string
{
    do {
        $code = 'PRD-' . strtoupper(substr(md5(uniqid((string) mt_rand(), true)), 0, 6));
    } while (productCodeExists($pdo, $code));

    return $code;
}

/**
 * Membersihkan string angka dari karakter pemisah.
 */
function normalizeNumber(?string $value): ?string
{
    if ($value === null) {
        return null;
    }

    $value = trim((string) $value);

    if ($value === '') {
        return null;
    }

    $digits = preg_replace('/[^\d]/', '', $value);

    return $digits === '' ? null : $digits;
}

/**
 * Mengonversi status menjadi 1 atau 0.
 */
function normalizeStatus($value): int
{
    if ($value === null || $value === '') {
        return 1;
    }

    if (is_numeric($value)) {
        return (int) ((int) $value === 1);
    }

    $value = strtolower(trim((string) $value));

    $inactive = ['0', 'no', 'tidak', 'nonaktif', 'inactive', 'false'];
    $active = ['1', 'yes', 'ya', 'aktif', 'active', 'true'];

    if (in_array($value, $inactive, true)) {
        return 0;
    }

    if (in_array($value, $active, true)) {
        return 1;
    }

    return 1;
}

/**
 * Mengambil data dari file spreadsheet (CSV/XLSX).
 *
 * @return array<int, array<int, string>>
 */
function getSpreadsheetRows(string $path, string $extension): array
{
    if ($extension === 'csv') {
        $rows = [];
        if (($handle = fopen($path, 'r')) === false) {
            throw new RuntimeException('Tidak bisa membaca file CSV.');
        }

        while (($data = fgetcsv($handle)) !== false) {
            $rows[] = $data;
        }

        fclose($handle);

        return $rows;
    }

    if ($extension === 'xlsx') {
        if (!class_exists('SimpleXLSX')) {
            $library = __DIR__ . '/lib/SimpleXLSX.php';

            if (!file_exists($library)) {
                throw new RuntimeException('Library SimpleXLSX tidak ditemukan.');
            }

            require_once $library;
        }

        $xlsx = SimpleXLSX::parse($path);

        if ($xlsx === false) {
            throw new RuntimeException('File Excel tidak valid: ' . SimpleXLSX::parseError());
        }

        return $xlsx->rows();
    }

    throw new RuntimeException('Format file tidak didukung.');
}

/**
 * Mencari index kolom berdasarkan beberapa kandidat nama header.
 *
 * @param array<int, string> $headers
 * @param array<string, array<int, string>> $lookup
 * @return array<string, int>
 */
function mapHeaderIndexes(array $headers, array $lookup): array
{
    $normalized = array_map(fn($header) => strtolower(trim((string) $header)), $headers);
    $result = [];

    foreach ($lookup as $field => $candidates) {
        foreach ($candidates as $candidate) {
            $index = array_search(strtolower($candidate), $normalized, true);
            if ($index !== false) {
                $result[$field] = $index;
                break;
            }
        }
    }

    return $result;
}

$formType = isset($_POST['form_type']) ? $_POST['form_type'] : 'single';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $formType === 'single') {
    $name = isset($_POST['name']) ? trim($_POST['name']) : '';
    $price = isset($_POST['price']) ? trim($_POST['price']) : '';
    $code = isset($_POST['code']) ? trim($_POST['code']) : '';
    $qty = isset($_POST['qty']) && $_POST['qty'] !== '' ? (int) $_POST['qty'] : null;
    $status = isset($_POST['is_active']) ? (int) $_POST['is_active'] : 1;

    if ($name === '') {
        $errors[] = 'Nama produk wajib diisi.';
    }

    if ($price === '' || !ctype_digit($price) || (int) $price <= 0) {
        $errors[] = 'Harga harus berupa angka positif.';
    }

    $uploadedFileName = null;
    if (isset($_FILES['image']) && $_FILES['image']['error'] !== UPLOAD_ERR_NO_FILE) {
        $file = $_FILES['image'];
        if ($file['error'] !== UPLOAD_ERR_OK) {
            $errors[] = 'Gagal mengunggah gambar. Error code: ' . $file['error'];
        } else {
            $allowedTypes = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/gif' => 'gif', 'image/webp' => 'webp'];
            $mime = mime_content_type($file['tmp_name']);
            if (!isset($allowedTypes[$mime])) {
                $errors[] = 'Format gambar harus JPG, PNG, GIF, atau WEBP.';
            } elseif ($file['size'] > 2 * 1024 * 1024) {
                $errors[] = 'Ukuran gambar maksimal 2MB.';
            } else {
                if (!is_dir($uploadDir)) {
                    if (!mkdir($uploadDir, 0777, true)) {
                        $errors[] = 'Tidak bisa membuat folder uploads. Pastikan folder uploads dapat ditulis.';
                    }
                }
                
                if (empty($errors)) {
                    if (!is_writable($uploadDir)) {
                        $errors[] = 'Folder uploads tidak dapat ditulis. Periksa permission folder.';
                    } else {
                        // Gunakan nama file asli
                        $originalName = pathinfo($file['name'], PATHINFO_FILENAME);
                        $originalExt = pathinfo($file['name'], PATHINFO_EXTENSION);
                        
                        // Sanitize nama file (hapus karakter berbahaya)
                        $originalName = preg_replace('/[^a-zA-Z0-9_-]/', '_', $originalName);
                        $originalName = trim($originalName, '_');
                        
                        // Jika nama kosong setelah sanitize, gunakan default
                        if ($originalName === '') {
                            $originalName = 'product_' . time();
                        }
                        
                        // Pastikan extension sesuai dengan mime type
                        $ext = $allowedTypes[$mime];
                        $filename = $originalName . '.' . $ext;
                        
                        // Jika file sudah ada, tambahkan angka
                        $counter = 1;
                        $baseFilename = $filename;
                        while (file_exists($uploadDir . '/' . $filename)) {
                            $filename = pathinfo($baseFilename, PATHINFO_FILENAME) . '_' . $counter . '.' . pathinfo($baseFilename, PATHINFO_EXTENSION);
                            $counter++;
                        }
                        
                        $destination = $uploadDir . '/' . $filename;
                        if (!move_uploaded_file($file['tmp_name'], $destination)) {
                            $errors[] = 'Tidak bisa menyimpan file gambar. Periksa permission folder uploads.';
                        } else {
                            $uploadedFileName = 'uploads/products/' . $filename;
                        }
                    }
                }
            }
        }
    }

    if (empty($errors)) {
        try {
            $pdo = getDbConnection();

            if ($code !== '') {
                if (productCodeExists($pdo, $code)) {
                    $errors[] = 'Kode produk sudah digunakan. Biarkan kosong untuk otomatis.';
                }
            }

            if (empty($errors)) {
                if ($code === '') {
                    $code = generateAutomaticProductCode($pdo);
                }

                $stmt = $pdo->prepare('INSERT INTO products (name, price, kode_product, is_active, gambar, qty) VALUES (:name, :price, :code, :status, :image, :qty)');
                $stmt->execute([
                    ':name' => $name,
                    ':price' => (int) $price,
                    ':code' => $code,
                    ':status' => $status,
                    ':image' => $uploadedFileName ?: null,
                    ':qty' => $qty,
                ]);

                $productId = (int) $pdo->lastInsertId();

                // Proses variants jika ada
                $variants = [];
                if (isset($_POST['variants']) && is_array($_POST['variants'])) {
                    foreach ($_POST['variants'] as $variantData) {
                        if (!isset($variantData['variant_name']) || trim($variantData['variant_name']) === '') {
                            continue; // Skip variant tanpa nama
                        }

                        $variantName = trim($variantData['variant_name']);
                        $variantPrice = isset($variantData['price']) && $variantData['price'] !== '' 
                            ? normalizeNumber($variantData['price']) 
                            : null;
                        $variantPrice = $variantPrice !== null ? (int) $variantPrice : null;
                        $variantSku = isset($variantData['sku']) && trim($variantData['sku']) !== '' 
                            ? trim($variantData['sku']) 
                            : null;
                        $variantStock = null;
                        if (isset($variantData['stock']) && $variantData['stock'] !== '') {
                            $stockValue = trim((string) $variantData['stock']);
                            if ($stockValue !== '') {
                                $variantStock = (int) $stockValue;
                            }
                        }
                        $variantStatus = isset($variantData['is_active']) 
                            ? normalizeStatus($variantData['is_active']) 
                            : 1;

                        $variants[] = [
                            'name' => $variantName,
                            'price' => $variantPrice,
                            'sku' => $variantSku,
                            'stock' => $variantStock,
                            'status' => $variantStatus,
                        ];
                    }
                }

                // Simpan variants ke database
                if (!empty($variants)) {
                    $variantStmt = $pdo->prepare('INSERT INTO product_variants (product_id, variant_name, price, sku, stock, is_active, created_at) VALUES (:product_id, :variant_name, :price, :sku, :stock, :is_active, NOW())');
                    
                    foreach ($variants as $variant) {
                        $variantStmt->execute([
                            ':product_id' => $productId,
                            ':variant_name' => $variant['name'],
                            ':price' => $variant['price'],
                            ':sku' => $variant['sku'],
                            ':stock' => $variant['stock'],
                            ':is_active' => $variant['status'],
                        ]);
                    }
                }

                $variantCount = count($variants);
                $successMessage = 'Produk berhasil ditambahkan!' . ($variantCount > 0 ? " ({$variantCount} variant ditambahkan)" : '');
                $_POST = [];
            }
        } catch (PDOException $exception) {
            $errors[] = 'Gagal menambahkan produk: ' . $exception->getMessage();
        }
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST' && $formType === 'import') {
    $file = $_FILES['import_file'] ?? null;
    $pasteData = isset($_POST['paste_data']) ? trim($_POST['paste_data']) : '';

    // Jika ada paste data, proses dari textarea
    if ($pasteData !== '') {
        try {
            // Parse data dari textarea (bisa tab-separated atau comma-separated)
            $lines = preg_split('/\r\n|\r|\n/', $pasteData);
            $rows = [];
            
            // Deteksi separator: cek baris pertama untuk menentukan apakah tab atau comma
            $firstLine = '';
            foreach ($lines as $line) {
                $line = trim($line);
                if ($line !== '') {
                    $firstLine = $line;
                    break;
                }
            }
            
            $useTab = false;
            if ($firstLine !== '') {
                // Jika ada tab di baris pertama, gunakan tab sebagai separator
                if (strpos($firstLine, "\t") !== false) {
                    $useTab = true;
                }
            }
            
            foreach ($lines as $line) {
                $line = rtrim($line); // Hanya trim di akhir, jangan di awal (bisa ada spasi di awal cell)
                if ($line === '') {
                    continue;
                }
                
                // Parse berdasarkan separator yang terdeteksi
                if ($useTab) {
                    // Tab-separated (dari Excel)
                    $row = str_getcsv($line, "\t");
                } else {
                    // Comma-separated
                    $row = str_getcsv($line);
                }
                
                // Filter empty rows
                $hasData = false;
                foreach ($row as $cell) {
                    if (trim($cell) !== '') {
                        $hasData = true;
                        break;
                    }
                }
                
                if ($hasData) {
                    $rows[] = $row;
                }
            }
            
            if (count($rows) < 2) {
                throw new RuntimeException('Data harus memiliki minimal 1 baris data setelah header.');
            }
            
            // Proses sama seperti import file
            $headers = array_shift($rows);
            $headerMap = mapHeaderIndexes($headers, [
                'name' => ['name', 'nama', 'nama produk', 'product name'],
                'price' => ['price', 'harga', 'price (idr)'],
                'code' => ['code', 'kode', 'kode produk', 'kode_product', 'product code'],
                'qty' => ['qty', 'stok', 'stock', 'quantity', 'jumlah'],
                'is_active' => ['status', 'is_active', 'aktif', 'active'],
                'gambar' => ['gambar', 'image', 'gambar produk', 'product image', 'img', 'picture'],
                'variant_name' => ['variant_name', 'variant name', 'nama varian', 'varian', 'variant'],
                'variant_price' => ['variant_price', 'variant price', 'harga varian', 'harga variant'],
                'variant_sku' => ['variant_sku', 'variant sku', 'sku varian', 'sku variant'],
                'variant_stock' => ['variant_stock', 'variant stock', 'stok varian', 'stok variant'],
                'variant_is_active' => ['variant_is_active', 'variant status', 'status varian', 'status variant'],
            ]);

            foreach (['name', 'price'] as $requiredField) {
                if (!isset($headerMap[$requiredField])) {
                    throw new RuntimeException(sprintf('Kolom "%s" wajib ada di header.', $requiredField));
                }
            }

            // Gunakan fungsi yang sama untuk proses data
            $pdo = getDbConnection();
            $insertStmt = $pdo->prepare('INSERT INTO products (name, price, kode_product, is_active, gambar, qty) VALUES (:name, :price, :code, :status, :image, :qty)');
            $variantStmt = $pdo->prepare('INSERT INTO product_variants (product_id, variant_name, price, sku, stock, is_active, created_at) VALUES (:product_id, :variant_name, :price, :sku, :stock, :is_active, NOW())');
            
            $importSummary = [
                'inserted' => 0,
                'skipped' => 0,
                'variants_inserted' => 0,
                'messages' => [],
            ];
            $localCodes = [];
            
            // Kelompokkan baris berdasarkan produk (nama produk + kode produk)
            $productsData = [];
            
            foreach ($rows as $index => $row) {
                $rowNumber = $index + 2; // Header berada pada baris 1
                $name = isset($row[$headerMap['name']]) ? trim((string) $row[$headerMap['name']]) : '';
                $priceRaw = isset($row[$headerMap['price']]) ? (string) $row[$headerMap['price']] : '';
                $priceClean = normalizeNumber($priceRaw);

                if ($name === '') {
                    $importSummary['skipped']++;
                    $importSummary['messages'][] = "Baris {$rowNumber}: Nama produk kosong.";
                    continue;
                }

                if ($priceClean === null || (int) $priceClean <= 0) {
                    $importSummary['skipped']++;
                    $importSummary['messages'][] = "Baris {$rowNumber}: Harga tidak valid.";
                    continue;
                }

                $price = (int) $priceClean;
                $code = isset($headerMap['code']) && isset($row[$headerMap['code']]) ? trim((string) $row[$headerMap['code']]) : '';
                
                // Key untuk grouping: gunakan nama produk (dan kode jika ada)
                if ($code === '') {
                    $productKey = strtoupper($name);
                } else {
                    $productKey = strtoupper($name . '|' . $code);
                }
                
                if (!isset($productsData[$productKey])) {
                    $productsData[$productKey] = [
                        'name' => $name,
                        'price' => $price,
                        'code' => $code,
                        'qty' => null,
                        'status' => 1,
                        'gambar' => null,
                        'variants' => [],
                        'row_number' => $rowNumber,
                    ];
                }
                
                // Ambil gambar jika ada (dari baris pertama produk, hanya set sekali)
                if ($productsData[$productKey]['gambar'] === null && isset($headerMap['gambar']) && isset($row[$headerMap['gambar']])) {
                    $gambarPath = trim((string) $row[$headerMap['gambar']]);
                    if ($gambarPath !== '') {
                        $gambarPath = str_replace('\\', '/', $gambarPath);
                        $gambarPath = ltrim($gambarPath, '/');
                        
                        // Normalize path: jika tidak ada prefix uploads/products, tambahkan
                        if (strpos($gambarPath, 'uploads/products/') !== 0) {
                            if (strpos($gambarPath, '/') === false) {
                                // Hanya nama file, tambahkan prefix
                                $gambarPath = 'uploads/products/' . $gambarPath;
                            }
                        }
                        
                        // Simpan path gambar (meskipun file belum ada, akan divalidasi nanti)
                        $productsData[$productKey]['gambar'] = $gambarPath;
                    }
                }
                
                // Ambil data variant jika ada
                $variantName = isset($headerMap['variant_name']) && isset($row[$headerMap['variant_name']]) 
                    ? trim((string) $row[$headerMap['variant_name']]) 
                    : '';
                
                if ($variantName !== '') {
                    $variantPrice = null;
                    if (isset($headerMap['variant_price']) && isset($row[$headerMap['variant_price']])) {
                        $variantPriceRaw = (string) $row[$headerMap['variant_price']];
                        $variantPriceClean = normalizeNumber($variantPriceRaw);
                        $variantPrice = $variantPriceClean !== null ? (int) $variantPriceClean : null;
                    }
                    
                    $variantSku = isset($headerMap['variant_sku']) && isset($row[$headerMap['variant_sku']]) 
                        ? trim((string) $row[$headerMap['variant_sku']]) 
                        : null;
                    
                    $variantStock = null;
                    if (isset($headerMap['variant_stock']) && isset($row[$headerMap['variant_stock']])) {
                        $variantStockRaw = trim((string) $row[$headerMap['variant_stock']]);
                        if ($variantStockRaw !== '') {
                            $variantStockClean = normalizeNumber($variantStockRaw);
                            $variantStock = $variantStockClean !== null ? (int) $variantStockClean : null;
                        }
                    }
                    
                    $variantStatus = 1;
                    if (isset($headerMap['variant_is_active']) && isset($row[$headerMap['variant_is_active']])) {
                        $variantStatus = normalizeStatus($row[$headerMap['variant_is_active']]);
                    }
                    
                    $productsData[$productKey]['variants'][] = [
                        'name' => $variantName,
                        'price' => $variantPrice,
                        'sku' => $variantSku,
                        'stock' => $variantStock,
                        'status' => $variantStatus,
                    ];
                }
                
                // Update qty dan status dari baris pertama (atau baris terakhir jika ada variant)
                if (isset($headerMap['qty']) && isset($row[$headerMap['qty']])) {
                    $qtyClean = normalizeNumber((string) $row[$headerMap['qty']]);
                    if ($qtyClean !== null) {
                        $productsData[$productKey]['qty'] = (int) $qtyClean;
                    }
                }
                
                if (isset($headerMap['is_active']) && isset($row[$headerMap['is_active']])) {
                    $productsData[$productKey]['status'] = normalizeStatus($row[$headerMap['is_active']]);
                }
            }
            
            // Proses setiap produk
            foreach ($productsData as $productData) {
                $rowNumber = $productData['row_number'];
                $name = $productData['name'];
                $price = $productData['price'];
                $code = $productData['code'];
                
                // Jika kode kosong, generate kode otomatis
                if ($code === '') {
                    $code = generateAutomaticProductCode($pdo);
                } else {
                    // Validasi kode
                    if (!preg_match('/^[A-Za-z0-9._-]+$/', $code)) {
                        $importSummary['skipped']++;
                        $importSummary['messages'][] = "Baris {$rowNumber}: Kode produk hanya boleh berisi huruf, angka, titik, strip, atau underscore.";
                        continue;
                    }
                    
                    $normalizedCode = strtoupper($code);
                    if (isset($localCodes[$normalizedCode])) {
                        $importSummary['skipped']++;
                        $importSummary['messages'][] = "Baris {$rowNumber}: Kode produk duplikat di file import.";
                        continue;
                    }
                    
                    if (productCodeExists($pdo, $code)) {
                        $importSummary['skipped']++;
                        $importSummary['messages'][] = "Baris {$rowNumber}: Kode produk sudah terpakai di database.";
                        continue;
                    }
                    
                    $localCodes[$normalizedCode] = true;
                }
                
                try {
                    // Ambil path gambar dari productData
                    $gambarPath = $productData['gambar'];
                    
                    // Validasi gambar jika ada (tapi tetap simpan path meskipun file belum ada)
                    if ($gambarPath !== null && $gambarPath !== '') {
                        $fullPath = __DIR__ . '/' . $gambarPath;
                        if (!file_exists($fullPath) || !is_file($fullPath)) {
                            $importSummary['messages'][] = "Baris {$rowNumber}: File gambar tidak ditemukan: {$gambarPath} (path tetap disimpan)";
                            // Tetap simpan path meskipun file belum ada
                        }
                    }
                    
                    // Insert produk
                    $insertStmt->execute([
                        ':name' => $name,
                        ':price' => $price,
                        ':code' => $code,
                        ':status' => $productData['status'],
                        ':image' => $gambarPath,
                        ':qty' => $productData['qty'],
                    ]);
                    
                    $productId = (int) $pdo->lastInsertId();
                    $importSummary['inserted']++;
                    
                    // Insert variants jika ada
                    if (!empty($productData['variants'])) {
                        foreach ($productData['variants'] as $variant) {
                            $variantStmt->execute([
                                ':product_id' => $productId,
                                ':variant_name' => $variant['name'],
                                ':price' => $variant['price'],
                                ':sku' => $variant['sku'],
                                ':stock' => $variant['stock'],
                                ':is_active' => $variant['status'],
                            ]);
                            $importSummary['variants_inserted']++;
                        }
                    }
                } catch (PDOException $e) {
                    $importSummary['skipped']++;
                    $importSummary['messages'][] = "Baris {$rowNumber}: Gagal disimpan ({$e->getMessage()}).";
                }
            }

            if ($importSummary['inserted'] > 0) {
                $variantMsg = $importSummary['variants_inserted'] > 0 
                    ? sprintf(' (%d variant ditambahkan)', $importSummary['variants_inserted']) 
                    : '';
                $successMessage = sprintf('%d produk berhasil diimpor%s.', $importSummary['inserted'], $variantMsg);
            }

            if ($importSummary['inserted'] === 0 && $importSummary['skipped'] === 0) {
                $errors[] = 'Tidak ada data yang diproses.';
                $importSummary = null;
            }

            $_POST = [];
        } catch (RuntimeException $exception) {
            $errors[] = $exception->getMessage();
        }
    } elseif ($file === null || $file['error'] === UPLOAD_ERR_NO_FILE) {
        $errors[] = 'Pilih file Excel/CSV atau paste data dari Excel.';
    } elseif ($file['error'] !== UPLOAD_ERR_OK) {
        $errors[] = 'Gagal mengunggah file import. Error code: ' . $file['error'];
    } else {
        $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $allowedExtensions = ['xlsx', 'csv'];

        if (!in_array($extension, $allowedExtensions, true)) {
            $errors[] = 'Format file harus XLSX atau CSV.';
        } else {
            try {
                $rows = getSpreadsheetRows($file['tmp_name'], $extension);

                if (count($rows) < 2) {
                    throw new RuntimeException('File harus memiliki minimal 1 baris data setelah header.');
                }

                $headers = array_shift($rows);
                $headerMap = mapHeaderIndexes($headers, [
                    'name' => ['name', 'nama', 'nama produk', 'product name'],
                    'price' => ['price', 'harga', 'price (idr)'],
                    'code' => ['code', 'kode', 'kode produk', 'kode_product', 'product code'],
                    'qty' => ['qty', 'stok', 'stock', 'quantity', 'jumlah'],
                    'is_active' => ['status', 'is_active', 'aktif', 'active'],
                    'gambar' => ['gambar', 'image', 'gambar produk', 'product image', 'img', 'picture'],
                    'variant_name' => ['variant_name', 'variant name', 'nama varian', 'varian', 'variant'],
                    'variant_price' => ['variant_price', 'variant price', 'harga varian', 'harga variant'],
                    'variant_sku' => ['variant_sku', 'variant sku', 'sku varian', 'sku variant'],
                    'variant_stock' => ['variant_stock', 'variant stock', 'stok varian', 'stok variant'],
                    'variant_is_active' => ['variant_is_active', 'variant status', 'status varian', 'status variant'],
                ]);

                foreach (['name', 'price'] as $requiredField) {
                    if (!isset($headerMap[$requiredField])) {
                        throw new RuntimeException(sprintf('Kolom "%s" wajib ada di header.', $requiredField));
                    }
                }

                $pdo = getDbConnection();
                $insertStmt = $pdo->prepare('INSERT INTO products (name, price, kode_product, is_active, gambar, qty) VALUES (:name, :price, :code, :status, :image, :qty)');
                $variantStmt = $pdo->prepare('INSERT INTO product_variants (product_id, variant_name, price, sku, stock, is_active, created_at) VALUES (:product_id, :variant_name, :price, :sku, :stock, :is_active, NOW())');
                
                $importSummary = [
                    'inserted' => 0,
                    'skipped' => 0,
                    'variants_inserted' => 0,
                    'messages' => [],
                ];
                $localCodes = [];
                
                // Kelompokkan baris berdasarkan produk (nama produk + kode produk)
                $productsData = [];

                foreach ($rows as $index => $row) {
                    $rowNumber = $index + 2; // Header berada pada baris 1
                    $name = isset($row[$headerMap['name']]) ? trim((string) $row[$headerMap['name']]) : '';
                    $priceRaw = isset($row[$headerMap['price']]) ? (string) $row[$headerMap['price']] : '';
                    $priceClean = normalizeNumber($priceRaw);

                    if ($name === '') {
                        $importSummary['skipped']++;
                        $importSummary['messages'][] = "Baris {$rowNumber}: Nama produk kosong.";
                        continue;
                    }

                    if ($priceClean === null || (int) $priceClean <= 0) {
                        $importSummary['skipped']++;
                        $importSummary['messages'][] = "Baris {$rowNumber}: Harga tidak valid.";
                        continue;
                    }

                    $price = (int) $priceClean;
                    $code = isset($headerMap['code']) && isset($row[$headerMap['code']]) ? trim((string) $row[$headerMap['code']]) : '';

                    // Key untuk grouping: gunakan nama produk (dan kode jika ada)
                    // Jika kode kosong, semua baris dengan nama yang sama akan di-group
                    // Jika kode ada, gunakan nama+kode sebagai key
                    if ($code === '') {
                        $productKey = strtoupper($name);
                    } else {
                        $productKey = strtoupper($name . '|' . $code);
                    }
                    
                    if (!isset($productsData[$productKey])) {
                        $productsData[$productKey] = [
                            'name' => $name,
                            'price' => $price,
                            'code' => $code,
                            'qty' => null,
                            'status' => 1,
                            'gambar' => null,
                            'variants' => [],
                            'row_number' => $rowNumber,
                        ];
                    }
                    
                    // Ambil gambar jika ada (dari baris pertama produk, hanya set sekali)
                    if ($productsData[$productKey]['gambar'] === null && isset($headerMap['gambar']) && isset($row[$headerMap['gambar']])) {
                        $gambarPath = trim((string) $row[$headerMap['gambar']]);
                        if ($gambarPath !== '') {
                            // Normalize path: pastikan menggunakan forward slash
                            $gambarPath = str_replace('\\', '/', $gambarPath);
                            
                            // Normalize: hapus leading slash jika ada
                            $gambarPath = ltrim($gambarPath, '/');
                            
                            // Normalize path: jika tidak ada prefix uploads/products, tambahkan
                            if (strpos($gambarPath, 'uploads/products/') !== 0) {
                                if (strpos($gambarPath, '/') === false) {
                                    // Hanya nama file, tambahkan prefix
                                    $gambarPath = 'uploads/products/' . $gambarPath;
                                }
                            }
                            
                            // Simpan path gambar (meskipun file belum ada, akan divalidasi nanti)
                            $productsData[$productKey]['gambar'] = $gambarPath;
                        }
                    }
                    
                    // Ambil data variant jika ada
                    $variantName = isset($headerMap['variant_name']) && isset($row[$headerMap['variant_name']]) 
                        ? trim((string) $row[$headerMap['variant_name']]) 
                        : '';
                    
                    if ($variantName !== '') {
                        $variantPrice = null;
                        if (isset($headerMap['variant_price']) && isset($row[$headerMap['variant_price']])) {
                            $variantPriceRaw = (string) $row[$headerMap['variant_price']];
                            $variantPriceClean = normalizeNumber($variantPriceRaw);
                            $variantPrice = $variantPriceClean !== null ? (int) $variantPriceClean : null;
                        }
                        
                        $variantSku = isset($headerMap['variant_sku']) && isset($row[$headerMap['variant_sku']]) 
                            ? trim((string) $row[$headerMap['variant_sku']]) 
                            : null;
                        
                        $variantStock = null;
                        if (isset($headerMap['variant_stock']) && isset($row[$headerMap['variant_stock']])) {
                            $variantStockRaw = trim((string) $row[$headerMap['variant_stock']]);
                            if ($variantStockRaw !== '') {
                                $variantStockClean = normalizeNumber($variantStockRaw);
                                $variantStock = $variantStockClean !== null ? (int) $variantStockClean : null;
                            }
                        }
                        
                        $variantStatus = 1;
                        if (isset($headerMap['variant_is_active']) && isset($row[$headerMap['variant_is_active']])) {
                            $variantStatus = normalizeStatus($row[$headerMap['variant_is_active']]);
                        }
                        
                        $productsData[$productKey]['variants'][] = [
                            'name' => $variantName,
                            'price' => $variantPrice,
                            'sku' => $variantSku,
                            'stock' => $variantStock,
                            'status' => $variantStatus,
                        ];
                    }
                    
                    // Update qty dan status dari baris pertama (atau baris terakhir jika ada variant)
                    if (isset($headerMap['qty']) && isset($row[$headerMap['qty']])) {
                        $qtyClean = normalizeNumber((string) $row[$headerMap['qty']]);
                        if ($qtyClean !== null) {
                            $productsData[$productKey]['qty'] = (int) $qtyClean;
                        }
                    }
                    
                    if (isset($headerMap['is_active']) && isset($row[$headerMap['is_active']])) {
                        $productsData[$productKey]['status'] = normalizeStatus($row[$headerMap['is_active']]);
                    }
                }
                
                // Proses setiap produk
                foreach ($productsData as $productData) {
                    $rowNumber = $productData['row_number'];
                    $name = $productData['name'];
                    $price = $productData['price'];
                    $code = $productData['code'];
                    
                    // Jika kode kosong, generate kode otomatis
                    if ($code === '') {
                        $code = generateAutomaticProductCode($pdo);
                    } else {
                        // Validasi kode
                        if (!preg_match('/^[A-Za-z0-9._-]+$/', $code)) {
                            $importSummary['skipped']++;
                            $importSummary['messages'][] = "Baris {$rowNumber}: Kode produk hanya boleh berisi huruf, angka, titik, strip, atau underscore.";
                            continue;
                        }

                        $normalizedCode = strtoupper($code);
                        if (isset($localCodes[$normalizedCode])) {
                            $importSummary['skipped']++;
                            $importSummary['messages'][] = "Baris {$rowNumber}: Kode produk duplikat di file import.";
                            continue;
                        }

                        if (productCodeExists($pdo, $code)) {
                            $importSummary['skipped']++;
                            $importSummary['messages'][] = "Baris {$rowNumber}: Kode produk sudah terpakai di database.";
                            continue;
                        }

                        $localCodes[$normalizedCode] = true;
                    }
                    
                    try {
                        // Ambil path gambar dari productData
                        $gambarPath = $productData['gambar'];
                        
                        // Validasi gambar jika ada (tapi tetap simpan path meskipun file belum ada)
                        if ($gambarPath !== null && $gambarPath !== '') {
                            $fullPath = __DIR__ . '/' . $gambarPath;
                            if (!file_exists($fullPath) || !is_file($fullPath)) {
                                $importSummary['messages'][] = "Baris {$rowNumber}: File gambar tidak ditemukan: {$gambarPath} (path tetap disimpan)";
                                // Tetap simpan path meskipun file belum ada
                            }
                        }
                        
                        // Insert produk
                        $insertStmt->execute([
                            ':name' => $name,
                            ':price' => $price,
                            ':code' => $code,
                            ':status' => $productData['status'],
                            ':image' => $gambarPath,
                            ':qty' => $productData['qty'],
                        ]);

                        $productId = (int) $pdo->lastInsertId();
                        $importSummary['inserted']++;
                        
                        // Insert variants jika ada
                        if (!empty($productData['variants'])) {
                            foreach ($productData['variants'] as $variant) {
                                $variantStmt->execute([
                                    ':product_id' => $productId,
                                    ':variant_name' => $variant['name'],
                                    ':price' => $variant['price'],
                                    ':sku' => $variant['sku'],
                                    ':stock' => $variant['stock'],
                                    ':is_active' => $variant['status'],
                                ]);
                                $importSummary['variants_inserted']++;
                            }
                        }
                    } catch (PDOException $e) {
                        $importSummary['skipped']++;
                        $importSummary['messages'][] = "Baris {$rowNumber}: Gagal disimpan ({$e->getMessage()}).";
                    }
                }

                if ($importSummary['inserted'] > 0) {
                    $variantMsg = $importSummary['variants_inserted'] > 0 
                        ? sprintf(' (%d variant ditambahkan)', $importSummary['variants_inserted']) 
                        : '';
                    $successMessage = sprintf('%d produk berhasil diimpor%s.', $importSummary['inserted'], $variantMsg);
                }

                if ($importSummary['inserted'] === 0 && $importSummary['skipped'] === 0) {
                    $errors[] = 'Tidak ada data yang diproses.';
                    $importSummary = null;
                }

                $_POST = [];
            } catch (RuntimeException $exception) {
                $errors[] = $exception->getMessage();
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Produk Baru</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="page narrow">
        <header class="hero hero-compact">
            <div>
                <p class="eyebrow">New Product</p>
                <h1>Tambah Produk Voucher</h1>
                <p class="subtitle">Masukkan nama paket, harga, dan kode (opsional). Produk bisa diaktifkan/nonaktifkan sewaktu-waktu.</p>
                <div style="margin-top: 1rem;">
                    <a href="editproduct.php" class="btn btn-secondary" style="display: inline-flex; align-items: center; gap: 0.5rem;">
                        ✏️ Edit Produk
                    </a>
                </div>
            </div>
            <div class="hero-card">
                <p>Harga Default</p>
                <strong>Rp 70K</strong>
                <small>Dapat disesuaikan</small>
            </div>
        </header>

        <section class="form-card">
            <?php foreach ($errors as $error) : ?>
                <div class="feedback error"><?= htmlspecialchars($error) ?></div>
            <?php endforeach; ?>

            <?php if ($successMessage !== null) : ?>
                <div class="feedback success"><?= htmlspecialchars($successMessage) ?></div>
            <?php endif; ?>

            <form method="post" class="form-grid" enctype="multipart/form-data">
                <input type="hidden" name="form_type" value="single">
                <div class="form-group">
                    <label for="name">Nama Produk</label>
                    <input
                        type="text"
                        class="form-control"
                        id="name"
                        name="name"
                        placeholder="Contoh: Paket Gift 70K"
                        value="<?= isset($_POST['name']) ? htmlspecialchars($_POST['name']) : '' ?>"
                        required
                    >
                </div>

                <div class="form-group">
                    <label for="price">Harga Produk</label>
                    <input
                        type="number"
                        min="1000"
                        step="1000"
                        class="form-control"
                        id="price"
                        name="price"
                        placeholder="Contoh: 70000"
                        value="<?= isset($_POST['price']) ? htmlspecialchars($_POST['price']) : '' ?>"
                        required
                    >
                    <small>Masukkan angka tanpa titik/koma.</small>
                </div>

                <div class="form-group">
                    <label for="qty">Quantity / Stok (opsional)</label>
                    <input
                        type="number"
                        min="0"
                        class="form-control"
                        id="qty"
                        name="qty"
                        placeholder="Contoh: 100"
                        value="<?= isset($_POST['qty']) && $_POST['qty'] !== '' ? htmlspecialchars($_POST['qty']) : '' ?>"
                    >
                    <small>Jumlah stok produk. Biarkan kosong jika tidak perlu.</small>
                </div>

                <div class="form-group">
                    <label for="code">Kode Produk (opsional)</label>
                    <input
                        type="text"
                        class="form-control"
                        id="code"
                        name="code"
                        placeholder="Contoh: PKT70"
                        value="<?= isset($_POST['code']) ? htmlspecialchars($_POST['code']) : '' ?>"
                    >
                    <small>Biarkan kosong untuk kode otomatis.</small>
                </div>

                <div class="form-group">
                    <label>Status Produk</label>
                    <select class="form-control" name="is_active">
                        <option value="1" <?= (isset($_POST['is_active']) ? (int) $_POST['is_active'] === 1 : true) ? 'selected' : '' ?>>Aktif</option>
                        <option value="0" <?= isset($_POST['is_active']) && (int) $_POST['is_active'] === 0 ? 'selected' : '' ?>>Nonaktif</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="image">Gambar Produk (opsional)</label>
                    <input type="file" id="image" name="image" class="form-control" accept="image/*">
                    <small>Format: JPG, PNG, GIF, WEBP. Maksimal 2MB.</small>
                    <div id="imagePreview" class="image-preview" style="display: none;">
                        <img id="previewImg" src="" alt="Preview">
                        <button type="button" id="removePreview" class="btn-remove-preview">×</button>
                    </div>
                </div>

                <div class="form-group">
                    <label>Varian Produk (opsional)</label>
                    <div id="variantsContainer">
                        <!-- Variants will be added here dynamically -->
                    </div>
                    <button type="button" id="addVariantBtn" class="btn btn-secondary" style="margin-top: 0.5rem;">+ Tambah Varian</button>
                    <small>Tambahkan varian produk jika produk memiliki beberapa pilihan (contoh: Ukuran, Warna, dll).</small>
                </div>

                <div class="form-actions">
                    <a class="btn btn-secondary" href="index.php">Kembali</a>
                    <button class="btn btn-primary" type="submit">Simpan Produk</button>
                </div>
            </form>
        </section>

        <section class="form-card">
            <header>
                <h2>Import Produk dari Excel/CSV</h2>
                <p>Gunakan template berikut untuk menambahkan produk secara massal.</p>
            </header>
            <p>
                <a class="btn btn-secondary" href="templates/products_import_template.csv" download>
                    Unduh Template CSV
                </a>
            </p>

            <?php if ($importSummary !== null) : ?>
                <div class="feedback info">
                    <strong>Hasil Import:</strong>
                    <p><?= htmlspecialchars($importSummary['inserted']) ?> baris berhasil, <?= htmlspecialchars($importSummary['skipped']) ?> baris dilewati.</p>
                    <?php if (!empty($importSummary['messages'])) : ?>
                        <ul>
                            <?php foreach ($importSummary['messages'] as $message) : ?>
                                <li><?= htmlspecialchars($message) ?></li>
                            <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <form method="post" class="form-grid" enctype="multipart/form-data" id="importForm">
                <input type="hidden" name="form_type" value="import">
                
                <div class="form-group">
                    <label>Paste Data dari Excel (Alternatif)</label>
                    <textarea
                        class="form-control"
                        id="paste_data"
                        name="paste_data"
                        rows="8"
                        placeholder="Copy data dari Excel (termasuk header) dan paste di sini. Data akan otomatis terdeteksi sebagai tab-separated atau comma-separated."
                        style="font-family: monospace; font-size: 0.9rem;"
                    ><?= isset($_POST['paste_data']) ? htmlspecialchars($_POST['paste_data']) : '' ?></textarea>
                    <small><strong>Tips:</strong> Copy seluruh data dari Excel (termasuk header baris pertama) dan paste di textarea ini. Format akan otomatis terdeteksi.</small>
                </div>
                
                <div style="text-align: center; margin: 1rem 0; color: var(--muted); font-weight: 600;">ATAU</div>
                
                <div class="form-group">
                    <label for="import_file">Upload File Excel/CSV</label>
                    <input
                        type="file"
                        class="form-control"
                        id="import_file"
                        name="import_file"
                        accept=".xlsx,.csv"
                    >
                    <small>Format header wajib: name, price. Opsional: code, qty, is_active, gambar, variant_name, variant_price, variant_sku, variant_stock, variant_is_active.<br>
                    <strong>Tips:</strong> Untuk produk dengan variant, buat beberapa baris dengan nama produk yang sama. Setiap baris = satu variant.<br>
                    <strong>Gambar:</strong> Isi path ke file gambar yang sudah diupload ke folder uploads/products/ (contoh: uploads/products/namafile.jpg)</small>
                </div>
                <div class="form-actions">
                    <button class="btn btn-primary" type="submit">Import Produk</button>
                </div>
            </form>
            
            <script>
                // Validasi form: pastikan salah satu diisi
                document.getElementById('importForm').addEventListener('submit', function(e) {
                    var pasteData = document.getElementById('paste_data').value.trim();
                    var fileInput = document.getElementById('import_file');
                    var hasFile = fileInput.files.length > 0;
                    
                    if (pasteData === '' && !hasFile) {
                        e.preventDefault();
                        alert('Pilih file Excel/CSV atau paste data dari Excel.');
                        return false;
                    }
                    
                    // Jika ada paste data, hapus required dari file input
                    if (pasteData !== '') {
                        fileInput.removeAttribute('required');
                    } else {
                        fileInput.setAttribute('required', 'required');
                    }
                });
            </script>
        </section>
    </div>

    <button class="fab" id="fabButton" type="button">+</button>
    <div class="fab-menu" id="fabMenu">
        <a class="fab-item dashboard" href="index.php" title="Dashboard">🏠</a>
        <a class="fab-item new-guest" href="new_guest.php" title="New Guest">➕</a>
        <a class="fab-item products" href="new_product.php" title="New Product">🛍️</a>
        <a class="fab-item edit-products" href="editproduct.php" title="Edit Products">✏️</a>
    </div>
    <script>
        (function () {
            var fabButton = document.getElementById('fabButton');
            var fabMenu = document.getElementById('fabMenu');

            var toggleMenu = function () {
                if (!fabMenu || !fabButton) {
                    return;
                }
                fabMenu.classList.toggle('open');
                fabButton.classList.toggle('open');
            };

            if (fabButton) {
                fabButton.addEventListener('click', toggleMenu);
            }

            // Image preview
            var imageInput = document.getElementById('image');
            var imagePreview = document.getElementById('imagePreview');
            var previewImg = document.getElementById('previewImg');
            var removePreview = document.getElementById('removePreview');

            if (imageInput && imagePreview && previewImg) {
                imageInput.addEventListener('change', function (e) {
                    var file = e.target.files[0];
                    if (file) {
                        if (file.type.match('image.*')) {
                            var reader = new FileReader();
                            reader.onload = function (e) {
                                previewImg.src = e.target.result;
                                imagePreview.style.display = 'block';
                            };
                            reader.readAsDataURL(file);
                        } else {
                            alert('File harus berupa gambar.');
                            imageInput.value = '';
                        }
                    }
                });

                if (removePreview) {
                    removePreview.addEventListener('click', function () {
                        imagePreview.style.display = 'none';
                        previewImg.src = '';
                        imageInput.value = '';
                    });
                }
            }

            // Variants management
            var variantsContainer = document.getElementById('variantsContainer');
            var addVariantBtn = document.getElementById('addVariantBtn');
            var variantCounter = 0;

            function addVariantRow() {
                variantCounter++;
                var variantRow = document.createElement('div');
                variantRow.className = 'variant-row';
                variantRow.style.cssText = 'border: 1px solid #e0e0e0; padding: 1rem; margin-bottom: 0.75rem; border-radius: 8px; background: #f9f9f9;';
                
                variantRow.innerHTML = 
                    '<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 0.75rem; margin-bottom: 0.75rem;">' +
                        '<div>' +
                            '<label style="display: block; margin-bottom: 0.25rem; font-size: 0.875rem; font-weight: 500;">Nama Varian *</label>' +
                            '<input type="text" name="variants[' + variantCounter + '][variant_name]" class="form-control" placeholder="Contoh: Ukuran S, Warna Merah" required>' +
                        '</div>' +
                        '<div>' +
                            '<label style="display: block; margin-bottom: 0.25rem; font-size: 0.875rem; font-weight: 500;">Harga (opsional)</label>' +
                            '<input type="number" name="variants[' + variantCounter + '][price]" class="form-control" placeholder="Kosongkan jika sama dengan harga produk" min="0" step="1000">' +
                        '</div>' +
                    '</div>' +
                    '<div style="display: grid; grid-template-columns: 1fr 1fr 1fr auto; gap: 0.75rem; align-items: end;">' +
                        '<div>' +
                            '<label style="display: block; margin-bottom: 0.25rem; font-size: 0.875rem; font-weight: 500;">SKU (opsional)</label>' +
                            '<input type="text" name="variants[' + variantCounter + '][sku]" class="form-control" placeholder="Kode SKU">' +
                        '</div>' +
                        '<div>' +
                            '<label style="display: block; margin-bottom: 0.25rem; font-size: 0.875rem; font-weight: 500;">Stok</label>' +
                            '<input type="number" name="variants[' + variantCounter + '][stock]" class="form-control" value="0" min="0">' +
                        '</div>' +
                        '<div>' +
                            '<label style="display: block; margin-bottom: 0.25rem; font-size: 0.875rem; font-weight: 500;">Status</label>' +
                            '<select name="variants[' + variantCounter + '][is_active]" class="form-control">' +
                                '<option value="1">Aktif</option>' +
                                '<option value="0">Nonaktif</option>' +
                            '</select>' +
                        '</div>' +
                        '<div>' +
                            '<button type="button" class="btn-remove-variant" style="background: #dc3545; color: white; border: none; padding: 0.5rem 1rem; border-radius: 4px; cursor: pointer; font-size: 0.875rem;">Hapus</button>' +
                        '</div>' +
                    '</div>';

                variantsContainer.appendChild(variantRow);

                // Add remove functionality
                var removeBtn = variantRow.querySelector('.btn-remove-variant');
                removeBtn.addEventListener('click', function() {
                    variantRow.remove();
                });
            }

            if (addVariantBtn && variantsContainer) {
                addVariantBtn.addEventListener('click', addVariantRow);
            }
        })();
    </script>
</body>
</html>

