<?php
declare(strict_types=1);

header('Content-Type: application/json');

require_once __DIR__ . '/config.php';

use PDO;
use PDOException;

$response = ['success' => false, 'message' => '', 'voucher' => null];

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    $response['message'] = 'Method not allowed';
    echo json_encode($response);
    exit;
}

$voucherCode = isset($_POST['voucher_code']) ? trim($_POST['voucher_code']) : '';
$userId = isset($_POST['user_id']) ? (int) $_POST['user_id'] : 0;

if (empty($voucherCode)) {
    $response['message'] = 'Kode voucher tidak boleh kosong.';
    echo json_encode($response);
    exit;
}

if ($userId <= 0) {
    $response['message'] = 'ID user tidak valid.';
    echo json_encode($response);
    exit;
}

try {
    $pdo = getDbConnection();
    
    // Cari voucher berdasarkan kode
    $voucherStmt = $pdo->prepare('SELECT id, code, value, owner_user_id, status FROM vouchers WHERE code = :code LIMIT 1');
    $voucherStmt->execute([':code' => $voucherCode]);
    $voucher = $voucherStmt->fetch();
    
    if (!$voucher) {
        $response['message'] = 'Kode voucher tidak ditemukan.';
        echo json_encode($response);
        exit;
    }
    
    // Cek apakah voucher sudah digunakan
    if ($voucher['status'] !== 'unused') {
        $response['message'] = 'Voucher sudah digunakan atau tidak tersedia.';
        echo json_encode($response);
        exit;
    }
    
    // Voucher valid, kembalikan data voucher
    $response['success'] = true;
    $response['message'] = 'Voucher berhasil ditambahkan.';
    $response['voucher'] = [
        'id' => (int) $voucher['id'],
        'code' => $voucher['code'],
        'value' => (int) $voucher['value'],
        'owner_user_id' => (int) $voucher['owner_user_id'],
    ];
    
} catch (PDOException $exception) {
    $response['message'] = 'Gagal memproses voucher: ' . $exception->getMessage();
}

echo json_encode($response);

