<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';

use PDO;
use PDOException;

$search = isset($_GET['q']) ? trim($_GET['q']) : '';
$recapData = [];
$dbError = null;
$currentPage = 'recap';

try {
    $pdo = getDbConnection();
    
    // Query untuk mendapatkan semua data rekapitulasi
    $sql = 'SELECT 
                u.id,
                u.name,
                u.branch,
                u.no_hp,
                u.attendance_status,
                u.attendance_at,
                u.voucher_code,
                COUNT(DISTINCT t.id) as jumlah_produk_dibeli,
                COALESCE(SUM(t.total_price), 0) as total_rp_transaksi,
                COALESCE(SUM(t.extra_charge), 0) as total_kurang_bayar
            FROM users u
            LEFT JOIN transactions t ON t.user_id = u.id';
    
    $params = [];
    $conditions = [];
    
    // Filter berdasarkan search
    if ($search !== '') {
        $conditions[] = '(u.name LIKE :search OR u.branch LIKE :search OR u.voucher_code LIKE :search OR u.no_hp LIKE :search OR CAST(u.id AS CHAR) LIKE :search)';
        $params[':search'] = '%' . $search . '%';
    }
    
    if (!empty($conditions)) {
        $sql .= ' WHERE ' . implode(' AND ', $conditions);
    }
    
    $sql .= ' GROUP BY u.id, u.name, u.branch, u.no_hp, u.attendance_status, u.attendance_at, u.voucher_code
              ORDER BY u.name COLLATE utf8mb4_unicode_ci ASC';
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $recapData = $stmt->fetchAll();
    
    // Untuk setiap user, cek detail voucher dan produk yang dibeli
    foreach ($recapData as &$row) {
        $userId = (int) $row['id'];
        
        // Ambil semua voucher user dan cek apakah dipakai oleh user lain
        $voucherStmt = $pdo->prepare('
            SELECT 
                v.id,
                v.code,
                v.status,
                v.owner_user_id,
                t.user_id as transaction_user_id
            FROM vouchers v
            LEFT JOIN transaction_vouchers tv ON tv.voucher_id = v.id
            LEFT JOIN transactions t ON t.id = tv.transaction_id
            WHERE v.owner_user_id = :user_id
            ORDER BY v.created_at ASC
        ');
        $voucherStmt->execute([':user_id' => $userId]);
        $vouchers = $voucherStmt->fetchAll();
        
        // Tentukan status voucher
        $voucherStatus = 'Tidak Terpakai';
        $voucherDetail = [];
        $hasUsedBySelf = false;
        $hasUsedByOthers = false;
        
        foreach ($vouchers as $voucher) {
            if ($voucher['status'] === 'used') {
                $transactionUserId = $voucher['transaction_user_id'] ? (int) $voucher['transaction_user_id'] : null;
                
                if ($transactionUserId && $transactionUserId !== $userId) {
                    // Voucher dipakai oleh user lain
                    $hasUsedByOthers = true;
                    $voucherDetail[] = $voucher['code'] . ' (dipakai oleh user lain)';
                } else {
                    // Voucher dipakai sendiri
                    $hasUsedBySelf = true;
                    $voucherDetail[] = $voucher['code'];
                }
            } else {
                $voucherDetail[] = $voucher['code'] . ' (belum terpakai)';
            }
        }
        
        // Tentukan status utama
        if ($hasUsedByOthers) {
            $voucherStatus = 'Dipakai untuk Referral';
        } elseif ($hasUsedBySelf) {
            $voucherStatus = 'Terpakai';
        } else {
            $voucherStatus = 'Tidak Terpakai';
        }
        
        // Ambil produk yang dibeli oleh user beserta variant-nya dan notes
        $productStmt = $pdo->prepare('
            SELECT DISTINCT 
                p.name as product_name,
                pv.variant_name,
                t.variant_id,
                t.notes
            FROM transactions t
            INNER JOIN products p ON t.product_id = p.id
            LEFT JOIN product_variants pv ON t.variant_id = pv.id
            WHERE t.user_id = :user_id
            ORDER BY p.name ASC, pv.variant_name ASC
        ');
        $productStmt->execute([':user_id' => $userId]);
        $products = $productStmt->fetchAll();
        
        // Format nama produk dengan variant dan notes
        $productNames = [];
        foreach ($products as $product) {
            $productName = $product['product_name'];
            $variantName = !empty($product['variant_name']) ? $product['variant_name'] : null;
            $notes = !empty($product['notes']) ? $product['notes'] : null;
            
            $productNames[] = [
                'name' => $productName,
                'variant_name' => $variantName,
                'notes' => $notes
            ];
        }
        
        // Ambil voucher referral yang digunakan oleh user (voucher dari user lain)
        $referralStmt = $pdo->prepare('
            SELECT DISTINCT
                v.code as voucher_code,
                v.value as voucher_value,
                owner.name as owner_name,
                owner.branch as owner_branch,
                SUM(tv.amount_applied) as total_used
            FROM transactions t
            INNER JOIN transaction_vouchers tv ON tv.transaction_id = t.id
            INNER JOIN vouchers v ON tv.voucher_id = v.id
            INNER JOIN users owner ON v.owner_user_id = owner.id
            WHERE t.user_id = :user_id AND v.owner_user_id != :user_id
            GROUP BY v.id, v.code, v.value, owner.name, owner.branch
            ORDER BY v.code ASC
        ');
        $referralStmt->execute([':user_id' => $userId]);
        $referralVouchers = $referralStmt->fetchAll();
        
        $row['voucher_status'] = $voucherStatus;
        $row['voucher_detail'] = $voucherDetail;
        $row['jumlah_produk_dibeli'] = (int) $row['jumlah_produk_dibeli'];
        $row['total_rp_transaksi'] = (int) $row['total_rp_transaksi'];
        $row['total_kurang_bayar'] = (int) $row['total_kurang_bayar'];
        $row['nama_produk'] = $productNames;
        $row['voucher_referral'] = $referralVouchers;
        $row['has_referral'] = !empty($referralVouchers);
    }
    unset($row);
    
} catch (PDOException $e) {
    $dbError = 'Gagal memuat data: ' . $e->getMessage();
}

?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rekapitulasi - Guest Redeem</title>
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <style>
        .recap-page {
            max-width: 1400px;
            margin: 0 auto;
            padding: 2rem;
        }
        
        .recap-header {
            background: linear-gradient(135deg, #1d4ed8, #3b82f6);
            color: #fff;
            padding: 2rem;
            border-radius: 1.25rem;
            margin-bottom: 2rem;
            box-shadow: 0 20px 45px rgba(3, 7, 18, 0.35);
        }
        
        .subnav {
            display: flex;
            gap: 0.75rem;
            margin-bottom: 2rem;
            flex-wrap: wrap;
        }
        
        .subnav-link {
            padding: 0.65rem 1.25rem;
            border-radius: 999px;
            background: #e2e8f0;
            color: #1e293b;
            font-weight: 600;
            text-decoration: none;
            transition: background 0.2s ease, color 0.2s ease;
        }
        
        .subnav-link:hover {
            background: #cbd5f5;
        }
        
        .subnav-link.active {
            background: #1d4ed8;
            color: #fff;
            box-shadow: 0 10px 20px rgba(30, 64, 175, 0.25);
        }
        
        .recap-header h1 {
            margin: 0 0 0.5rem;
            font-size: 2rem;
        }
        
        .recap-header p {
            margin: 0;
            opacity: 0.9;
        }
        
        .search-section {
            background: #fff;
            border-radius: 1rem;
            padding: 1.5rem;
            margin-bottom: 2rem;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }
        
        .search-form {
            display: flex;
            gap: 1rem;
        }
        
        .search-input {
            flex: 1;
            padding: 0.75rem 1rem;
            border: 2px solid #e2e8f0;
            border-radius: 0.5rem;
            font-size: 1rem;
            transition: border-color 0.2s;
        }
        
        .search-input:focus {
            outline: none;
            border-color: #3b82f6;
        }
        
        .recap-table-container {
            background: #fff;
            border-radius: 1rem;
            padding: 1.5rem;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            overflow-x: auto;
        }
        
        .recap-table {
            width: 100%;
            border-collapse: collapse;
            min-width: 2000px;
        }
        
        .recap-table thead {
            background: #f8fafc;
        }
        
        .recap-table th {
            padding: 1rem;
            text-align: left;
            font-weight: 600;
            color: #1e293b;
            border-bottom: 2px solid #e2e8f0;
            white-space: nowrap;
        }
        
        .recap-table td {
            padding: 1rem;
            border-bottom: 1px solid #e2e8f0;
            color: #475569;
        }
        
        .recap-table tbody tr:hover {
            background: #f8fafc;
        }
        
        .status-badge {
            display: inline-block;
            padding: 0.375rem 0.75rem;
            border-radius: 0.375rem;
            font-size: 0.875rem;
            font-weight: 500;
        }
        
        .status-hadir {
            background: #d1fae5;
            color: #065f46;
        }
        
        .status-belum-hadir {
            background: #fee2e2;
            color: #991b1b;
        }
        
        .voucher-status {
            font-weight: 500;
        }
        
        .voucher-terpakai {
            color: #059669;
        }
        
        .voucher-tidak-terpakai {
            color: #64748b;
        }
        
        .voucher-referral {
            color: #d97706;
        }
        
        .voucher-detail {
            font-size: 0.875rem;
            color: #64748b;
            margin-top: 0.25rem;
        }
        
        .empty-state {
            text-align: center;
            padding: 3rem;
            color: #64748b;
        }
        
        .empty-state svg {
            width: 64px;
            height: 64px;
            margin: 0 auto 1rem;
            opacity: 0.5;
        }
        
        @media print {
            .recap-page {
                padding: 0;
            }
            
            .recap-header {
                background: #fff;
                color: #000;
                box-shadow: none;
                padding: 1rem;
                margin-bottom: 1rem;
            }
            
            .search-section {
                display: none;
            }
            
            .fab, .fab-menu {
                display: none !important;
            }
            
            .recap-table {
                font-size: 0.75rem;
            }
            
            .recap-table th,
            .recap-table td {
                padding: 0.5rem;
            }
        }
    </style>
</head>
<body>
    <div class="recap-page">
        <div class="recap-header">
            <h1>📊 Rekapitulasi</h1>
            <p>Data lengkap kehadiran, voucher, dan transaksi tamu</p>
        </div>
        
        <nav class="subnav">
            <a class="subnav-link <?= $currentPage === 'recap' ? 'active' : '' ?>" href="recap.php">Rekapitulasi</a>
            <a class="subnav-link" href="transactions.php">Transaksi</a>
            <a class="subnav-link" href="referral.php">Voucher Referral</a>
        </nav>
        
        <div class="page-actions">
            <button type="button" class="btn btn-secondary btn-print" id="recapPrintBtn">
                🖨️ Print Halaman
            </button>
        </div>
        
        <div class="search-section">
            <form method="GET" action="recap.php" class="search-form">
                <input 
                    type="text" 
                    name="q" 
                    class="search-input" 
                    placeholder="Cari nama, cabang, no HP, atau kode voucher..." 
                    value="<?= htmlspecialchars($search) ?>"
                >
                <button type="submit" class="btn btn-primary">Cari</button>
                <?php if ($search !== '') : ?>
                    <a href="recap.php" class="btn btn-secondary">Reset</a>
                <?php endif; ?>
            </form>
        </div>
        
        <?php if ($dbError) : ?>
            <div class="alert alert-danger">
                <?= htmlspecialchars($dbError) ?>
            </div>
        <?php elseif (empty($recapData)) : ?>
            <div class="recap-table-container">
                <div class="empty-state">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                    </svg>
                    <p>Tidak ada data ditemukan.</p>
                </div>
            </div>
        <?php else : ?>
            <div class="recap-table-container">
                <table class="recap-table">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama User</th>
                            <th>Cabang</th>
                            <th>No HP</th>
                            <th>Kehadiran</th>
                            <th>Jam Kehadiran</th>
                            <th>Status Voucher</th>
                            <th>Voucher Referral</th>
                            <th>Jumlah Produk Dibeli</th>
                            <th>Nama Produk</th>
                            <th>Notes</th>
                            <th>Total Rp Transaksi</th>
                            <th>Kurang Bayar</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($recapData as $index => $row) : ?>
                            <tr>
                                <td><?= $index + 1 ?></td>
                                <td>
                                    <strong><?= htmlspecialchars($row['name']) ?></strong>
                                    <div style="font-size: 0.875rem; color: #64748b; margin-top: 0.25rem;">
                                        ID: <?= (int) $row['id'] ?> | Voucher: <?= htmlspecialchars($row['voucher_code']) ?>
                                    </div>
                                </td>
                                <td><?= htmlspecialchars($row['branch']) ?></td>
                                <td>
                                    <?php if (!empty($row['no_hp'])) : ?>
                                        📱 <?= htmlspecialchars($row['no_hp']) ?>
                                    <?php else : ?>
                                        <span style="color: #94a3b8;">-</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($row['attendance_status'] === 'hadir') : ?>
                                        <span class="status-badge status-hadir">✓ Hadir</span>
                                    <?php else : ?>
                                        <span class="status-badge status-belum-hadir">✗ Belum Hadir</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($row['attendance_at']) : ?>
                                        <?php
                                        $attendanceDate = new DateTime($row['attendance_at']);
                                        echo $attendanceDate->format('d/m/Y H:i:s');
                                        ?>
                                    <?php else : ?>
                                        <span style="color: #94a3b8;">-</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php
                                    $voucherClass = 'voucher-tidak-terpakai';
                                    if ($row['voucher_status'] === 'Terpakai') {
                                        $voucherClass = 'voucher-terpakai';
                                    } elseif ($row['voucher_status'] === 'Dipakai untuk Referral') {
                                        $voucherClass = 'voucher-referral';
                                    }
                                    ?>
                                    <div class="voucher-status <?= $voucherClass ?>">
                                        <?= htmlspecialchars($row['voucher_status']) ?>
                                    </div>
                                    <?php if (!empty($row['voucher_detail'])) : ?>
                                        <div class="voucher-detail">
                                            <?= implode(', ', array_map('htmlspecialchars', array_slice($row['voucher_detail'], 0, 2))) ?>
                                            <?php if (count($row['voucher_detail']) > 2) : ?>
                                                <span>...</span>
                                            <?php endif; ?>
                                        </div>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if (!empty($row['voucher_referral'])) : ?>
                                        <div style="max-width: 300px;">
                                            <?php foreach ($row['voucher_referral'] as $idx => $refVoucher) : ?>
                                                <div style="margin-bottom: 0.5rem; padding: 0.5rem; background: #fef3c7; border-radius: 0.25rem; border-left: 3px solid #f59e0b;">
                                                    <div style="font-weight: 600; color: #92400e; font-size: 0.875rem;">
                                                        <?= ($idx + 1) ?>. <?= htmlspecialchars($refVoucher['voucher_code']) ?>
                                                    </div>
                                                    <div style="font-size: 0.75rem; color: #64748b; margin-top: 0.25rem;">
                                                        Dari: <strong><?= htmlspecialchars($refVoucher['owner_name']) ?></strong>
                                                        (<?= htmlspecialchars($refVoucher['owner_branch']) ?>)
                                                    </div>
                                                    <div style="font-size: 0.75rem; color: #059669; margin-top: 0.25rem;">
                                                        Digunakan: Rp <?= number_format((int) $refVoucher['total_used'], 0, ',', '.') ?>
                                                    </div>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                    <?php else : ?>
                                        <span style="color: #94a3b8;">-</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <strong><?= number_format($row['jumlah_produk_dibeli'], 0, ',', '.') ?></strong>
                                    <?php if ($row['jumlah_produk_dibeli'] > 0) : ?>
                                        <span style="font-size: 0.875rem; color: #64748b;">produk</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if (!empty($row['nama_produk'])) : ?>
                                        <div style="max-width: 300px;">
                                            <?php foreach ($row['nama_produk'] as $idx => $productDetail) : ?>
                                                <?php
                                                // Handle both old format (string) and new format (array)
                                                if (is_array($productDetail)) {
                                                    $productNameOnly = $productDetail['name'];
                                                    $variantName = $productDetail['variant_name'] ?? null;
                                                } else {
                                                    // Backward compatibility: old format was string
                                                    $parts = explode(' - ', $productDetail, 2);
                                                    $productNameOnly = $parts[0];
                                                    $variantName = isset($parts[1]) ? $parts[1] : null;
                                                }
                                                ?>
                                                <div style="margin-bottom: 0.5rem; padding: 0.5rem; background: #f8fafc; border-radius: 0.375rem;">
                                                    <div style="font-weight: 600; margin-bottom: 0.25rem;">
                                                        <?= ($idx + 1) ?>. <?= htmlspecialchars($productNameOnly) ?>
                                                    </div>
                                                    <?php if ($variantName) : ?>
                                                        <div style="font-size: 0.875rem; color: #3b82f6; font-weight: 500;">
                                                            Varian: <?= htmlspecialchars($variantName) ?>
                                                        </div>
                                                    <?php endif; ?>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                    <?php else : ?>
                                        <span style="color: #94a3b8;">-</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if (!empty($row['nama_produk'])) : ?>
                                        <div style="max-width: 300px;">
                                            <?php foreach ($row['nama_produk'] as $idx => $productDetail) : ?>
                                                <?php
                                                // Handle both old format (string) and new format (array)
                                                $notes = null;
                                                if (is_array($productDetail) && isset($productDetail['notes'])) {
                                                    $notes = $productDetail['notes'];
                                                }
                                                ?>
                                                <?php if ($notes) : ?>
                                                    <div style="margin-bottom: 0.5rem; padding: 0.5rem; background: #fef3c7; border-radius: 0.375rem; border-left: 3px solid #f59e0b;">
                                                        <div style="font-size: 0.75rem; color: #92400e; font-weight: 600; margin-bottom: 0.25rem;">
                                                            📝 Catatan:
                                                        </div>
                                                        <div style="font-size: 0.875rem; color: #78350f; word-wrap: break-word;">
                                                            <?= htmlspecialchars($notes) ?>
                                                        </div>
                                                    </div>
                                                <?php else : ?>
                                                    <div style="font-size: 0.875rem; color: #94a3b8; font-style: italic;">
                                                        -
                                                    </div>
                                                <?php endif; ?>
                                            <?php endforeach; ?>
                                        </div>
                                    <?php else : ?>
                                        <span style="color: #94a3b8;">-</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($row['total_rp_transaksi'] > 0) : ?>
                                        <strong style="color: #059669;">
                                            Rp <?= number_format($row['total_rp_transaksi'], 0, ',', '.') ?>
                                        </strong>
                                    <?php else : ?>
                                        <span style="color: #94a3b8;">Rp 0</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($row['total_kurang_bayar'] > 0) : ?>
                                        <strong style="color: #dc2626;">
                                            Rp <?= number_format($row['total_kurang_bayar'], 0, ',', '.') ?>
                                        </strong>
                                    <?php else : ?>
                                        <span style="color: #94a3b8;">Rp 0</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
    
    <!-- FAB Menu -->
    <button class="fab" id="fabButton" type="button">+</button>
    <div class="fab-menu" id="fabMenu">
        <a class="fab-item dashboard" href="index.php" title="Dashboard">🏠</a>
        <a class="fab-item new-guest" href="new_guest.php" title="New Guest">➕</a>
        <a class="fab-item products" href="new_product.php" title="New Product">🛍️</a>
        <a class="fab-item transactions" href="transactions.php" title="Transactions">📋</a>
        <a class="fab-item referral" href="referral.php" title="Voucher Referral">🎫</a>
    </div>
    
    <script>
        (function() {
            var printBtn = document.getElementById('recapPrintBtn');
            var tableContainer = document.querySelector('.recap-table-container');

            if (printBtn && tableContainer) {
                printBtn.addEventListener('click', function() {
                    var printWindow = window.open('', '', 'width=1200,height=800');
                    if (!printWindow) {
                        alert('Popup print diblokir oleh browser.');
                        return;
                    }

                    var tableHtml = tableContainer.outerHTML;
                    var doc = `
                        <!DOCTYPE html>
                        <html lang="id">
                        <head>
                            <meta charset="UTF-8">
                            <title>Print Rekap</title>
                            <link rel="stylesheet" href="style.css">
                            <style>
                                body {
                                    margin: 1.5rem;
                                    font-family: 'Inter', system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
                                }
                                .recap-table-container { box-shadow: none; padding: 0; }
                                .recap-table { min-width: 100%; font-size: 0.85rem; }
                                .recap-table th,
                                .recap-table td { padding: 0.4rem 0.6rem; }
                                .voucher-detail, .voucher-status,
                                .voucher-referral { font-size: 0.75rem; }
                                table, thead, tbody, th, td, tr {
                                    display: revert !important;
                                }
                                thead {
                                    display: table-header-group !important;
                                }
                                tbody {
                                    display: table-row-group !important;
                                }
                                tr {
                                    display: table-row !important;
                                    border: none !important;
                                    background: transparent !important;
                                }
                                td {
                                    display: table-cell !important;
                                    border-bottom: 1px solid #e2e8f0;
                                }
                                td::before {
                                    display: none !important;
                                }
                            </style>
                        </head>
                        <body>
                            ${tableHtml}
                        </body>
                        </html>
                    `;

                    printWindow.document.write(doc);
                    printWindow.document.close();
                    printWindow.focus();
                    printWindow.onload = function() {
                        printWindow.print();
                        printWindow.close();
                    };
                });
            }
        })();
        // FAB Menu Toggle
        (function() {
            const fabButton = document.getElementById('fabButton');
            const fabMenu = document.getElementById('fabMenu');
            
            if (fabButton && fabMenu) {
                fabButton.addEventListener('click', function() {
                    const isOpen = fabMenu.classList.contains('open');
                    if (isOpen) {
                        fabMenu.classList.remove('open');
                        fabButton.classList.remove('active');
                    } else {
                        fabMenu.classList.add('open');
                        fabButton.classList.add('active');
                    }
                });
                
                // Close menu when clicking outside
                document.addEventListener('click', function(e) {
                    if (!fabButton.contains(e.target) && !fabMenu.contains(e.target)) {
                        fabMenu.classList.remove('open');
                        fabButton.classList.remove('active');
                    }
                });
            }
        })();
    </script>
</body>
</html>

