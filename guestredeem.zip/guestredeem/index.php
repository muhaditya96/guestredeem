<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';

use PDOException;

$search = isset($_GET['q']) ? trim($_GET['q']) : '';
$users = [];
$dbError = null;
$totalTamu = 0;
$tamuHadir = 0;

try {
    $pdo = getDbConnection();
    
    // Export CSV untuk tamu yang sudah hadir
    if (isset($_GET['export']) && $_GET['export'] === 'csv') {
        $exportStmt = $pdo->query('SELECT id, name, branch, voucher_code, attendance_at FROM users WHERE attendance_status = "hadir" ORDER BY name COLLATE utf8mb4_unicode_ci ASC');
        $rows = $exportStmt->fetchAll();

        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="tamu_hadir_' . date('Ymd_His') . '.csv"');
        header('Pragma: no-cache');
        header('Expires: 0');

        $output = fopen('php://output', 'w');
        fputcsv($output, ['ID', 'Nama', 'Cabang', 'Kode Voucher', 'Waktu Kehadiran']);

        foreach ($rows as $row) {
            $attendanceAt = '';
            if (!empty($row['attendance_at'])) {
                $attendanceDate = new DateTime($row['attendance_at']);
                $attendanceAt = $attendanceDate->format('d/m/Y H:i:s');
            }

            fputcsv($output, [
                $row['id'],
                $row['name'],
                $row['branch'],
                $row['voucher_code'],
                $attendanceAt,
            ]);
        }

        fclose($output);
        exit;
    }
    
    // Hitung total tamu dan yang sudah hadir
    $countSql = 'SELECT COUNT(*) as total, SUM(CASE WHEN attendance_status = "hadir" THEN 1 ELSE 0 END) as hadir FROM users';
    $countStmt = $pdo->query($countSql);
    $countResult = $countStmt->fetch();
    $totalTamu = (int) ($countResult['total'] ?? 0);
    $tamuHadir = (int) ($countResult['hadir'] ?? 0);
    
    $sql = 'SELECT id, name, branch, attendance_status, voucher_code FROM users';
    $params = [];

    if ($search !== '') {
        $sql .= ' WHERE name LIKE :term OR branch LIKE :term OR voucher_code LIKE :term OR CAST(id AS CHAR) LIKE :term';
        $params['term'] = '%' . $search . '%';
    }

    $sql .= ' ORDER BY name COLLATE utf8mb4_unicode_ci ASC';
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $users = $stmt->fetchAll();
    
    // Cek status redeem untuk setiap user (lebih efisien dengan satu query)
    $redeemStatus = [];
    $voucherReferralInfo = []; // Info voucher yang dipakai untuk referral
    $usersWithTransaction = []; // User yang sudah melakukan transaksi sendiri
    if (!empty($users)) {
        $userIds = array_map(function($user) { return (int) $user['id']; }, $users);
        $placeholders = implode(',', array_fill(0, count($userIds), '?'));
        
        // Cek transaksi
        $transactionStmt = $pdo->prepare("SELECT DISTINCT user_id FROM transactions WHERE user_id IN ($placeholders)");
        $transactionStmt->execute($userIds);
        while ($row = $transactionStmt->fetch()) {
            $usersWithTransaction[] = (int) $row['user_id'];
        }
        
        // Cek voucher used
        $voucherStmt = $pdo->prepare("SELECT DISTINCT owner_user_id FROM vouchers WHERE owner_user_id IN ($placeholders) AND status = 'used'");
        $voucherStmt->execute($userIds);
        $usersWithUsedVoucher = [];
        while ($row = $voucherStmt->fetch()) {
            $usersWithUsedVoucher[] = (int) $row['owner_user_id'];
        }
        
        // Cek voucher yang dipakai untuk referral (dipakai oleh user lain)
        $referralStmt = $pdo->prepare("
            SELECT DISTINCT
                v.owner_user_id,
                v.code as voucher_code,
                u.name as used_by_name,
                u.branch as used_by_branch
            FROM vouchers v
            INNER JOIN transaction_vouchers tv ON tv.voucher_id = v.id
            INNER JOIN transactions t ON t.id = tv.transaction_id
            INNER JOIN users u ON t.user_id = u.id
            WHERE v.owner_user_id IN ($placeholders) 
            AND v.status = 'used'
            AND t.user_id != v.owner_user_id
        ");
        $referralStmt->execute($userIds);
        while ($row = $referralStmt->fetch()) {
            $ownerId = (int) $row['owner_user_id'];
            if (!isset($voucherReferralInfo[$ownerId])) {
                $voucherReferralInfo[$ownerId] = [];
            }
            $voucherReferralInfo[$ownerId][] = [
                'voucher_code' => $row['voucher_code'],
                'used_by_name' => $row['used_by_name'],
                'used_by_branch' => $row['used_by_branch'],
            ];
        }
        
        // Gabungkan hasil
        $usersRedeemed = array_unique(array_merge($usersWithTransaction, $usersWithUsedVoucher));
        foreach ($userIds as $userId) {
            // User tidak bisa redeem jika:
            // 1. Sudah melakukan transaksi sendiri, ATAU
            // 2. Vouchernya sudah dipakai untuk referral (dipakai oleh user lain)
            $hasReferral = isset($voucherReferralInfo[$userId]) && !empty($voucherReferralInfo[$userId]);
            $redeemStatus[$userId] = in_array($userId, $usersRedeemed) || $hasReferral;
        }
    }
} catch (PDOException $exception) {
    $dbError = $exception->getMessage();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Konfirmasi Kehadiran & Redeem Voucher</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="page">
        <header class="hero">
            <div>
                <p class="eyebrow">Voucher Guest Experience</p>
                <h1>Konfirmasi Kehadiran</h1>
                <p class="subtitle">
                    Cari nama tamu, tandai sebagai hadir, dan arahkan langsung ke halaman redeem voucher.
                </p>
            </div>
            <div class="hero-card">
                <p>Kehadiran</p>
                <strong id="attendanceCounter"><?= number_format($tamuHadir) ?> dari <?= number_format($totalTamu) ?></strong>
                <small id="attendancePercent"><?= $totalTamu > 0 ? number_format(($tamuHadir / $totalTamu) * 100, 1) : 0 ?>% hadir</small>
            </div>
        </header>

        <section class="panel">
            <div class="panel-header">
                <div>
                    <h2>Daftar tamu</h2>
                    <p>Selamat datang di Hari Guru by Telesis Digital Solution.</p>
                </div>
                <div class="panel-actions" style="display: flex; gap: 0.75rem; flex-wrap: wrap; align-items: center;">
                    <form class="search" method="get" style="display: flex; gap: 0.5rem; flex-wrap: wrap;">
                        <input data-search-input type="text" name="q" placeholder="Cari nama atau ID tamu..." value="<?= htmlspecialchars($search) ?>">
                        <?php if ($search !== '') : ?>
                            <a class="btn btn-secondary" href="index.php">Reset</a>
                        <?php endif; ?>
                        <button class="btn btn-primary" type="submit">Cari</button>
                    </form>
                    <a class="btn btn-secondary" href="index.php?export=csv" target="_blank" style="white-space: nowrap;">
                        📥 Export CSV (Hadir)
                    </a>
                </div>
            </div>

            <?php if ($dbError !== null) : ?>
                <div class="alert alert-error">
                    <strong>Gagal terkoneksi database.</strong>
                    <span><?= htmlspecialchars($dbError) ?></span>
                </div>
            <?php elseif (empty($users)) : ?>
                <div class="empty-state">
                    <img src="https://cdn.jsdelivr.net/gh/icons8/flat-color-icons/svg/empty-box.svg" alt="Empty">
                    <p>Data tamu tidak ditemukan.</p>
                </div>
            <?php else : ?>
                <div class="table-wrapper" data-table-wrapper>
                    <table>
                        <thead>
                        <tr>
                            <th>No</th>
                            <th>ID</th>
                            <th>Nama</th>
                            <th>Cabang</th>
                            <th>Status Kehadiran</th>
                            <th>Aksi</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($users as $index => $user) : ?>
                            <?php
                            $searchableText = strtolower($user['id'] . ' ' . $user['name'] . ' ' . $user['branch'] . ' ' . $user['voucher_code']);
                            ?>
                            <tr data-search-row="<?= htmlspecialchars($searchableText) ?>">
                                <td data-label="No"><?= $index + 1 ?></td>
                                <td data-label="ID">
                                    <span class="id-chip">#<?= (int) $user['id'] ?></span>
                                </td>
                                <td data-label="Nama">
                                    <div class="cell-main">
                                        <span class="avatar"><?= strtoupper(substr($user['name'], 0, 1)) ?></span>
                                        <div>
                                            <strong><?= htmlspecialchars($user['name']) ?></strong>
                                        </div>
                                    </div>
                                </td>
                                <td data-label="Cabang"><?= htmlspecialchars($user['branch']) ?></td>
                                <td data-label="Status">
                                    <?php
                                    $statusClass = $user['attendance_status'] === 'hadir' ? 'hadir' : 'pending';
                                    ?>
                                    <span class="status-badge <?= $statusClass ?>" data-status-badge data-user-id="<?= (int) $user['id'] ?>">
                                        <?= htmlspecialchars($user['attendance_status']) ?>
                                    </span>
                                </td>
                                <td data-label="Aksi">
                                    <div class="actions">
                                        <?php if ($user['attendance_status'] !== 'hadir') : ?>
                                            <form class="form-hadir" method="post" action="attendance.php" data-user-name="<?= htmlspecialchars($user['name']) ?>" data-user-id="<?= (int) $user['id'] ?>">
                                                <input type="hidden" name="user_id" value="<?= (int) $user['id'] ?>">
                                                <button class="btn btn-success" type="submit">
                                                    Hadir
                                                </button>
                                            </form>
                                        <?php else : ?>
                                            <?php 
                                            $userId = (int) $user['id'];
                                            $hasReferral = isset($voucherReferralInfo[$userId]) && !empty($voucherReferralInfo[$userId]);
                                            $hasRedeemed = isset($redeemStatus[$userId]) && $redeemStatus[$userId];
                                            $hasOwnTransaction = in_array($userId, $usersWithTransaction);
                                            ?>
                                            <?php if ($hasRedeemed || $hasReferral) : ?>
                                                <div style="display: flex; flex-direction: column; gap: 0.5rem;">
                                                    <button class="btn btn-secondary" disabled style="opacity: 0.6; cursor: not-allowed;">
                                                        Sudah Redeem
                                                    </button>
                                                    <?php if ($hasReferral && !$hasOwnTransaction) : ?>
                                                        <div style="font-size: 0.75rem; color: #d97706; background: #fef3c7; padding: 0.5rem; border-radius: 0.25rem; border-left: 3px solid #f59e0b;">
                                                            <strong>⚠️ Voucher digunakan untuk referral:</strong>
                                                            <?php foreach ($voucherReferralInfo[$userId] as $refInfo) : ?>
                                                                <div style="margin-top: 0.25rem;">
                                                                    • <?= htmlspecialchars($refInfo['voucher_code']) ?> digunakan oleh <strong><?= htmlspecialchars($refInfo['used_by_name']) ?></strong> (<?= htmlspecialchars($refInfo['used_by_branch']) ?>)
                                                                </div>
                                                            <?php endforeach; ?>
                                                        </div>
                                                    <?php endif; ?>
                                                </div>
                                            <?php else : ?>
                                                <a class="btn btn-warning" href="redeem.php?user_id=<?= $userId ?>">
                                                    Redeem
                                                </a>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <div class="empty-state empty-state-inline" data-empty-client hidden>
                    <p>Hasil pencarian realtime tidak ditemukan.</p>
                </div>
            <?php endif; ?>
        </section>
    </div>

    <div class="popup-backdrop" data-confirm hidden>
        <div class="popup-card">
            <div class="popup-icon question">?</div>
            <h3>Konfirmasi</h3>
            <p>Apakah anda yakin ini nama anda <strong data-confirm-name></strong>?</p>
            <div class="popup-actions">
                <button class="btn btn-secondary" type="button" data-confirm-cancel>Batal</button>
                <button class="btn btn-primary" type="button" data-confirm-accept>Ya</button>
            </div>
        </div>
    </div>

    <div class="popup-backdrop" data-popup hidden>
        <div class="popup-card">
            <div class="popup-icon">✔</div>
            <h3>Berhasil</h3>
            <p data-popup-message>Kehadiran tercatat.</p>
            <button class="btn btn-primary" type="button" data-popup-confirm>OK</button>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            var searchInput = document.querySelector('[data-search-input]');
            var rows = Array.prototype.slice.call(document.querySelectorAll('[data-search-row]'));
            var emptyClient = document.querySelector('[data-empty-client]');
            var hadirForms = Array.prototype.slice.call(document.querySelectorAll('.form-hadir'));
            var popup = document.querySelector('[data-popup]');
            var popupMessage = document.querySelector('[data-popup-message]');
            var popupConfirm = document.querySelector('[data-popup-confirm]');
            var confirmModal = document.querySelector('[data-confirm]');
            var confirmName = document.querySelector('[data-confirm-name]');
            var confirmAccept = document.querySelector('[data-confirm-accept]');
            var confirmCancel = document.querySelector('[data-confirm-cancel]');
            var pendingForm = null;
            var popupTimer = null;
            
            // Simpan nilai awal counter
            var totalTamu = <?= $totalTamu ?>;
            var tamuHadir = <?= $tamuHadir ?>;
            
            var updateAttendanceCounter = function () {
                var counterEl = document.getElementById('attendanceCounter');
                var percentEl = document.getElementById('attendancePercent');
                if (counterEl) {
                    counterEl.textContent = tamuHadir.toLocaleString('id-ID') + ' dari ' + totalTamu.toLocaleString('id-ID');
                }
                if (percentEl && totalTamu > 0) {
                    var percent = ((tamuHadir / totalTamu) * 100).toFixed(1);
                    percentEl.textContent = percent + '% hadir';
                }
            };

            var showPopup = function (message) {
                if (!popup || !popupMessage) {
                    alert(message);
                    return;
                }
                popupMessage.textContent = message;
                popup.hidden = false;
                popup.classList.add('open');
                if (popupConfirm) {
                    popupConfirm.focus();
                }
                if (popupTimer) {
                    clearTimeout(popupTimer);
                }
                popupTimer = setTimeout(function () {
                    hidePopup();
                }, 1000);
            };

            var hidePopup = function () {
                if (!popup) {
                    return;
                }
                if (popupTimer) {
                    clearTimeout(popupTimer);
                    popupTimer = null;
                }
                popup.classList.remove('open');
                popup.hidden = true;
            };

            if (popupConfirm) {
                popupConfirm.addEventListener('click', hidePopup);
            }
            if (popup) {
                popup.addEventListener('click', function (event) {
                    if (event.target === popup) {
                        hidePopup();
                    }
                });
            }

            var showConfirm = function (form) {
                if (!confirmModal || !confirmName) {
                    processAttendance(form);
                    return;
                }

                pendingForm = form;
                var name = form.dataset.userName || 'tamu';
                confirmName.textContent = name;
                confirmModal.hidden = false;
                confirmModal.classList.add('open');
                if (confirmAccept) {
                    confirmAccept.focus();
                }
            };

            var hideConfirm = function () {
                if (!confirmModal) {
                    return;
                }
                confirmModal.classList.remove('open');
                confirmModal.hidden = true;
                pendingForm = null;
            };

            if (confirmAccept) {
                confirmAccept.addEventListener('click', function () {
                    if (pendingForm) {
                        var formToSubmit = pendingForm;
                        hideConfirm();
                        processAttendance(formToSubmit);
                    }
                });
            }

            if (confirmCancel) {
                confirmCancel.addEventListener('click', hideConfirm);
            }

            if (confirmModal) {
                confirmModal.addEventListener('click', function (event) {
                    if (event.target === confirmModal) {
                        hideConfirm();
                    }
                });
            }

            if (searchInput && rows.length > 0) {
                var filterRows = function () {
                    var term = searchInput.value.trim().toLowerCase();
                    var visibleCount = 0;

                    rows.forEach(function (row) {
                        var matches = term === '' || row.dataset.searchRow.indexOf(term) !== -1;
                        row.style.display = matches ? '' : 'none';
                        if (matches) {
                            visibleCount += 1;
                        }
                    });

                    if (emptyClient) {
                        emptyClient.hidden = visibleCount !== 0;
                    }
                };

                searchInput.addEventListener('input', filterRows);
                filterRows();
            }

            var processAttendance = function (form) {
                if (form.dataset.loading === 'true') {
                    return;
                }

                var button = form.querySelector('button');
                var originalText = button ? button.textContent : '';

                if (button) {
                    button.textContent = 'Memproses...';
                    button.disabled = true;
                }

                form.dataset.loading = 'true';

                fetch(form.action, {
                    method: 'POST',
                    body: new FormData(form),
                })
                    .then(function (response) {
                        return response.json().then(function (data) {
                            if (!response.ok) {
                                var message = data && data.message ? data.message : 'Gagal mencatat kehadiran.';
                                throw new Error(message);
                            }
                            return data;
                        });
                    })
                    .then(function (data) {
                        if (!data.success) {
                            throw new Error(data.message || 'Gagal mencatat kehadiran.');
                        }

                        var userId = form.dataset.userId;
                        var badge = document.querySelector('[data-status-badge][data-user-id="' + userId + '"]');
                        if (badge) {
                            badge.textContent = 'hadir';
                            badge.classList.remove('pending');
                            badge.classList.add('hadir');
                        }

                        // Sembunyikan form "Hadir" dan tampilkan tombol Redeem
                        var actionsDiv = form.closest('.actions');
                        if (actionsDiv) {
                            // Sembunyikan form "Hadir"
                            form.style.display = 'none';
                            
                            // Tampilkan tombol Redeem jika belum ada
                            var existingRedeem = actionsDiv.querySelector('.btn-warning[href*="redeem.php"]');
                            if (!existingRedeem) {
                                var redeemBtn = document.createElement('a');
                                redeemBtn.className = 'btn btn-warning';
                                redeemBtn.href = 'redeem.php?user_id=' + userId;
                                redeemBtn.textContent = 'Redeem';
                                actionsDiv.appendChild(redeemBtn);
                            }
                        }

                        // Update counter kehadiran
                        tamuHadir++;
                        updateAttendanceCounter();

                        var userName = (data.user && data.user.name) ? data.user.name : (form.dataset.userName || 'tamu');
                        showPopup('Kehadiran ' + userName + ' berhasil dicatat.');
                    })
                    .catch(function (error) {
                        alert(error.message || 'Terjadi kesalahan.');
                        if (button) {
                            button.textContent = originalText || 'Hadir';
                            button.disabled = false;
                        }
                    })
                    .finally(function () {
                        form.dataset.loading = 'false';
                    });
            };

            hadirForms.forEach(function (form) {
                form.addEventListener('submit', function (event) {
                    event.preventDefault();
                    showConfirm(form);
                });
            });
        });
    </script>
    <button class="fab" id="fabButton" type="button">+</button>
    <div class="fab-menu" id="fabMenu">
        <a class="fab-item dashboard" href="index.php" title="Dashboard">🏠</a>
        <a class="fab-item new-guest" href="new_guest.php" title="New Guest">➕</a>
        <a class="fab-item products" href="new_product.php" title="New Product">🛍️</a>
        <a class="fab-item transactions" href="transactions.php" title="Transactions">📋</a>
        <a class="fab-item recap" href="recap.php" title="Rekapitulasi">📊</a>
        <a class="fab-item referral" href="referral.php" title="Voucher Referral">🎫</a>
    </div>
    <script>
        (function () {
            var fabButton = document.getElementById('fabButton');
            var fabMenu = document.getElementById('fabMenu');

            var toggleMenu = function () {
                if (!fabMenu || !fabButton) {
                    return;
                }
                fabMenu.classList.toggle('open');
                fabButton.classList.toggle('open');
            };

            if (fabButton) {
                fabButton.addEventListener('click', toggleMenu);
            }
        })();
    </script>
</body>
</html>

