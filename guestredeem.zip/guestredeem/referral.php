<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';

use PDO;
use PDOException;

$search = isset($_GET['q']) ? trim($_GET['q']) : '';
$referralData = [];
$dbError = null;
$currentPage = 'referral';

try {
    $pdo = getDbConnection();
    
    // Query untuk mendapatkan transaksi yang menggunakan voucher referral
    // (voucher yang owner_user_id berbeda dengan user_id yang melakukan transaksi)
    $sql = 'SELECT 
                t.id as transaction_id,
                t.user_id,
                t.total_price,
                t.voucher_covered,
                t.extra_charge,
                t.created_at as transaction_date,
                u.name as user_name,
                u.branch as user_branch,
                u.voucher_code as user_voucher_code,
                v.id as voucher_id,
                v.code as voucher_code,
                v.owner_user_id,
                v.value as voucher_value,
                owner.name as owner_name,
                owner.branch as owner_branch,
                owner.voucher_code as owner_voucher_code,
                p.name as product_name,
                p.price as product_price,
                tv.amount_applied
            FROM transactions t
            INNER JOIN transaction_vouchers tv ON tv.transaction_id = t.id
            INNER JOIN vouchers v ON tv.voucher_id = v.id
            INNER JOIN users u ON t.user_id = u.id
            INNER JOIN users owner ON v.owner_user_id = owner.id
            INNER JOIN products p ON t.product_id = p.id
            WHERE v.owner_user_id != t.user_id';
    
    $params = [];
    $conditions = [];
    
    // Filter berdasarkan search
    if ($search !== '') {
        $conditions[] = '(u.name LIKE :search OR owner.name LIKE :search OR v.code LIKE :search OR u.branch LIKE :search OR owner.branch LIKE :search OR CAST(t.id AS CHAR) LIKE :search)';
        $params[':search'] = '%' . $search . '%';
    }
    
    if (!empty($conditions)) {
        $sql .= ' AND ' . implode(' AND ', $conditions);
    }
    
    $sql .= ' ORDER BY t.created_at DESC';
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $referralData = $stmt->fetchAll();
    
    // Kelompokkan berdasarkan user yang menggunakan voucher referral
    $groupedByUser = [];
    foreach ($referralData as $row) {
        $userId = (int) $row['user_id'];
        if (!isset($groupedByUser[$userId])) {
            $groupedByUser[$userId] = [
                'user_id' => $userId,
                'user_name' => $row['user_name'],
                'user_branch' => $row['user_branch'],
                'user_voucher_code' => $row['user_voucher_code'],
                'transactions' => [],
                'total_transactions' => 0,
                'total_amount' => 0,
                'total_voucher_used' => 0,
                'total_extra_charge' => 0,
            ];
        }
        $groupedByUser[$userId]['transactions'][] = $row;
        $groupedByUser[$userId]['total_transactions']++;
        $groupedByUser[$userId]['total_amount'] += (int) $row['total_price'];
        $groupedByUser[$userId]['total_voucher_used'] += (int) $row['amount_applied'];
        $groupedByUser[$userId]['total_extra_charge'] += (int) $row['extra_charge'];
    }
    
    // Hitung statistik keseluruhan
    $totalStats = [
        'total_users' => count($groupedByUser),
        'total_transactions' => count($referralData),
        'total_amount' => array_sum(array_column($referralData, 'total_price')),
        'total_voucher_used' => array_sum(array_column($referralData, 'amount_applied')),
    ];
    
} catch (PDOException $e) {
    $dbError = 'Gagal memuat data: ' . $e->getMessage();
}

?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Voucher Referral - Guest Redeem</title>
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <style>
        .referral-page {
            max-width: 1400px;
            margin: 0 auto;
            padding: 2rem;
        }
        
        .referral-header {
            background: linear-gradient(135deg, #d97706, #f59e0b);
            color: #fff;
            padding: 2rem;
            border-radius: 1.25rem;
            margin-bottom: 2rem;
            box-shadow: 0 20px 45px rgba(3, 7, 18, 0.35);
        }
        
        .referral-header h1 {
            margin: 0 0 0.5rem;
            font-size: 2rem;
        }
        
        .subnav {
            display: flex;
            gap: 0.75rem;
            margin-bottom: 2rem;
            flex-wrap: wrap;
        }
        
        .subnav-link {
            padding: 0.65rem 1.25rem;
            border-radius: 999px;
            background: #fde68a;
            color: #78350f;
            font-weight: 600;
            text-decoration: none;
            transition: background 0.2s ease, color 0.2s ease;
        }
        
        .subnav-link:hover {
            background: #fcd34d;
        }
        
        .subnav-link.active {
            background: #d97706;
            color: #fff;
            box-shadow: 0 10px 20px rgba(217, 119, 6, 0.25);
        }
        
        .referral-header p {
            margin: 0;
            opacity: 0.9;
        }
        
        .stats-summary {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin-bottom: 2rem;
        }
        
        .stat-card {
            background: #fff;
            padding: 1.5rem;
            border-radius: 0.75rem;
            border-left: 4px solid var(--primary, #3b82f6);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }
        
        .stat-card.success {
            border-left-color: var(--success, #10b981);
        }
        
        .stat-card.warning {
            border-left-color: #f59e0b;
        }
        
        .stat-label {
            font-size: 0.875rem;
            color: #64748b;
            margin-bottom: 0.5rem;
        }
        
        .stat-value {
            font-size: 1.5rem;
            font-weight: 600;
            color: #1e293b;
        }
        
        .search-section {
            background: #fff;
            border-radius: 1rem;
            padding: 1.5rem;
            margin-bottom: 2rem;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }
        
        .search-form {
            display: flex;
            gap: 1rem;
        }
        
        .search-input {
            flex: 1;
            padding: 0.75rem 1rem;
            border: 2px solid #e2e8f0;
            border-radius: 0.5rem;
            font-size: 1rem;
            transition: border-color 0.2s;
        }
        
        .search-input:focus {
            outline: none;
            border-color: #3b82f6;
        }
        
        .user-card {
            background: #fff;
            border-radius: 1rem;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }
        
        .user-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 1rem;
            padding-bottom: 1rem;
            border-bottom: 2px solid #e2e8f0;
        }
        
        .user-info h3 {
            margin: 0 0 0.25rem;
            font-size: 1.25rem;
            color: #1e293b;
        }
        
        .user-meta {
            font-size: 0.875rem;
            color: #64748b;
        }
        
        .user-stats {
            text-align: right;
        }
        
        .user-stats-item {
            margin-bottom: 0.25rem;
            font-size: 0.875rem;
        }
        
        .user-stats-label {
            color: #64748b;
        }
        
        .user-stats-value {
            font-weight: 600;
            color: #1e293b;
        }
        
        .transaction-item {
            display: grid;
            grid-template-columns: auto 1fr auto;
            gap: 1rem;
            padding: 1rem;
            margin-bottom: 0.75rem;
            background: #f8fafc;
            border-radius: 0.5rem;
            border-left: 3px solid #f59e0b;
        }
        
        .transaction-product {
            font-weight: 600;
            color: #1e293b;
            margin-bottom: 0.25rem;
        }
        
        .transaction-details {
            font-size: 0.875rem;
            color: #64748b;
        }
        
        .transaction-voucher {
            text-align: right;
        }
        
        .voucher-badge {
            display: inline-block;
            padding: 0.25rem 0.5rem;
            background: #fef3c7;
            color: #92400e;
            border-radius: 0.25rem;
            font-size: 0.75rem;
            font-weight: 600;
            margin-bottom: 0.25rem;
        }
        
        .owner-info {
            font-size: 0.75rem;
            color: #64748b;
        }
        
        .transaction-amount {
            font-weight: 600;
            color: #059669;
        }
        
        .empty-state {
            text-align: center;
            padding: 3rem;
            color: #64748b;
            background: #fff;
            border-radius: 1rem;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }
        
        .empty-state svg {
            width: 64px;
            height: 64px;
            margin: 0 auto 1rem;
            opacity: 0.5;
        }
    </style>
</head>
<body>
    <div class="referral-page">
        <div class="referral-header">
            <h1>🎫 Voucher Referral</h1>
            <p>Data penggunaan voucher dari user lain (referral)</p>
        </div>
        
        <nav class="subnav">
            <a class="subnav-link" href="recap.php">Rekapitulasi</a>
            <a class="subnav-link" href="transactions.php">Transaksi</a>
            <a class="subnav-link <?= $currentPage === 'referral' ? 'active' : '' ?>" href="referral.php">Voucher Referral</a>
        </nav>
        
        <?php if ($dbError) : ?>
            <div class="alert alert-danger">
                <?= htmlspecialchars($dbError) ?>
            </div>
        <?php else : ?>
            <!-- Statistik -->
            <div class="stats-summary">
                <div class="stat-card">
                    <div class="stat-label">Total User yang Pakai Referral</div>
                    <div class="stat-value"><?= number_format($totalStats['total_users'], 0, ',', '.') ?></div>
                </div>
                <div class="stat-card success">
                    <div class="stat-label">Total Transaksi</div>
                    <div class="stat-value"><?= number_format($totalStats['total_transactions'], 0, ',', '.') ?></div>
                </div>
                <div class="stat-card warning">
                    <div class="stat-label">Total Voucher Referral Digunakan</div>
                    <div class="stat-value">Rp <?= number_format($totalStats['total_voucher_used'], 0, ',', '.') ?></div>
                </div>
                <div class="stat-card success">
                    <div class="stat-label">Total Nilai Transaksi</div>
                    <div class="stat-value">Rp <?= number_format($totalStats['total_amount'], 0, ',', '.') ?></div>
                </div>
            </div>
            
            <!-- Search -->
            <div class="search-section">
                <form method="GET" action="referral.php" class="search-form">
                    <input 
                        type="text" 
                        name="q" 
                        class="search-input" 
                        placeholder="Cari nama user, pemilik voucher, kode voucher, atau cabang..." 
                        value="<?= htmlspecialchars($search) ?>"
                    >
                    <button type="submit" class="btn btn-primary">Cari</button>
                    <?php if ($search !== '') : ?>
                        <a href="referral.php" class="btn btn-secondary">Reset</a>
                    <?php endif; ?>
                </form>
            </div>
            
            <!-- Data -->
            <?php if (empty($groupedByUser)) : ?>
                <div class="empty-state">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                    </svg>
                    <p>Tidak ada data penggunaan voucher referral.</p>
                </div>
            <?php else : ?>
                <?php foreach ($groupedByUser as $userData) : ?>
                    <div class="user-card">
                        <div class="user-header">
                            <div class="user-info">
                                <h3><?= htmlspecialchars($userData['user_name']) ?></h3>
                                <div class="user-meta">
                                    ID: <?= (int) $userData['user_id'] ?> | 
                                    Cabang: <?= htmlspecialchars($userData['user_branch']) ?> | 
                                    Voucher: <?= htmlspecialchars($userData['user_voucher_code']) ?>
                                </div>
                            </div>
                            <div class="user-stats">
                                <div class="user-stats-item">
                                    <span class="user-stats-label">Transaksi: </span>
                                    <span class="user-stats-value"><?= $userData['total_transactions'] ?></span>
                                </div>
                                <div class="user-stats-item">
                                    <span class="user-stats-label">Total: </span>
                                    <span class="user-stats-value">Rp <?= number_format($userData['total_amount'], 0, ',', '.') ?></span>
                                </div>
                                <div class="user-stats-item">
                                    <span class="user-stats-label">Voucher Referral: </span>
                                    <span class="user-stats-value" style="color: #d97706;">Rp <?= number_format($userData['total_voucher_used'], 0, ',', '.') ?></span>
                                </div>
                            </div>
                        </div>
                        
                        <div class="transactions-list">
                            <?php foreach ($userData['transactions'] as $transaction) : ?>
                                <div class="transaction-item">
                                    <div>
                                        <div class="transaction-product">
                                            <?= htmlspecialchars($transaction['product_name']) ?>
                                        </div>
                                        <div class="transaction-details">
                                            <?php
                                            $transDate = new DateTime($transaction['transaction_date']);
                                            echo $transDate->format('d/m/Y H:i:s');
                                            ?>
                                            | Harga: Rp <?= number_format((int) $transaction['product_price'], 0, ',', '.') ?>
                                        </div>
                                    </div>
                                    <div>
                                        <div class="voucher-badge">
                                            <?= htmlspecialchars($transaction['voucher_code']) ?>
                                        </div>
                                        <div class="owner-info">
                                            Voucher dari: <strong><?= htmlspecialchars($transaction['owner_name']) ?></strong>
                                            (<?= htmlspecialchars($transaction['owner_branch']) ?>)
                                        </div>
                                    </div>
                                    <div class="transaction-voucher">
                                        <div class="transaction-amount">
                                            Rp <?= number_format((int) $transaction['total_price'], 0, ',', '.') ?>
                                        </div>
                                        <div style="font-size: 0.75rem; color: #64748b;">
                                            Voucher: Rp <?= number_format((int) $transaction['amount_applied'], 0, ',', '.') ?>
                                            <?php if ((int) $transaction['extra_charge'] > 0) : ?>
                                                <br>Kurang: Rp <?= number_format((int) $transaction['extra_charge'], 0, ',', '.') ?>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        <?php endif; ?>
    </div>
    
    <!-- FAB Menu -->
    <button class="fab" id="fabButton" type="button">+</button>
    <div class="fab-menu" id="fabMenu">
        <a class="fab-item dashboard" href="index.php" title="Dashboard">🏠</a>
        <a class="fab-item new-guest" href="new_guest.php" title="New Guest">➕</a>
        <a class="fab-item products" href="new_product.php" title="New Product">🛍️</a>
        <a class="fab-item transactions" href="transactions.php" title="Transactions">📋</a>
        <a class="fab-item recap" href="recap.php" title="Rekapitulasi">📊</a>
        <a class="fab-item referral" href="referral.php" title="Voucher Referral">🎫</a>
    </div>
    
    <script>
        // FAB Menu Toggle
        (function() {
            const fabButton = document.getElementById('fabButton');
            const fabMenu = document.getElementById('fabMenu');
            
            if (fabButton && fabMenu) {
                fabButton.addEventListener('click', function() {
                    const isOpen = fabMenu.classList.contains('open');
                    if (isOpen) {
                        fabMenu.classList.remove('open');
                        fabButton.classList.remove('active');
                    } else {
                        fabMenu.classList.add('open');
                        fabButton.classList.add('active');
                    }
                });
                
                // Close menu when clicking outside
                document.addEventListener('click', function(e) {
                    if (!fabButton.contains(e.target) && !fabMenu.contains(e.target)) {
                        fabMenu.classList.remove('open');
                        fabButton.classList.remove('active');
                    }
                });
            }
        })();
    </script>
</body>
</html>

