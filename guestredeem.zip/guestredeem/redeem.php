<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';

use PDO;
use PDOException;

$userId = isset($_GET['user_id']) ? (int) $_GET['user_id'] : 0;
$user = null;
$products = [];
$vouchers = [];
$totalVoucherValue = 0;
$errors = [];
$successMessage = null;

if ($userId <= 0) {
    $errors[] = 'ID tamu tidak valid.';
} else {
    try {
        $pdo = getDbConnection();
        
        // Ambil data user
        $userStmt = $pdo->prepare('SELECT id, name, branch, voucher_code FROM users WHERE id = :id LIMIT 1');
        $userStmt->execute([':id' => $userId]);
        $user = $userStmt->fetch();
        
        if (!$user) {
            $errors[] = 'Tamu tidak ditemukan.';
        } else {
            // Ambil produk yang aktif (jika kolom is_active ada, jika tidak ambil semua)
            try {
                $productStmt = $pdo->query('SELECT id, name, price, gambar, qty, kode_product FROM products WHERE (is_active = 1 OR is_active IS NULL) ORDER BY name ASC');
            } catch (PDOException $e) {
                // Jika kolom is_active tidak ada, ambil semua produk
                $productStmt = $pdo->query('SELECT id, name, price, gambar, qty, kode_product FROM products ORDER BY name ASC');
            }
            $products = $productStmt->fetchAll();
            
            // Ambil variants untuk setiap produk
            $variantsMap = [];
            if (!empty($products)) {
                $productIds = array_map(function($p) { return (int) $p['id']; }, $products);
                $placeholders = implode(',', array_fill(0, count($productIds), '?'));
                $variantStmt = $pdo->prepare("SELECT id, product_id, variant_name, price, sku, stock, is_active FROM product_variants WHERE product_id IN ($placeholders) AND is_active = 1 ORDER BY product_id, variant_name ASC");
                $variantStmt->execute($productIds);
                $variants = $variantStmt->fetchAll();
                
                foreach ($variants as $variant) {
                    $productId = (int) $variant['product_id'];
                    if (!isset($variantsMap[$productId])) {
                        $variantsMap[$productId] = [];
                    }
                    $variantsMap[$productId][] = $variant;
                }
            }
            
            // Ambil voucher user yang masih unused
            $voucherStmt = $pdo->prepare('SELECT id, code, value FROM vouchers WHERE owner_user_id = :user_id AND status = "unused" ORDER BY created_at ASC');
            $voucherStmt->execute([':user_id' => $userId]);
            $vouchers = $voucherStmt->fetchAll();
            
            // Hitung total nilai voucher
            foreach ($vouchers as $voucher) {
                $totalVoucherValue += (int) $voucher['value'];
            }
        }
    } catch (PDOException $exception) {
        $errors[] = 'Gagal memuat data: ' . $exception->getMessage();
    }
}

// Handle checkout
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['checkout'])) {
    $cartItems = isset($_POST['cart_items']) ? json_decode($_POST['cart_items'], true) : [];
    $voucherIds = isset($_POST['voucher_ids']) ? array_map('intval', $_POST['voucher_ids']) : [];
    
    if (empty($cartItems)) {
        $errors[] = 'Keranjang kosong.';
    } elseif (empty($voucherIds)) {
        $errors[] = 'Pilih minimal satu voucher.';
    } else {
        try {
            $pdo = getDbConnection();
            $pdo->beginTransaction();
            
            // Validasi voucher (bisa dari user sendiri atau voucher yang dimasukkan dengan kode)
            $voucherStmt = $pdo->prepare('SELECT id, value FROM vouchers WHERE id = :id AND status = "unused"');
            $totalVoucherValue = 0;
            $validVouchers = [];
            
            foreach ($voucherIds as $voucherId) {
                $voucherStmt->execute([':id' => $voucherId]);
                $voucher = $voucherStmt->fetch();
                if ($voucher) {
                    $validVouchers[] = $voucher;
                    $totalVoucherValue += (int) $voucher['value'];
                }
            }
            
            if (empty($validVouchers)) {
                throw new Exception('Voucher tidak valid atau sudah digunakan.');
            }
            
            // Hitung total harga
            $totalPrice = 0;
            $productStmt = $pdo->prepare('SELECT id, price FROM products WHERE id = :id');
            $variantStmt = $pdo->prepare('SELECT id, price FROM product_variants WHERE id = :id');
            $validItems = [];
            
            foreach ($cartItems as $item) {
                $productId = (int) $item['product_id'];
                $variantId = isset($item['variant_id']) ? (int) $item['variant_id'] : null;
                $qty = isset($item['qty']) ? (int) $item['qty'] : 1;
                $itemPrice = 0;
                
                // Jika ada variant_id, gunakan harga variant
                if ($variantId) {
                    $variantStmt->execute([':id' => $variantId]);
                    $variant = $variantStmt->fetch();
                    if ($variant) {
                        // Gunakan harga variant jika ada, jika tidak gunakan harga produk
                        $itemPrice = $variant['price'] !== null ? (int) $variant['price'] : 0;
                        if ($itemPrice === 0) {
                            $productStmt->execute([':id' => $productId]);
                            $product = $productStmt->fetch();
                            $itemPrice = $product ? (int) $product['price'] : 0;
                        }
                    }
                } else {
                    // Gunakan harga produk
                    $productStmt->execute([':id' => $productId]);
                    $product = $productStmt->fetch();
                    if ($product) {
                        $itemPrice = (int) $product['price'];
                    }
                }
                
                if ($itemPrice > 0) {
                    $itemPrice = $itemPrice * $qty;
                    $totalPrice += $itemPrice;
                    $notes = isset($item['notes']) ? trim($item['notes']) : null;
                    $validItems[] = [
                        'product_id' => $productId,
                        'variant_id' => $variantId,
                        'price' => $itemPrice,
                        'qty' => $qty,
                        'notes' => $notes && $notes !== '' ? $notes : null
                    ];
                }
            }
            
            if (empty($validItems)) {
                throw new Exception('Tidak ada item valid di keranjang.');
            }
            
            $voucherCovered = min($totalVoucherValue, $totalPrice);
            $extraCharge = max(0, $totalPrice - $totalVoucherValue);
            
            // Simpan transaksi untuk setiap produk
            $transactionStmt = $pdo->prepare('INSERT INTO transactions (user_id, product_id, variant_id, total_price, voucher_covered, extra_charge, notes) VALUES (:user_id, :product_id, :variant_id, :total_price, :voucher_covered, :extra_charge, :notes)');
            $transactionVoucherStmt = $pdo->prepare('INSERT INTO transaction_vouchers (transaction_id, voucher_id, amount_applied) VALUES (:transaction_id, :voucher_id, :amount_applied)');
            $updateVoucherStmt = $pdo->prepare('UPDATE vouchers SET status = "used" WHERE id = :id');
            
            $remainingVoucher = $totalVoucherValue;
            
            foreach ($validItems as $item) {
                $voucherForThisItem = min($remainingVoucher, $item['price']);
                $extraForThisItem = max(0, $item['price'] - $voucherForThisItem);
                
                $transactionStmt->execute([
                    ':user_id' => $userId,
                    ':product_id' => $item['product_id'],
                    ':variant_id' => isset($item['variant_id']) && $item['variant_id'] > 0 ? $item['variant_id'] : null,
                    ':total_price' => $item['price'],
                    ':voucher_covered' => $voucherForThisItem,
                    ':extra_charge' => $extraForThisItem,
                    ':notes' => isset($item['notes']) ? $item['notes'] : null,
                ]);
                
                $transactionId = (int) $pdo->lastInsertId();
                
                // Assign voucher ke transaksi
                $voucherUsed = 0;
                foreach ($validVouchers as $voucher) {
                    if ($voucherUsed >= $voucherForThisItem) {
                        break;
                    }
                    $amountToUse = min((int) $voucher['value'], $voucherForThisItem - $voucherUsed);
                    if ($amountToUse > 0) {
                        $transactionVoucherStmt->execute([
                            ':transaction_id' => $transactionId,
                            ':voucher_id' => (int) $voucher['id'],
                            ':amount_applied' => $amountToUse,
                        ]);
                        $voucherUsed += $amountToUse;
                    }
                }
                
                $remainingVoucher -= $voucherForThisItem;
            }
            
            // Update status voucher menjadi used
            foreach ($validVouchers as $voucher) {
                $updateVoucherStmt->execute([':id' => (int) $voucher['id']]);
            }
            
            $pdo->commit();
            $successMessage = 'Transaksi berhasil! Total: Rp ' . number_format($totalPrice, 0, ',', '.') . 
                            ($extraCharge > 0 ? ' (Kekurangan: Rp ' . number_format($extraCharge, 0, ',', '.') . ')' : '');
        } catch (Exception $exception) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $errors[] = 'Gagal checkout: ' . $exception->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Redeem Voucher</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <style>
        .redeem-page {
            max-width: 1400px;
            margin: 0 auto;
            padding: 2rem;
        }
        
        .redeem-header {
            background: linear-gradient(135deg, #1d4ed8, #3b82f6);
            color: #fff;
            padding: 2rem;
            border-radius: 1.25rem;
            margin-bottom: 2rem;
            box-shadow: 0 20px 45px rgba(3, 7, 18, 0.35);
        }
        
        .redeem-header h1 {
            margin: 0 0 0.5rem;
            font-size: 2rem;
        }
        
        .voucher-info {
            display: flex;
            gap: 2rem;
            margin-top: 1rem;
            flex-wrap: wrap;
        }
        
        .voucher-card {
            background: rgba(255, 255, 255, 0.15);
            padding: 1rem 1.5rem;
            border-radius: 0.85rem;
            backdrop-filter: blur(10px);
        }
        
        .voucher-card strong {
            display: block;
            font-size: 1.5rem;
            margin-top: 0.25rem;
        }
        
        .products-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }
        
        .product-card {
            background: #fff;
            border-radius: 1rem;
            overflow: hidden;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            transition: transform 0.2s ease, box-shadow 0.2s ease;
            display: flex;
            flex-direction: column;
        }
        
        .product-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.15);
        }
        
        .product-image-wrapper {
            width: 100%;
            height: 200px;
            background: #f1f5f9;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
        }
        
        .product-image {
            width: 100%;
            background-color:rgb(255, 255, 255);
            height: 100%;
            object-fit: contain;
            padding: 0.5rem;
        }
        
        .product-image-svg {
            width: 100%;
            height: 100%;
            padding: 1rem;
            background: #e2e8f0;
        }
        
        .product-info {
            padding: 1.25rem;
            display: flex;
            flex-direction: column;
            flex: 1;
        }
        
        .product-name {
            font-size: 1.1rem;
            font-weight: 600;
            margin: 0 0 0.5rem;
            color: var(--text);
        }
        
        .product-price {
            font-size: 1.25rem;
            font-weight: 700;
            color: var(--primary);
            margin: 0.5rem 0;
        }
        
        .product-qty {
            font-size: 0.9rem;
            color: var(--muted);
            margin-top: 0.5rem;
        }
        
        .product-add-btn {
            margin-top: auto;
            width: 100%;
            padding: 0.75rem;
            background: var(--primary);
            color: #fff;
            border: none;
            border-radius: 0.5rem;
            font-weight: 600;
            cursor: pointer;
            transition: background 0.2s ease;
        }
        
        .product-add-btn:hover {
            background: var(--primary-dark, #1d4ed8);
        }
        
        .product-add-btn:active {
            transform: scale(0.98);
        }
        
        .cart-sidebar {
            position: fixed;
            right: -400px;
            top: 0;
            width: 400px;
            height: 100vh;
            background: #fff;
            box-shadow: -4px 0 24px rgba(0, 0, 0, 0.15);
            transition: right 0.3s ease;
            z-index: 1000;
            display: flex;
            flex-direction: column;
        }
        
        .cart-sidebar.open {
            right: 0;
        }
        
        .cart-header {
            padding: 1.5rem;
            border-bottom: 1px solid var(--border);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .cart-body {
            flex: 1;
            overflow-y: auto;
            padding: 1rem;
        }
        
        .cart-item {
            display: flex;
            gap: 1rem;
            padding: 1rem;
            border-bottom: 1px solid var(--border);
        }
        
        .cart-item-image {
            width: 80px;
            height: 80px;
            object-fit: cover;
            border-radius: 0.5rem;
            background: #f1f5f9;
        }
        
        .cart-item-info {
            flex: 1;
        }
        
        .cart-item-name {
            font-weight: 600;
            margin-bottom: 0.25rem;
        }
        
        .cart-item-price {
            color: var(--muted);
            font-size: 0.9rem;
        }
        
        .cart-item-qty {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            margin-top: 0.5rem;
        }
        
        .qty-btn {
            width: 28px;
            height: 28px;
            border: 1px solid var(--border);
            background: #fff;
            border-radius: 0.35rem;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
        }
        
        .qty-input {
            width: 50px;
            text-align: center;
            border: 1px solid var(--border);
            border-radius: 0.35rem;
            padding: 0.25rem;
        }
        
        .remove-item {
            color: var(--danger);
            cursor: pointer;
            font-size: 1.25rem;
            padding: 0.25rem;
        }
        
        .cart-footer {
            padding: 1.5rem;
            border-top: 1px solid var(--border);
            background: #f8fafc;
        }
        
        .cart-summary {
            margin-bottom: 1rem;
        }
        
        .summary-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 0.5rem;
        }
        
        .summary-total {
            font-size: 1.25rem;
            font-weight: 700;
            color: var(--text);
            margin-top: 0.5rem;
            padding-top: 0.5rem;
            border-top: 2px solid var(--border);
        }
        
        .cart-toggle {
            position: fixed;
            bottom: 8rem;
            right: 2rem;
            width: 64px;
            height: 64px;
            border-radius: 50%;
            background: var(--warning);
            color: #fff;
            border: none;
            font-size: 1.5rem;
            cursor: pointer;
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.2);
            z-index: 999;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .cart-badge {
            position: absolute;
            top: -8px;
            right: -8px;
            background: var(--danger);
            color: #fff;
            border-radius: 50%;
            width: 24px;
            height: 24px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.75rem;
            font-weight: 600;
        }
        
        .voucher-selection {
            margin: 1rem 0;
            padding: 1rem;
            background: #f8fafc;
            border-radius: 0.85rem;
        }
        
        .voucher-checkbox {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            margin-bottom: 0.5rem;
        }
        
        .fab {
            left: 2rem;
            right: auto;
            text-decoration: none;
        }
        
        #productSearch:focus {
            outline: none;
            border-color: var(--primary, #3b82f6);
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
        }
        
        .image-preview-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.9);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 10001;
            opacity: 0;
            visibility: hidden;
            transition: opacity 0.3s ease, visibility 0.3s ease;
            cursor: pointer;
        }
        
        .image-preview-overlay.open {
            opacity: 1;
            visibility: visible;
        }
        
        .image-preview-container {
            position: relative;
            max-width: 90%;
            max-height: 90vh;
            display: flex;
            flex-direction: column;
            align-items: center;
            cursor: default;
        }
        
        .image-preview-container img {
            max-width: 100%;
            max-height: 85vh;
            object-fit: contain;
            border-radius: 0.5rem;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.5);
        }
        
        .image-preview-title {
            color: #fff;
            margin-top: 1rem;
            font-size: 1.1rem;
            text-align: center;
            padding: 0 1rem;
        }
        
        .image-preview-close {
            position: absolute;
            top: -2.5rem;
            right: 0;
            background: rgba(255, 255, 255, 0.2);
            color: #fff;
            border: none;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            font-size: 1.5rem;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: background 0.2s ease;
        }
        
        .image-preview-close:hover {
            background: rgba(255, 255, 255, 0.3);
        }
        
        .modal-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.5);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 10000;
            opacity: 0;
            visibility: hidden;
            transition: opacity 0.3s ease, visibility 0.3s ease;
            pointer-events: none;
        }
        
        .modal-overlay.open {
            opacity: 1;
            visibility: visible;
            pointer-events: auto;
        }
        
        .modal {
            background: #fff;
            border-radius: 1rem;
            padding: 2rem;
            max-width: 400px;
            width: 90%;
            box-shadow: 0 20px 45px rgba(0, 0, 0, 0.3);
            transform: scale(0.9);
            transition: transform 0.3s ease;
            pointer-events: auto;
            position: relative;
            z-index: 10001;
        }
        
        .modal-overlay.open .modal {
            transform: scale(1);
        }
        
        .modal h3 {
            margin: 0 0 1rem;
            font-size: 1.5rem;
        }
        
        .modal p {
            margin: 0 0 1.5rem;
            color: var(--muted);
        }
        
        .modal-actions {
            display: flex;
            gap: 1rem;
            justify-content: flex-end;
        }
        
        .modal-actions button {
            pointer-events: auto;
            cursor: pointer;
            position: relative;
            z-index: 10002;
        }
        
        .modal-actions button:hover {
            opacity: 0.9;
        }
        
        .modal-actions button:active {
            transform: scale(0.98);
        }
        
        .variant-selection {
            margin: 1rem 0;
        }
        
        .variant-option {
            padding: 0.75rem;
            border: 2px solid var(--border, #e2e8f0);
            border-radius: 0.5rem;
            margin-bottom: 0.75rem;
            cursor: pointer;
            transition: all 0.2s ease;
        }
        
        .variant-option:hover {
            border-color: var(--primary, #3b82f6);
            background: #f0f7ff;
        }
        
        .variant-option.selected {
            border-color: var(--primary, #3b82f6);
            background: #eff6ff;
        }
        
        .variant-name {
            font-weight: 600;
            margin-bottom: 0.25rem;
        }
        
        .variant-details {
            display: flex;
            justify-content: space-between;
            font-size: 0.9rem;
            color: var(--muted, #64748b);
        }
        
        .variant-price {
            color: var(--primary, #3b82f6);
            font-weight: 600;
        }
        
        .variant-stock {
            font-size: 0.85rem;
        }
        
        .variant-stock.out-of-stock {
            color: var(--danger, #ef4444);
        }
        
        @media (max-width: 768px) {
            .cart-sidebar {
                width: 100%;
                right: -100%;
            }
            
            .products-grid {
                grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            }
        }
    </style>
</head>
<body>
    <div class="redeem-page">
        <?php if (!empty($errors)) : ?>
            <?php foreach ($errors as $error) : ?>
                <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
            <?php endforeach; ?>
        <?php endif; ?>
        
        <?php if ($user) : ?>
            <div class="redeem-header">
                <h1>Redeem Voucher</h1>
                <p>Selamat datang, <strong><?= htmlspecialchars($user['name']) ?></strong>!</p>
                <div class="voucher-info">
                    <div class="voucher-card">
                        <small>Total Voucher</small>
                        <strong id="totalVoucherValue">Rp <?= number_format($totalVoucherValue, 0, ',', '.') ?></strong>
                    </div>
                    <div class="voucher-card">
                        <small>Jumlah Voucher</small>
                        <strong id="voucherCount"><?= count($vouchers) ?> voucher</strong>
                    </div>
                </div>
            </div>
            
            <div style="margin-bottom: 1.5rem;">
                <div style="position: relative; max-width: 500px; margin: 0 auto;">
                    <input type="text" id="productSearch" placeholder="Cari produk..." style="width: 100%; padding: 0.75rem 1rem 0.75rem 2.5rem; border: 2px solid var(--border, #e2e8f0); border-radius: 0.75rem; font-size: 1rem; transition: border-color 0.2s ease, box-shadow 0.2s ease; background: #fff;">
                    <span style="position: absolute; left: 0.75rem; top: 50%; transform: translateY(-50%); color: var(--muted, #64748b); font-size: 1.25rem; pointer-events: none;">🔍</span>
                </div>
            </div>
            
            <div class="products-grid" id="productsGrid">
                <?php foreach ($products as $product) : ?>
                    <div class="product-card" data-product-id="<?= (int) $product['id'] ?>" data-product-price="<?= (int) $product['price'] ?>" data-product-name="<?= htmlspecialchars(strtolower($product['name'])) ?>" data-product-code="<?= htmlspecialchars(strtolower($product['kode_product'] ?? '')) ?>" data-has-variants="<?= isset($variantsMap[(int) $product['id']]) && !empty($variantsMap[(int) $product['id']]) ? '1' : '0' ?>">
                        <div class="product-image-wrapper">
                            <?php if ($product['gambar']) : ?>
                                <img src="<?= htmlspecialchars($product['gambar']) ?>" alt="<?= htmlspecialchars($product['name']) ?>" class="product-image" data-image-src="<?= htmlspecialchars($product['gambar']) ?>" data-product-name="<?= htmlspecialchars($product['name']) ?>" style="cursor: pointer;">
                            <?php else : ?>
                                <svg class="product-image-svg" viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
                                    <rect width="200" height="200" fill="#e2e8f0"/>
                                    <path d="M60 60h80v80H60z" fill="#cbd5e1" stroke="#94a3b8" stroke-width="2"/>
                                    <path d="M70 70l30 30 40-40" fill="none" stroke="#64748b" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
                                    <circle cx="85" cy="85" r="8" fill="#64748b"/>
                                </svg>
                            <?php endif; ?>
                        </div>
                        <div class="product-info">
                            <h3 class="product-name"><?= htmlspecialchars($product['name']) ?></h3>
                            <?php if (!empty($product['kode_product'])) : ?>
                                <div class="product-code" style="font-size: 0.85rem; color: var(--muted, #64748b); margin-bottom: 0.5rem; font-weight: 500;"><?= htmlspecialchars($product['kode_product']) ?></div>
                            <?php endif; ?>
                            <div class="product-price">Rp <?= number_format((int) $product['price'], 0, ',', '.') ?></div>
                            <?php if ($product['qty'] !== null) : ?>
                                <div class="product-qty">Stok: <?= (int) $product['qty'] ?></div>
                            <?php endif; ?>
                            <?php if (isset($variantsMap[(int) $product['id']]) && !empty($variantsMap[(int) $product['id']])) : ?>
                                <div class="product-qty" style="color: var(--primary); font-weight: 500;">Pilih varian tersedia</div>
                            <?php endif; ?>
                            <button type="button" class="product-add-btn" data-product-id="<?= (int) $product['id'] ?>">
                                🛒 Tambah ke Keranjang
                            </button>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else : ?>
            <div class="alert alert-error">Data tamu tidak ditemukan.</div>
        <?php endif; ?>
    </div>
    
    <!-- Cart Sidebar -->
    <button class="cart-toggle" id="cartToggle">
        🛒
        <span class="cart-badge" id="cartBadge" style="display: none;">0</span>
    </button>
    
    <div class="cart-sidebar" id="cartSidebar">
        <div class="cart-header">
            <h2>Keranjang</h2>
            <button type="button" id="closeCart" style="background: none; border: none; font-size: 1.5rem; cursor: pointer;">×</button>
        </div>
        <div class="cart-body" id="cartBody">
            <p style="text-align: center; color: var(--muted); padding: 2rem;">Keranjang kosong</p>
        </div>
        <div class="cart-footer" id="cartFooter" style="display: none;">
            <?php if (empty($vouchers)) : ?>
                <div class="alert alert-error" style="margin: 1rem 0;">
                    Anda tidak memiliki voucher yang dapat digunakan.
                </div>
            <?php else : ?>
                <form method="post" id="checkoutForm">
                    <input type="hidden" name="checkout" value="1">
                    <input type="hidden" name="cart_items" id="cartItemsInput">
                    <div class="voucher-selection">
                        <strong>Pilih Voucher:</strong>
                        <div id="voucherList">
                            <?php foreach ($vouchers as $voucher) : ?>
                                <div class="voucher-checkbox" data-voucher-id="<?= (int) $voucher['id'] ?>">
                                    <input type="checkbox" name="voucher_ids[]" value="<?= (int) $voucher['id'] ?>" id="voucher_<?= (int) $voucher['id'] ?>" checked>
                                    <label for="voucher_<?= (int) $voucher['id'] ?>">
                                        <?= htmlspecialchars($voucher['code']) ?> - Rp <?= number_format((int) $voucher['value'], 0, ',', '.') ?>
                                    </label>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        <div style="margin-top: 1rem; padding-top: 1rem; border-top: 1px solid var(--border);">
                            <strong style="display: block; margin-bottom: 0.5rem;">Tambah Voucher Lain:</strong>
                            <div style="display: flex; gap: 0.5rem;">
                                <input type="text" id="voucherCodeInput" placeholder="Masukkan kode voucher" style="flex: 1; padding: 0.5rem; border: 1px solid var(--border); border-radius: 0.5rem;">
                                <button type="button" id="addVoucherBtn" class="btn btn-primary" style="padding: 0.5rem 1rem;">Tambah</button>
                            </div>
                            <div id="voucherMessage" style="margin-top: 0.5rem; font-size: 0.875rem;"></div>
                        </div>
                    </div>
                    <div class="cart-summary" id="cartSummary"></div>
                    <button type="submit" class="btn btn-primary" style="width: 100%;">Checkout</button>
                </form>
            <?php endif; ?>
        </div>
    </div>
    
    <script>
        (function() {
            var cart = [];
            var products = <?= json_encode($products) ?>;
            var vouchers = <?= json_encode($vouchers) ?>;
            var totalVoucherValue = <?= $totalVoucherValue ?>;
            var variantsMap = <?= json_encode($variantsMap ?? []) ?>;
            
            var cartToggle = document.getElementById('cartToggle');
            var cartSidebar = document.getElementById('cartSidebar');
            var closeCart = document.getElementById('closeCart');
            var cartBody = document.getElementById('cartBody');
            var cartFooter = document.getElementById('cartFooter');
            var cartBadge = document.getElementById('cartBadge');
            var cartItemsInput = document.getElementById('cartItemsInput');
            var cartSummary = document.getElementById('cartSummary');
            var checkoutForm = document.getElementById('checkoutForm');
            
            // Product search/filter
            var productSearch = document.getElementById('productSearch');
            var productsGrid = document.getElementById('productsGrid');
            
            if (productSearch && productsGrid) {
                productSearch.addEventListener('input', function(e) {
                    var searchTerm = e.target.value.toLowerCase().trim();
                    var productCards = productsGrid.querySelectorAll('.product-card');
                    var visibleCount = 0;
                    
                    productCards.forEach(function(card) {
                        var productName = card.getAttribute('data-product-name') || '';
                        var productCode = card.getAttribute('data-product-code') || '';
                        
                        if (searchTerm === '' || productName.includes(searchTerm) || productCode.includes(searchTerm)) {
                            card.style.display = '';
                            visibleCount++;
                        } else {
                            card.style.display = 'none';
                        }
                    });
                    
                    // Tampilkan pesan jika tidak ada hasil
                    var emptyState = productsGrid.querySelector('.empty-state-search');
                    if (visibleCount === 0 && searchTerm !== '') {
                        if (!emptyState) {
                            emptyState = document.createElement('div');
                            emptyState.className = 'empty-state-search';
                            emptyState.style.cssText = 'grid-column: 1 / -1; text-align: center; padding: 3rem; color: var(--muted, #64748b);';
                            emptyState.innerHTML = '<p style="font-size: 1.1rem; margin: 0;">Produk tidak ditemukan</p><p style="font-size: 0.9rem; margin-top: 0.5rem;">Coba cari dengan kata kunci lain</p>';
                            productsGrid.appendChild(emptyState);
                        }
                        emptyState.style.display = 'block';
                    } else {
                        if (emptyState) {
                            emptyState.style.display = 'none';
                        }
                    }
                });
                
                // Focus pada input saat page load (optional)
                // productSearch.focus();
            }
            
            // Product image preview
            productsGrid.addEventListener('click', function(e) {
                var img = e.target;
                
                // Cek apakah yang diklik adalah gambar produk
                if (img && img.classList.contains('product-image') && img.dataset.imageSrc) {
                    e.preventDefault();
                    e.stopPropagation();
                    
                    var imageSrc = img.dataset.imageSrc;
                    var productName = img.dataset.productName || 'Preview Produk';
                    
                    // Tampilkan modal preview
                    var previewOverlay = document.getElementById('imagePreviewOverlay');
                    var previewImg = document.getElementById('imagePreviewImg');
                    var previewTitle = document.getElementById('imagePreviewTitle');
                    
                    if (previewOverlay && previewImg) {
                        previewImg.src = imageSrc;
                        previewImg.alt = productName;
                        if (previewTitle) {
                            previewTitle.textContent = productName;
                        }
                        previewOverlay.classList.add('open');
                    }
                    
                    return false;
                }
                
                // Product add to cart buttons (dengan event delegation untuk produk yang difilter)
                var btn = e.target.closest('.product-add-btn');
                if (btn) {
                    e.stopPropagation();
                    var productId = parseInt(btn.dataset.productId);
                    var product = products.find(function(p) { return p.id == productId; });
                    if (product) {
                        // Langsung add to cart tanpa modal notes (notes bisa di-edit dari cart)
                        addToCart(product, null, null, null, '');
                    }
                }
            });
            
            function addToCart(product, variantId, variantName, variantPrice, notes) {
                // Cek apakah produk punya variant
                var productVariants = variantsMap[product.id] || [];
                
                if (productVariants.length > 0 && !variantId) {
                    // Tampilkan modal pilih variant
                    showVariantModal(product, productVariants);
                    return;
                }
                
                // Tentukan harga yang digunakan
                var finalPrice = parseInt(product.price);
                if (variantId && variantPrice !== null && variantPrice !== undefined) {
                    finalPrice = parseInt(variantPrice) || finalPrice;
                }
                
                // Cek apakah item dengan product_id dan variant_id yang sama sudah ada
                var existing = cart.find(function(item) { 
                    return item.product_id == product.id && 
                           ((!item.variant_id && !variantId) || (item.variant_id == variantId));
                });
                
                if (existing) {
                    existing.qty++;
                    // Update notes jika ada
                    if (notes !== undefined && notes !== null) {
                        existing.notes = notes || '';
                    }
                } else {
                    cart.push({
                        product_id: product.id,
                        variant_id: variantId || null,
                        name: product.name + (variantName ? ' - ' + variantName : ''),
                        price: finalPrice,
                        gambar: product.gambar || null,
                        qty: 1,
                        notes: notes || ''
                    });
                }
                updateCart();
                cartSidebar.classList.add('open');
            }
            
            function showNotesModal(product, variantId, variantName, variantPrice, callback) {
                var modal = document.getElementById('notesModal');
                var notesInput = document.getElementById('notesInput');
                var notesTitle = document.getElementById('notesModalTitle');
                var confirmNotesBtn = document.getElementById('confirmNotesBtn');
                
                if (!modal || !notesInput) {
                    // Jika modal tidak ada, langsung add tanpa notes
                    if (callback) callback('');
                    return;
                }
                
                // Set title
                if (notesTitle) {
                    notesTitle.textContent = 'Tambah Catatan: ' + product.name + (variantName ? ' - ' + variantName : '');
                }
                
                // Clear previous notes
                notesInput.value = '';
                
                // Show modal
                modal.classList.add('open');
                notesInput.focus();
                
                // Handle confirm
                var handleConfirm = function() {
                    var notes = notesInput.value.trim();
                    modal.classList.remove('open');
                    if (callback) callback(notes);
                };
                
                // Remove old listeners
                var newConfirmBtn = confirmNotesBtn.cloneNode(true);
                confirmNotesBtn.parentNode.replaceChild(newConfirmBtn, confirmNotesBtn);
                
                newConfirmBtn.addEventListener('click', handleConfirm);
                
                // Enter key support
                notesInput.onkeydown = function(e) {
                    if (e.key === 'Enter' && e.ctrlKey) {
                        handleConfirm();
                    }
                };
            }
            
            function showVariantModal(product, variants) {
                var modal = document.getElementById('variantModal');
                var modalTitle = document.getElementById('variantModalTitle');
                var variantList = document.getElementById('variantList');
                var selectedVariantId = null;
                
                if (!modal || !modalTitle || !variantList) {
                    return;
                }
                
                modalTitle.textContent = 'Pilih Varian: ' + product.name;
                
                var html = '';
                variants.forEach(function(variant) {
                    var variantPrice = variant.price !== null && variant.price !== undefined 
                        ? parseInt(variant.price) 
                        : parseInt(product.price);
                    var stock = variant.stock !== null ? parseInt(variant.stock) : null;
                    var isOutOfStock = stock !== null && stock <= 0;
                    
                    html += '<div class="variant-option' + (isOutOfStock ? ' out-of-stock' : '') + '" data-variant-id="' + variant.id + '" data-variant-price="' + variantPrice + '" data-variant-name="' + escapeHtml(variant.variant_name) + '">';
                    html += '<div class="variant-name">' + escapeHtml(variant.variant_name) + '</div>';
                    html += '<div class="variant-details">';
                    html += '<span class="variant-price">Rp ' + variantPrice.toLocaleString('id-ID') + '</span>';
                    if (stock !== null) {
                        html += '<span class="variant-stock' + (isOutOfStock ? ' out-of-stock' : '') + '">Stok: ' + stock + '</span>';
                    }
                    html += '</div>';
                    html += '</div>';
                });
                
                variantList.innerHTML = html;
                
                // Attach click handlers
                variantList.querySelectorAll('.variant-option').forEach(function(option) {
                    var isOutOfStock = option.classList.contains('out-of-stock');
                    
                    if (!isOutOfStock) {
                        option.style.cursor = 'pointer';
                        option.addEventListener('click', function() {
                            // Remove previous selection
                            variantList.querySelectorAll('.variant-option').forEach(function(opt) {
                                opt.classList.remove('selected');
                            });
                            
                            // Select this variant
                            option.classList.add('selected');
                            selectedVariantId = parseInt(option.dataset.variantId);
                        });
                    } else {
                        option.style.cursor = 'not-allowed';
                        option.style.opacity = '0.6';
                    }
                });
                
                // Reset confirm button
                var confirmVariantBtn = document.getElementById('confirmVariantBtn');
                if (confirmVariantBtn) {
                    confirmVariantBtn.onclick = function() {
                        if (!selectedVariantId) {
                            alert('Pilih varian terlebih dahulu.');
                            return;
                        }
                        
                        var selectedOption = variantList.querySelector('.variant-option.selected');
                        if (selectedOption) {
                            var variantPrice = selectedOption.dataset.variantPrice;
                            var variantName = selectedOption.dataset.variantName;
                            
                            // Close variant modal
                            modal.classList.remove('open');
                            
                            // Langsung add to cart tanpa modal notes (notes bisa di-edit dari cart)
                            addToCart(product, selectedVariantId, variantName, variantPrice, '');
                        }
                    };
                }
                
                // Show modal
                modal.classList.add('open');
            }
            
            function escapeHtml(text) {
                var div = document.createElement('div');
                div.textContent = text;
                return div.innerHTML;
            }
            
            function removeFromCart(productId, variantId) {
                cart = cart.filter(function(item) { 
                    if (variantId === null || variantId === 'null') {
                        return !(item.product_id == productId && !item.variant_id);
                    }
                    return !(item.product_id == productId && item.variant_id == variantId);
                });
                updateCart();
            }
            
            function updateQty(productId, newQty, variantId) {
                var item = cart.find(function(i) { 
                    if (variantId === null || variantId === 'null') {
                        return i.product_id == productId && !i.variant_id;
                    }
                    return i.product_id == productId && i.variant_id == variantId;
                });
                if (item) {
                    if (newQty <= 0) {
                        removeFromCart(productId, variantId);
                    } else {
                        item.qty = newQty;
                        updateCart();
                    }
                }
            }
            
            function updateCart() {
                if (cart.length === 0) {
                    cartBody.innerHTML = '<p style="text-align: center; color: var(--muted); padding: 2rem;">Keranjang kosong</p>';
                    cartFooter.style.display = 'none';
                    cartBadge.style.display = 'none';
                } else {
                    var html = '';
                    cart.forEach(function(item, index) {
                        html += '<div class="cart-item" data-item-index="' + index + '">';
                        if (item.gambar) {
                            html += '<img src="' + item.gambar + '" alt="" class="cart-item-image">';
                        } else {
                            html += '<div class="cart-item-image" style="display: flex; align-items: center; justify-content: center; background: #f1f5f9;">📦</div>';
                        }
                        html += '<div class="cart-item-info" style="flex: 1;">';
                        html += '<div class="cart-item-name">' + item.name + '</div>';
                        html += '<div class="cart-item-price">Rp ' + item.price.toLocaleString('id-ID') + (item.variant_id ? ' <small style="color: var(--muted);">(Varian)</small>' : '') + '</div>';
                        html += '<div class="cart-item-qty">';
                        html += '<button type="button" class="qty-btn" onclick="updateQty(' + item.product_id + ', ' + (item.qty - 1) + ', ' + (item.variant_id || 'null') + ')">-</button>';
                        html += '<input type="number" class="qty-input" value="' + item.qty + '" min="1" onchange="updateQty(' + item.product_id + ', parseInt(this.value), ' + (item.variant_id || 'null') + ')">';
                        html += '<button type="button" class="qty-btn" onclick="updateQty(' + item.product_id + ', ' + (item.qty + 1) + ', ' + (item.variant_id || 'null') + ')">+</button>';
                        html += '</div>';
                        html += '<div class="cart-item-notes" style="margin-top: 0.5rem;">';
                        html += '<div style="display: flex; align-items: center; gap: 0.5rem;">';
                        html += '<span style="font-size: 0.85rem; color: var(--muted);">📝 Catatan:</span>';
                        html += '<button type="button" onclick="editItemNotes(' + index + ')" style="background: none; border: none; color: var(--primary); cursor: pointer; font-size: 0.85rem; padding: 0.25rem 0.5rem; border-radius: 0.25rem; transition: background 0.2s;">';
                        html += item.notes ? escapeHtml(item.notes.substring(0, 30) + (item.notes.length > 30 ? '...' : '')) : 'Tambah catatan';
                        html += '</button>';
                        html += '</div>';
                        if (item.notes) {
                            html += '<div style="font-size: 0.8rem; color: var(--muted); margin-top: 0.25rem; padding: 0.5rem; background: #f8fafc; border-radius: 0.25rem; max-width: 100%; word-wrap: break-word;">' + escapeHtml(item.notes) + '</div>';
                        }
                        html += '</div>';
                        html += '</div>';
                        html += '<button type="button" class="remove-item" onclick="removeFromCart(' + item.product_id + ', ' + (item.variant_id || 'null') + ')">×</button>';
                        html += '</div>';
                    });
                    cartBody.innerHTML = html;
                    cartFooter.style.display = 'block';
                    
                    var totalItems = cart.reduce(function(sum, item) { return sum + item.qty; }, 0);
                    cartBadge.textContent = totalItems;
                    cartBadge.style.display = 'block';
                    
                    updateSummary();
                    
                    // Update hidden input
                    cartItemsInput.value = JSON.stringify(cart);
                    
                    // Attach event listener untuk tombol checkout (fallback)
                    var checkoutBtn = document.querySelector('#checkoutForm button[type="submit"]');
                    if (checkoutBtn && !checkoutBtn.hasAttribute('data-listener-attached')) {
                        checkoutBtn.setAttribute('data-listener-attached', 'true');
                        checkoutBtn.addEventListener('click', function(e) {
                            // Biarkan form submit event yang handle
                            // Ini hanya untuk memastikan tombol bisa diklik
                        });
                    }
                }
            }
            
            function updateSummary() {
                var totalPrice = cart.reduce(function(sum, item) { return sum + (item.price * item.qty); }, 0);
                
                // Hitung total voucher yang dipilih
                var selectedVouchers = Array.from(document.querySelectorAll('input[name="voucher_ids[]"]:checked'));
                var selectedVoucherValue = selectedVouchers.reduce(function(sum, checkbox) {
                    var voucherId = parseInt(checkbox.value);
                    var voucher = vouchers.find(function(v) { return v.id == voucherId; });
                    return sum + (voucher ? parseInt(voucher.value) : 0);
                }, 0);
                
                var voucherCovered = Math.min(selectedVoucherValue, totalPrice);
                var extraCharge = Math.max(0, totalPrice - selectedVoucherValue);
                
                var summaryHtml = '';
                summaryHtml += '<div class="summary-row"><span>Subtotal:</span><span>Rp ' + totalPrice.toLocaleString('id-ID') + '</span></div>';
                summaryHtml += '<div class="summary-row"><span>Voucher:</span><span>- Rp ' + voucherCovered.toLocaleString('id-ID') + '</span></div>';
                if (extraCharge > 0) {
                    summaryHtml += '<div class="summary-row" style="color: var(--danger);"><span>Kekurangan:</span><span>Rp ' + extraCharge.toLocaleString('id-ID') + '</span></div>';
                }
                summaryHtml += '<div class="summary-row summary-total"><span>Total:</span><span>Rp ' + totalPrice.toLocaleString('id-ID') + '</span></div>';
                cartSummary.innerHTML = summaryHtml;
            }
            
            // Update summary ketika voucher dipilih/di-uncheck
            document.addEventListener('change', function(e) {
                if (e.target.name === 'voucher_ids[]') {
                    updateSummary();
                }
            });
            
            // Tambah voucher dengan kode
            var addVoucherBtn = document.getElementById('addVoucherBtn');
            var voucherCodeInput = document.getElementById('voucherCodeInput');
            var voucherMessage = document.getElementById('voucherMessage');
            var voucherList = document.getElementById('voucherList');
            
            if (addVoucherBtn && voucherCodeInput) {
                addVoucherBtn.addEventListener('click', function() {
                    var code = voucherCodeInput.value.trim();
                    if (!code) {
                        voucherMessage.textContent = 'Masukkan kode voucher.';
                        voucherMessage.style.color = 'var(--danger)';
                        return;
                    }
                    
                    // Cek apakah voucher sudah ada
                    var existing = vouchers.find(function(v) { return v.code === code; });
                    if (existing) {
                        voucherMessage.textContent = 'Voucher sudah ditambahkan.';
                        voucherMessage.style.color = 'var(--danger)';
                        return;
                    }
                    
                    // Disable button
                    addVoucherBtn.disabled = true;
                    addVoucherBtn.textContent = 'Memproses...';
                    voucherMessage.textContent = '';
                    
                    // AJAX request
                    var formData = new FormData();
                    formData.append('voucher_code', code);
                    formData.append('user_id', <?= $userId ?>);
                    
                    fetch('add_voucher.php', {
                        method: 'POST',
                        body: formData
                    })
                    .then(function(response) {
                        return response.json();
                    })
                    .then(function(data) {
                        if (data.success) {
                            // Tambahkan voucher ke array
                            vouchers.push(data.voucher);
                            
                            // Update total voucher value
                            totalVoucherValue += data.voucher.value;
                            
                            // Update header
                            var totalVoucherEl = document.getElementById('totalVoucherValue');
                            var voucherCountEl = document.getElementById('voucherCount');
                            if (totalVoucherEl) {
                                totalVoucherEl.textContent = 'Rp ' + totalVoucherValue.toLocaleString('id-ID');
                            }
                            if (voucherCountEl) {
                                voucherCountEl.textContent = vouchers.length + ' voucher';
                            }
                            
                            // Tambahkan ke UI
                            var voucherDiv = document.createElement('div');
                            voucherDiv.className = 'voucher-checkbox';
                            voucherDiv.setAttribute('data-voucher-id', data.voucher.id);
                            voucherDiv.innerHTML = '<input type="checkbox" name="voucher_ids[]" value="' + data.voucher.id + '" id="voucher_' + data.voucher.id + '" checked><label for="voucher_' + data.voucher.id + '">' + data.voucher.code + ' - Rp ' + data.voucher.value.toLocaleString('id-ID') + '</label>';
                            voucherList.appendChild(voucherDiv);
                            
                            voucherMessage.textContent = data.message;
                            voucherMessage.style.color = 'var(--success, #10b981)';
                            voucherCodeInput.value = '';
                            
                            // Update summary
                            updateSummary();
                        } else {
                            voucherMessage.textContent = data.message;
                            voucherMessage.style.color = 'var(--danger)';
                        }
                    })
                    .catch(function(error) {
                        voucherMessage.textContent = 'Gagal menambahkan voucher.';
                        voucherMessage.style.color = 'var(--danger)';
                    })
                    .finally(function() {
                        addVoucherBtn.disabled = false;
                        addVoucherBtn.textContent = 'Tambah';
                    });
                });
                
                // Enter key support
                voucherCodeInput.addEventListener('keypress', function(e) {
                    if (e.key === 'Enter') {
                        addVoucherBtn.click();
                    }
                });
            }
            
            function editItemNotes(itemIndex) {
                var item = cart[itemIndex];
                if (!item) return;
                
                var modal = document.getElementById('notesModal');
                var notesInput = document.getElementById('notesInput');
                var notesTitle = document.getElementById('notesModalTitle');
                var confirmNotesBtn = document.getElementById('confirmNotesBtn');
                
                if (!modal || !notesInput) return;
                
                // Set title
                if (notesTitle) {
                    notesTitle.textContent = 'Edit Catatan: ' + item.name;
                }
                
                // Set current notes
                notesInput.value = item.notes || '';
                
                // Show modal
                modal.classList.add('open');
                notesInput.focus();
                
                // Handle confirm
                var handleConfirm = function() {
                    var notes = notesInput.value.trim();
                    item.notes = notes;
                    modal.classList.remove('open');
                    updateCart();
                };
                
                // Remove old listeners
                var newConfirmBtn = confirmNotesBtn.cloneNode(true);
                confirmNotesBtn.parentNode.replaceChild(newConfirmBtn, confirmNotesBtn);
                
                newConfirmBtn.addEventListener('click', handleConfirm);
                
                // Enter key support
                notesInput.onkeydown = function(e) {
                    if (e.key === 'Enter' && e.ctrlKey) {
                        handleConfirm();
                    }
                };
            }
            
            // Make functions global for onclick
            window.updateQty = updateQty;
            window.removeFromCart = removeFromCart;
            window.editItemNotes = editItemNotes;
            
            cartToggle.addEventListener('click', function() {
                cartSidebar.classList.toggle('open');
            });
            
            closeCart.addEventListener('click', function() {
                cartSidebar.classList.remove('open');
            });
            
            // Setup event listener untuk tombol konfirmasi menggunakan event delegation
            // Ini akan selalu bekerja bahkan jika elemen belum ada saat script dijalankan
            
            // Redirect setelah checkout berhasil
            <?php if ($successMessage) : ?>
                cart = [];
                updateCart();
                // Tampilkan modal success
                var successModal = document.getElementById('successModal');
                if (successModal) {
                    successModal.classList.add('open');
                }
                // Redirect setelah 2 detik
                setTimeout(function() {
                    window.location.href = 'index.php';
                }, 2000);
            <?php endif; ?>
        })();
        
        // Flag untuk menandai submit dari tombol Ya
        var isConfirmedSubmit = false;
        
        // Handle form submit event untuk checkout (di luar IIFE agar selalu aktif)
        document.addEventListener('submit', function(e) {
            if (e.target && e.target.id === 'checkoutForm') {
                // Jika sudah dikonfirmasi, biarkan form submit normal
                if (isConfirmedSubmit) {
                    isConfirmedSubmit = false; // Reset flag
                    return true; // Biarkan submit berjalan
                }
                
                e.preventDefault();
                e.stopPropagation();
                
                // Ambil cart dari scope global atau dari form
                var cartItemsInput = document.getElementById('cartItemsInput');
                var cart = [];
                if (cartItemsInput && cartItemsInput.value) {
                    try {
                        cart = JSON.parse(cartItemsInput.value);
                    } catch (err) {
                        cart = [];
                    }
                }
                
                // Validasi: pastikan ada item di keranjang
                if (!cart || cart.length === 0) {
                    alert('Keranjang kosong. Silakan tambahkan produk terlebih dahulu.');
                    return false;
                }
                
                // Validasi: pastikan ada voucher yang dipilih
                var selectedVouchers = Array.from(document.querySelectorAll('input[name="voucher_ids[]"]:checked'));
                if (selectedVouchers.length === 0) {
                    alert('Pilih minimal satu voucher.');
                    return false;
                }
                
                // Tampilkan modal konfirmasi
                var confirmModal = document.getElementById('confirmModal');
                if (confirmModal) {
                    confirmModal.classList.add('open');
                }
                
                return false;
            }
        });
        
        // Handle tombol konfirmasi modal menggunakan event delegation (di luar IIFE)
        // Menggunakan capture phase untuk memastikan event terpanggil lebih awal
        document.addEventListener('click', function(e) {
            var target = e.target;
            
            // Handle tombol Ya
            if (target && (target.id === 'confirmYesBtn' || target.closest('#confirmYesBtn'))) {
                e.preventDefault();
                e.stopPropagation();
                e.stopImmediatePropagation();
                
                var confirmModal = document.getElementById('confirmModal');
                var checkoutForm = document.getElementById('checkoutForm');
                
                if (confirmModal) {
                    confirmModal.classList.remove('open');
                }
                
                // Submit form langsung (submit() tidak memicu submit event di browser modern)
                if (checkoutForm) {
                    // Langsung submit form tanpa memicu submit event
                    checkoutForm.submit();
                }
                
                return false;
            }
            
            // Handle tombol Batal
            if (target && (target.id === 'confirmNoBtn' || target.closest('#confirmNoBtn'))) {
                e.preventDefault();
                e.stopPropagation();
                e.stopImmediatePropagation();
                
                var confirmModal = document.getElementById('confirmModal');
                
                if (confirmModal) {
                    confirmModal.classList.remove('open');
                }
                
                return false;
            }
            
            // Close modal jika klik di overlay (tapi bukan di modal content)
            var confirmModal = document.getElementById('confirmModal');
            if (confirmModal && confirmModal.classList.contains('open')) {
                if (target === confirmModal) {
                    confirmModal.classList.remove('open');
                }
            }
        }, true); // Gunakan capture phase
    </script>
    
    <!-- Modal Pilih Varian -->
    <div class="modal-overlay" id="variantModal">
        <div class="modal">
            <h3 id="variantModalTitle">Pilih Varian</h3>
            <div class="variant-selection" id="variantList">
                <!-- Variants will be populated here -->
            </div>
            <div class="modal-actions">
                <button type="button" class="btn btn-secondary" onclick="document.getElementById('variantModal').classList.remove('open')">Batal</button>
                <button type="button" class="btn btn-primary" id="confirmVariantBtn">Pilih</button>
            </div>
        </div>
    </div>
    
    <!-- Modal Input Notes -->
    <div class="modal-overlay" id="notesModal">
        <div class="modal">
            <h3 id="notesModalTitle">Tambah Catatan</h3>
            <p style="color: var(--muted); font-size: 0.9rem; margin-bottom: 1rem;">Tambahkan catatan untuk item ini (opsional)</p>
            <textarea 
                id="notesInput" 
                placeholder="Contoh: Warna merah, ukuran besar, tanpa gula, dll..."
                style="width: 100%; min-height: 100px; padding: 0.75rem; border: 1px solid var(--border); border-radius: 0.5rem; font-family: inherit; font-size: 0.95rem; resize: vertical;"
            ></textarea>
            <div style="margin-top: 0.5rem; font-size: 0.8rem; color: var(--muted);">
                Tekan Ctrl+Enter untuk menyimpan
            </div>
            <div class="modal-actions" style="margin-top: 1.5rem;">
                <button type="button" class="btn btn-secondary" onclick="document.getElementById('notesModal').classList.remove('open')">Lewati</button>
                <button type="button" class="btn btn-primary" id="confirmNotesBtn">Simpan</button>
            </div>
        </div>
    </div>
    
    <!-- Modal Konfirmasi -->
    <div class="modal-overlay" id="confirmModal">
        <div class="modal">
            <h3>Konfirmasi Transaksi</h3>
            <p>Apakah Anda yakin akan melakukan transaksi? Redeem hanya bisa dilakukan sekali.</p>
            <div class="modal-actions">
                <button type="button" class="btn btn-secondary" id="confirmNoBtn">Batal</button>
                <button type="button" class="btn btn-primary" id="confirmYesBtn">Ya</button>
            </div>
        </div>
    </div>
    
    <!-- Modal Success -->
    <?php if ($successMessage) : ?>
    <div class="modal-overlay open" id="successModal">
        <div class="modal">
            <h3>✅ Transaksi Berhasil!</h3>
            <p><?= htmlspecialchars($successMessage) ?></p>
            <p style="font-size: 0.875rem; color: var(--muted);">Anda akan diarahkan ke halaman utama...</p>
        </div>
    </div>
    <?php endif; ?>
    
    <!-- Image Preview Modal -->
    <div class="image-preview-overlay" id="imagePreviewOverlay">
        <div class="image-preview-container" onclick="event.stopPropagation();">
            <button type="button" class="image-preview-close" id="imagePreviewClose">×</button>
            <img id="imagePreviewImg" src="" alt="" style="display: block;">
            <div class="image-preview-title" id="imagePreviewTitle"></div>
        </div>
    </div>
    
    <script>
        // Handle image preview modal close
        var imagePreviewOverlay = document.getElementById('imagePreviewOverlay');
        var imagePreviewClose = document.getElementById('imagePreviewClose');
        
        // Close saat klik tombol close
        if (imagePreviewClose) {
            imagePreviewClose.addEventListener('click', function(e) {
                e.stopPropagation();
                if (imagePreviewOverlay) {
                    imagePreviewOverlay.classList.remove('open');
                }
            });
        }
        
        // Close saat klik overlay
        if (imagePreviewOverlay) {
            imagePreviewOverlay.addEventListener('click', function(e) {
                if (e.target === imagePreviewOverlay) {
                    imagePreviewOverlay.classList.remove('open');
                }
            });
        }
        
        // Close saat tekan ESC
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                if (imagePreviewOverlay && imagePreviewOverlay.classList.contains('open')) {
                    imagePreviewOverlay.classList.remove('open');
                }
                var variantModal = document.getElementById('variantModal');
                if (variantModal && variantModal.classList.contains('open')) {
                    variantModal.classList.remove('open');
                }
                var notesModal = document.getElementById('notesModal');
                if (notesModal && notesModal.classList.contains('open')) {
                    notesModal.classList.remove('open');
                }
            }
        });
        
        // Close notes modal saat klik overlay
        var notesModal = document.getElementById('notesModal');
        if (notesModal) {
            notesModal.addEventListener('click', function(e) {
                if (e.target === notesModal) {
                    notesModal.classList.remove('open');
                }
            });
        }
        
        // Close variant modal saat klik overlay
        var variantModal = document.getElementById('variantModal');
        if (variantModal) {
            variantModal.addEventListener('click', function(e) {
                if (e.target === variantModal) {
                    variantModal.classList.remove('open');
                }
            });
        }
    </script>
    
    <a href="index.php" class="fab" id="fabButton" title="Kembali ke Dashboard">🏠</a>
</body>
</html>


