<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';

// Start session untuk flash messages
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Ambil flash messages dari session
$errors = isset($_SESSION['editproduct_errors']) ? $_SESSION['editproduct_errors'] : [];
$successMessage = isset($_SESSION['editproduct_success']) ? $_SESSION['editproduct_success'] : null;
// Clear flash messages setelah diambil
unset($_SESSION['editproduct_errors'], $_SESSION['editproduct_success']);

$products = [];
$variantsMap = [];

// Handle batch update produk dan variant
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['batch_update_products'])) {
    $productsData = isset($_POST['products']) && is_array($_POST['products']) ? $_POST['products'] : [];
    $variantsData = isset($_POST['variants']) && is_array($_POST['variants']) ? $_POST['variants'] : [];
    $newVariantsData = isset($_POST['new_variants']) && is_array($_POST['new_variants']) ? $_POST['new_variants'] : [];
    $updatedProductCount = 0;
    $updatedVariantCount = 0;
    $insertedVariantCount = 0;
    $errorProductCount = 0;
    $errorVariantCount = 0;
    $errorNewVariantCount = 0;
    
    if (empty($productsData) && empty($variantsData) && empty($newVariantsData)) {
        $errors[] = 'Tidak ada data yang diupdate.';
    } else {
        try {
            $pdo = getDbConnection();
            $pdo->beginTransaction();
            
            // Update products
            if (!empty($productsData)) {
                $updateProductStmt = $pdo->prepare('UPDATE products SET name = :name, price = :price, kode_product = :code, is_active = :status, qty = :qty, gambar = :gambar WHERE id = :id');
                $updateProductWithoutImageStmt = $pdo->prepare('UPDATE products SET name = :name, price = :price, kode_product = :code, is_active = :status, qty = :qty WHERE id = :id');
                $checkCodeStmt = $pdo->prepare('SELECT id FROM products WHERE kode_product = :code AND id != :id LIMIT 1');
                
                foreach ($productsData as $productData) {
                    $productId = isset($productData['id']) ? (int) $productData['id'] : 0;
                    $name = isset($productData['name']) ? trim($productData['name']) : '';
                    $price = isset($productData['price']) ? trim($productData['price']) : '';
                    $code = isset($productData['code']) ? trim($productData['code']) : '';
                    $qty = isset($productData['qty']) && $productData['qty'] !== '' ? (int) $productData['qty'] : null;
                    $status = isset($productData['is_active']) ? (int) $productData['is_active'] : 1;
                    $imageFilename = isset($productData['image_filename']) ? trim($productData['image_filename']) : '';
                    
                    if ($productId <= 0) {
                        $errorProductCount++;
                        continue;
                    }
                    
                    if ($name === '') {
                        $errorProductCount++;
                        continue;
                    }
                    
                    if ($price === '' || !ctype_digit($price) || (int) $price <= 0) {
                        $errorProductCount++;
                        continue;
                    }
                    
                    // Cek apakah kode sudah digunakan oleh produk lain
                    if ($code !== '') {
                        $checkCodeStmt->execute([':code' => $code, ':id' => $productId]);
                        if ($checkCodeStmt->fetch()) {
                            $errorProductCount++;
                            continue;
                        }
                    }
                    
                    // Handle gambar: jika ada nama file, gabungkan dengan path
                    // Jika kosong, tidak update field gambar (biarkan seperti semula)
                    if ($imageFilename !== '') {
                        // Sanitize filename
                        $imageFilename = preg_replace('/[^a-zA-Z0-9._-]/', '', $imageFilename);
                        if ($imageFilename !== '') {
                            $gambarPath = 'uploads/products/' . $imageFilename;
                            $updateProductStmt->execute([
                                ':name' => $name,
                                ':price' => (int) $price,
                                ':code' => $code ?: null,
                                ':status' => $status,
                                ':qty' => $qty,
                                ':gambar' => $gambarPath,
                                ':id' => $productId,
                            ]);
                        } else {
                            // Jika setelah sanitize kosong, tidak update gambar
                            $updateProductWithoutImageStmt->execute([
                                ':name' => $name,
                                ':price' => (int) $price,
                                ':code' => $code ?: null,
                                ':status' => $status,
                                ':qty' => $qty,
                                ':id' => $productId,
                            ]);
                        }
                    } else {
                        // Jika field kosong, tidak update gambar (biarkan path lama)
                        $updateProductWithoutImageStmt->execute([
                            ':name' => $name,
                            ':price' => (int) $price,
                            ':code' => $code ?: null,
                            ':status' => $status,
                            ':qty' => $qty,
                            ':id' => $productId,
                        ]);
                    }
                    
                    $updatedProductCount++;
                }
            }
            
            // Update variants
            if (!empty($variantsData)) {
                $updateVariantStmt = $pdo->prepare('UPDATE product_variants SET variant_name = :name, price = :price, sku = :sku, stock = :stock, is_active = :status WHERE id = :id');
                
                foreach ($variantsData as $variantData) {
                    $variantId = isset($variantData['id']) ? (int) $variantData['id'] : 0;
                    $variantName = isset($variantData['name']) ? trim($variantData['name']) : '';
                    $variantPrice = isset($variantData['price']) && $variantData['price'] !== '' ? trim($variantData['price']) : null;
                    $variantSku = isset($variantData['sku']) ? trim($variantData['sku']) : null;
                    $variantStock = isset($variantData['stock']) && $variantData['stock'] !== '' ? trim($variantData['stock']) : null;
                    $variantStatus = isset($variantData['is_active']) ? (int) $variantData['is_active'] : 1;
                    
                    if ($variantId <= 0 || $variantName === '') {
                        $errorVariantCount++;
                        continue;
                    }
                    
                    $variantPriceInt = null;
                    if ($variantPrice !== null && $variantPrice !== '') {
                        $variantPriceClean = preg_replace('/[^\d]/', '', $variantPrice);
                        $variantPriceInt = $variantPriceClean !== '' ? (int) $variantPriceClean : null;
                    }
                    
                    $variantStockInt = null;
                    if ($variantStock !== null && $variantStock !== '') {
                        $variantStockClean = preg_replace('/[^\d]/', '', $variantStock);
                        $variantStockInt = $variantStockClean !== '' ? (int) $variantStockClean : null;
                    }
                    
                    $updateVariantStmt->execute([
                        ':name' => $variantName,
                        ':price' => $variantPriceInt,
                        ':sku' => $variantSku ?: null,
                        ':stock' => $variantStockInt,
                        ':status' => $variantStatus,
                        ':id' => $variantId,
                    ]);
                    
                    $updatedVariantCount++;
                }
            }
            
            // Insert new variants
            if (!empty($newVariantsData)) {
                $insertVariantStmt = $pdo->prepare('INSERT INTO product_variants (product_id, variant_name, price, sku, stock, is_active, created_at) VALUES (:product_id, :name, :price, :sku, :stock, :status, NOW())');
                
                foreach ($newVariantsData as $newVariantData) {
                    $productId = isset($newVariantData['product_id']) ? (int) $newVariantData['product_id'] : 0;
                    $variantName = isset($newVariantData['name']) ? trim($newVariantData['name']) : '';
                    $variantPrice = isset($newVariantData['price']) && $newVariantData['price'] !== '' ? trim($newVariantData['price']) : null;
                    $variantSku = isset($newVariantData['sku']) ? trim($newVariantData['sku']) : null;
                    $variantStock = isset($newVariantData['stock']) && $newVariantData['stock'] !== '' ? trim($newVariantData['stock']) : null;
                    $variantStatus = isset($newVariantData['is_active']) ? (int) $newVariantData['is_active'] : 1;
                    
                    if ($productId <= 0 || $variantName === '') {
                        $errorNewVariantCount++;
                        continue;
                    }
                    
                    $variantPriceInt = null;
                    if ($variantPrice !== null && $variantPrice !== '') {
                        $variantPriceClean = preg_replace('/[^\d]/', '', $variantPrice);
                        $variantPriceInt = $variantPriceClean !== '' ? (int) $variantPriceClean : null;
                    }
                    
                    $variantStockInt = null;
                    if ($variantStock !== null && $variantStock !== '') {
                        $variantStockClean = preg_replace('/[^\d]/', '', $variantStock);
                        $variantStockInt = $variantStockClean !== '' ? (int) $variantStockClean : null;
                    }
                    
                    $insertVariantStmt->execute([
                        ':product_id' => $productId,
                        ':name' => $variantName,
                        ':price' => $variantPriceInt,
                        ':sku' => $variantSku ?: null,
                        ':stock' => $variantStockInt,
                        ':status' => $variantStatus,
                    ]);
                    
                    $insertedVariantCount++;
                }
            }
            
            $pdo->commit();
            
            // Build success message
            $messages = [];
            if ($updatedProductCount > 0) {
                $messages[] = sprintf('%d produk berhasil diperbarui', $updatedProductCount);
            }
            if ($updatedVariantCount > 0) {
                $messages[] = sprintf('%d variant berhasil diperbarui', $updatedVariantCount);
            }
            if ($insertedVariantCount > 0) {
                $messages[] = sprintf('%d variant baru berhasil ditambahkan', $insertedVariantCount);
            }
            if (!empty($messages)) {
                $successMessage = implode(', ', $messages) . '.';
                if ($errorProductCount > 0 || $errorVariantCount > 0 || $errorNewVariantCount > 0) {
                    $errorMessages = [];
                    if ($errorProductCount > 0) {
                        $errorMessages[] = sprintf('%d produk gagal', $errorProductCount);
                    }
                    if ($errorVariantCount > 0) {
                        $errorMessages[] = sprintf('%d variant gagal', $errorVariantCount);
                    }
                    if ($errorNewVariantCount > 0) {
                        $errorMessages[] = sprintf('%d variant baru gagal', $errorNewVariantCount);
                    }
                    $successMessage .= ' ' . implode(', ', $errorMessages) . '.';
                }
            } else {
                $errors[] = 'Tidak ada data yang berhasil diperbarui.';
            }
            
            // Redirect untuk menghindari form resubmission
            $_SESSION['editproduct_success'] = $successMessage;
            if (!empty($errors)) {
                $_SESSION['editproduct_errors'] = $errors;
            }
            header('Location: ' . $_SERVER['PHP_SELF']);
            exit;
        } catch (PDOException $exception) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $errors[] = 'Gagal memperbarui data: ' . $exception->getMessage();
            $_SESSION['editproduct_errors'] = $errors;
            header('Location: ' . $_SERVER['PHP_SELF']);
            exit;
        }
    }
}

// Handle update produk (single - untuk backward compatibility)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_product'])) {
    $productId = isset($_POST['product_id']) ? (int) $_POST['product_id'] : 0;
    $name = isset($_POST['name']) ? trim($_POST['name']) : '';
    $price = isset($_POST['price']) ? trim($_POST['price']) : '';
    $code = isset($_POST['code']) ? trim($_POST['code']) : '';
    $qty = isset($_POST['qty']) && $_POST['qty'] !== '' ? (int) $_POST['qty'] : null;
    $status = isset($_POST['is_active']) ? (int) $_POST['is_active'] : 1;
    
    if ($productId <= 0) {
        $errors[] = 'ID produk tidak valid.';
    } elseif ($name === '') {
        $errors[] = 'Nama produk wajib diisi.';
    } elseif ($price === '' || !ctype_digit($price) || (int) $price <= 0) {
        $errors[] = 'Harga harus berupa angka positif.';
    } else {
        try {
            $pdo = getDbConnection();
            
            // Cek apakah kode sudah digunakan oleh produk lain
            if ($code !== '') {
                $checkStmt = $pdo->prepare('SELECT id FROM products WHERE kode_product = :code AND id != :id LIMIT 1');
                $checkStmt->execute([':code' => $code, ':id' => $productId]);
                if ($checkStmt->fetch()) {
                    $errors[] = 'Kode produk sudah digunakan oleh produk lain.';
                }
            }
            
            if (empty($errors)) {
                $updateStmt = $pdo->prepare('UPDATE products SET name = :name, price = :price, kode_product = :code, is_active = :status, qty = :qty WHERE id = :id');
                $updateStmt->execute([
                    ':name' => $name,
                    ':price' => (int) $price,
                    ':code' => $code ?: null,
                    ':status' => $status,
                    ':qty' => $qty,
                    ':id' => $productId,
                ]);
                
                $_SESSION['editproduct_success'] = 'Produk berhasil diperbarui!';
                header('Location: ' . $_SERVER['PHP_SELF']);
                exit;
            } else {
                $_SESSION['editproduct_errors'] = $errors;
                header('Location: ' . $_SERVER['PHP_SELF']);
                exit;
            }
        } catch (PDOException $exception) {
            $errors[] = 'Gagal memperbarui produk: ' . $exception->getMessage();
            $_SESSION['editproduct_errors'] = $errors;
            header('Location: ' . $_SERVER['PHP_SELF']);
            exit;
        }
    }
}

// Handle batch update variant
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['batch_update_variants'])) {
    $variantsData = isset($_POST['variants']) && is_array($_POST['variants']) ? $_POST['variants'] : [];
    $updatedCount = 0;
    $errorCount = 0;
    
    if (!empty($variantsData)) {
        try {
            $pdo = getDbConnection();
            $pdo->beginTransaction();
            
            $updateStmt = $pdo->prepare('UPDATE product_variants SET variant_name = :name, price = :price, sku = :sku, stock = :stock, is_active = :status WHERE id = :id');
            
            foreach ($variantsData as $variantData) {
                $variantId = isset($variantData['id']) ? (int) $variantData['id'] : 0;
                $variantName = isset($variantData['name']) ? trim($variantData['name']) : '';
                $variantPrice = isset($variantData['price']) && $variantData['price'] !== '' ? trim($variantData['price']) : null;
                $variantSku = isset($variantData['sku']) ? trim($variantData['sku']) : null;
                $variantStock = isset($variantData['stock']) && $variantData['stock'] !== '' ? trim($variantData['stock']) : null;
                $variantStatus = isset($variantData['is_active']) ? (int) $variantData['is_active'] : 1;
                
                if ($variantId <= 0 || $variantName === '') {
                    $errorCount++;
                    continue;
                }
                
                $variantPriceInt = null;
                if ($variantPrice !== null && $variantPrice !== '') {
                    $variantPriceClean = preg_replace('/[^\d]/', '', $variantPrice);
                    $variantPriceInt = $variantPriceClean !== '' ? (int) $variantPriceClean : null;
                }
                
                $variantStockInt = null;
                if ($variantStock !== null && $variantStock !== '') {
                    $variantStockClean = preg_replace('/[^\d]/', '', $variantStock);
                    $variantStockInt = $variantStockClean !== '' ? (int) $variantStockClean : null;
                }
                
                $updateStmt->execute([
                    ':name' => $variantName,
                    ':price' => $variantPriceInt,
                    ':sku' => $variantSku ?: null,
                    ':stock' => $variantStockInt,
                    ':status' => $variantStatus,
                    ':id' => $variantId,
                ]);
                
                $updatedCount++;
            }
            
            $pdo->commit();
            
            if ($updatedCount > 0) {
                if ($successMessage === null) {
                    $successMessage = '';
                }
                $successMessage .= sprintf('%s%d variant berhasil diperbarui.', $successMessage !== '' ? ' ' : '', $updatedCount);
                if ($errorCount > 0) {
                    $successMessage .= sprintf(' %d variant gagal diperbarui.', $errorCount);
                }
            }
        } catch (PDOException $exception) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $errors[] = 'Gagal memperbarui variant: ' . $exception->getMessage();
        }
    }
}

// Handle update variant (single - untuk backward compatibility)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_variant'])) {
    $variantId = isset($_POST['variant_id']) ? (int) $_POST['variant_id'] : 0;
    $variantName = isset($_POST['variant_name']) ? trim($_POST['variant_name']) : '';
    $variantPrice = isset($_POST['variant_price']) && $_POST['variant_price'] !== '' ? trim($_POST['variant_price']) : null;
    $variantSku = isset($_POST['variant_sku']) ? trim($_POST['variant_sku']) : null;
    $variantStock = isset($_POST['variant_stock']) && $_POST['variant_stock'] !== '' ? trim($_POST['variant_stock']) : null;
    $variantStatus = isset($_POST['variant_is_active']) ? (int) $_POST['variant_is_active'] : 1;
    
    if ($variantId <= 0) {
        $errors[] = 'ID variant tidak valid.';
    } elseif ($variantName === '') {
        $errors[] = 'Nama variant wajib diisi.';
    } else {
        try {
            $pdo = getDbConnection();
            
            $variantPriceInt = null;
            if ($variantPrice !== null && $variantPrice !== '') {
                $variantPriceClean = preg_replace('/[^\d]/', '', $variantPrice);
                $variantPriceInt = $variantPriceClean !== '' ? (int) $variantPriceClean : null;
            }
            
            $variantStockInt = null;
            if ($variantStock !== null && $variantStock !== '') {
                $variantStockClean = preg_replace('/[^\d]/', '', $variantStock);
                $variantStockInt = $variantStockClean !== '' ? (int) $variantStockClean : null;
            }
            
            $updateStmt = $pdo->prepare('UPDATE product_variants SET variant_name = :name, price = :price, sku = :sku, stock = :stock, is_active = :status WHERE id = :id');
            $updateStmt->execute([
                ':name' => $variantName,
                ':price' => $variantPriceInt,
                ':sku' => $variantSku ?: null,
                ':stock' => $variantStockInt,
                ':status' => $variantStatus,
                ':id' => $variantId,
            ]);
            
            $_SESSION['editproduct_success'] = 'Variant berhasil diperbarui!';
            header('Location: ' . $_SERVER['PHP_SELF']);
            exit;
        } catch (PDOException $exception) {
            $errors[] = 'Gagal memperbarui variant: ' . $exception->getMessage();
            $_SESSION['editproduct_errors'] = $errors;
            header('Location: ' . $_SERVER['PHP_SELF']);
            exit;
        }
    }
}

// Handle delete produk
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_product'])) {
    $productId = isset($_POST['product_id']) ? (int) $_POST['product_id'] : 0;
    
    if ($productId <= 0) {
        $errors[] = 'ID produk tidak valid.';
    } else {
        try {
            $pdo = getDbConnection();
            $pdo->beginTransaction();
            
            // Hapus variants terlebih dahulu
            $deleteVariantsStmt = $pdo->prepare('DELETE FROM product_variants WHERE product_id = :id');
            $deleteVariantsStmt->execute([':id' => $productId]);
            
            // Hapus produk
            $deleteStmt = $pdo->prepare('DELETE FROM products WHERE id = :id');
            $deleteStmt->execute([':id' => $productId]);
            
            $pdo->commit();
            $_SESSION['editproduct_success'] = 'Produk berhasil dihapus!';
            header('Location: ' . $_SERVER['PHP_SELF']);
            exit;
        } catch (PDOException $exception) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $errors[] = 'Gagal menghapus produk: ' . $exception->getMessage();
            $_SESSION['editproduct_errors'] = $errors;
            header('Location: ' . $_SERVER['PHP_SELF']);
            exit;
        }
    }
}

// Handle delete variant
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_variant'])) {
    $variantId = isset($_POST['variant_id']) ? (int) $_POST['variant_id'] : 0;
    
    if ($variantId <= 0) {
        $errors[] = 'ID variant tidak valid.';
    } else {
        try {
            $pdo = getDbConnection();
            $deleteStmt = $pdo->prepare('DELETE FROM product_variants WHERE id = :id');
            $deleteStmt->execute([':id' => $variantId]);
            
            $_SESSION['editproduct_success'] = 'Variant berhasil dihapus!';
            header('Location: ' . $_SERVER['PHP_SELF']);
            exit;
        } catch (PDOException $exception) {
            $errors[] = 'Gagal menghapus variant: ' . $exception->getMessage();
            $_SESSION['editproduct_errors'] = $errors;
            header('Location: ' . $_SERVER['PHP_SELF']);
            exit;
        }
    }
}

// Ambil semua produk
try {
    $pdo = getDbConnection();
    $productStmt = $pdo->query('SELECT id, name, price, kode_product, is_active, gambar, qty FROM products ORDER BY name ASC');
    $products = $productStmt->fetchAll();
    
    // Ambil semua variants
    if (!empty($products)) {
        $productIds = array_map(function($p) { return (int) $p['id']; }, $products);
        $placeholders = implode(',', array_fill(0, count($productIds), '?'));
        $variantStmt = $pdo->prepare("SELECT id, product_id, variant_name, price, sku, stock, is_active FROM product_variants WHERE product_id IN ($placeholders) ORDER BY product_id, variant_name ASC");
        $variantStmt->execute($productIds);
        $variants = $variantStmt->fetchAll();
        
        foreach ($variants as $variant) {
            $productId = (int) $variant['product_id'];
            if (!isset($variantsMap[$productId])) {
                $variantsMap[$productId] = [];
            }
            $variantsMap[$productId][] = $variant;
        }
    }
} catch (PDOException $exception) {
    $errors[] = 'Gagal memuat data: ' . $exception->getMessage();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Edit Produk</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <style>
        .edit-products-page {
            max-width: 1600px;
            margin: 0 auto;
            padding: 2rem;
        }
        
        .products-table {
            width: 100%;
            border-collapse: collapse;
            background: #fff;
            border-radius: 1rem;
            overflow: hidden;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }
        
        .products-table thead {
            background: #f8fafc;
        }
        
        .products-table th {
            padding: 1rem;
            text-align: left;
            font-weight: 600;
            color: var(--text);
            border-bottom: 2px solid var(--border);
        }
        
        .products-table td {
            padding: 1rem;
            border-bottom: 1px solid var(--border);
            vertical-align: top;
        }
        
        .products-table tbody tr:hover {
            background: #f8fafc;
        }
        
        .products-table tbody tr:last-child td {
            border-bottom: none;
        }
        
        .product-row {
            background: #fff;
        }
        
        .variant-row {
            background: #f8fafc;
        }
        
        .variant-row td {
            padding-left: 3rem;
            font-size: 0.9rem;
        }
        
        .edit-input {
            width: 100%;
            padding: 0.5rem;
            border: 1px solid var(--border);
            border-radius: 0.5rem;
            font-size: 0.9rem;
        }
        
        .edit-input:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
        }
        
        .edit-select {
            width: 100%;
            padding: 0.5rem;
            border: 1px solid var(--border);
            border-radius: 0.5rem;
            font-size: 0.9rem;
        }
        
        .btn-small {
            padding: 0.4rem 0.8rem;
            font-size: 0.85rem;
            border-radius: 0.5rem;
        }
        
        .btn-danger {
            background: var(--danger);
            color: #fff;
        }
        
        .btn-danger:hover {
            background: #b91c1c;
        }
        
        .variant-toggle {
            cursor: pointer;
            color: var(--primary);
            font-weight: 600;
            user-select: none;
            display: inline-block;
            padding: 0.25rem 0.5rem;
            background: #e0e7ff;
            border-radius: 0.375rem;
        }
        
        .variant-toggle:hover {
            background: #c7d2fe;
        }
        
        .variants-container {
            display: none;
            margin-top: 0.5rem;
            padding: 1rem;
            background: #fff;
            border: 1px solid var(--border);
            border-radius: 0.5rem;
        }
        
        .variants-container.show {
            display: block;
        }
        
        .variant-badge {
            display: inline-block;
            padding: 0.25rem 0.5rem;
            background: #e0e7ff;
            color: #3730a3;
            border-radius: 0.375rem;
            font-size: 0.8rem;
            font-weight: 500;
            margin-right: 0.25rem;
            margin-bottom: 0.25rem;
        }
        
        .product-image-small {
            width: 50px;
            height: 50px;
            object-fit: cover;
            border-radius: 0.5rem;
            background: #f1f5f9;
        }
        
        .status-active {
            color: var(--success);
            font-weight: 600;
        }
        
        .status-inactive {
            color: var(--danger);
            font-weight: 600;
        }
    </style>
</head>
<body>
    <div class="edit-products-page">
        <header class="hero hero-compact">
            <div>
                <p class="eyebrow">Product Management</p>
                <h1>Edit Produk</h1>
                <p class="subtitle">Kelola semua produk dan variant dalam satu halaman. Edit langsung di tabel ini.</p>
            </div>
            <div class="hero-card">
                <p>Total Produk</p>
                <strong><?= count($products) ?></strong>
            </div>
        </header>

        <?php if (!empty($errors)) : ?>
            <?php foreach ($errors as $error) : ?>
                <div class="feedback error"><?= htmlspecialchars($error) ?></div>
            <?php endforeach; ?>
        <?php endif; ?>

        <?php if ($successMessage !== null) : ?>
            <div class="feedback success"><?= htmlspecialchars($successMessage) ?></div>
        <?php endif; ?>

        <section class="form-card" style="margin-top: 2rem;">
            <form method="post" id="batchEditForm">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; padding-bottom: 1rem; border-bottom: 2px solid var(--border);">
                    <div>
                        <h2 style="margin: 0; font-size: 1.5rem;">Daftar Produk</h2>
                        <p style="margin: 0.5rem 0 0; color: var(--muted); font-size: 0.9rem;">Edit beberapa produk sekaligus, lalu klik "Simpan Semua" di bawah.</p>
                    </div>
                    <button type="submit" name="batch_update_products" class="btn btn-primary" style="font-size: 1rem; padding: 0.75rem 1.5rem;">
                        💾 Simpan Semua Perubahan
                    </button>
                </div>
            <div class="table-wrapper">
                <table class="products-table">
                    <thead>
                        <tr>
                            <th style="width: 50px;">No</th>
                            <th style="width: 50px;">ID</th>
                            <th style="width: 80px;">Gambar</th>
                            <th style="width: 200px;">Nama Produk</th>
                            <th style="width: 120px;">Harga</th>
                            <th style="width: 120px;">Kode</th>
                            <th style="width: 100px;">Stok</th>
                            <th style="width: 100px;">Status</th>
                            <th style="width: 150px;">Nama File Gambar</th>
                            <th style="width: 150px;">Variant</th>
                            <th style="width: 150px;">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $no = 1;
                        foreach ($products as $product) : ?>
                            <?php
                            $productId = (int) $product['id'];
                            $hasVariants = isset($variantsMap[$productId]) && !empty($variantsMap[$productId]);
                            ?>
                            <tr class="product-row" data-product-id="<?= $productId ?>">
                                <td style="text-align: center; font-weight: 600; color: var(--muted);"><?= $no++ ?></td>
                                <td><?= $productId ?></td>
                                <td>
                                    <?php if ($product['gambar']) : ?>
                                        <img src="<?= htmlspecialchars($product['gambar']) ?>" alt="" class="product-image-small">
                                    <?php else : ?>
                                        <div class="product-image-small" style="display: flex; align-items: center; justify-content: center; color: var(--muted);">📦</div>
                                    <?php endif; ?>
                                </td>
                                <td>
                                        <input type="hidden" name="products[<?= $productId ?>][id]" value="<?= $productId ?>">
                                        <input type="text" name="products[<?= $productId ?>][name]" value="<?= htmlspecialchars($product['name']) ?>" class="edit-input" required>
                                </td>
                                <td>
                                        <input type="number" name="products[<?= $productId ?>][price]" value="<?= (int) $product['price'] ?>" class="edit-input" min="1" required>
                                </td>
                                <td>
                                        <input type="text" name="products[<?= $productId ?>][code]" value="<?= htmlspecialchars($product['kode_product'] ?? '') ?>" class="edit-input">
                                </td>
                                <td>
                                        <input type="number" name="products[<?= $productId ?>][qty]" value="<?= $product['qty'] !== null ? (int) $product['qty'] : '' ?>" class="edit-input" min="0" placeholder="Unlimited">
                                </td>
                                <td>
                                        <select name="products[<?= $productId ?>][is_active]" class="edit-select">
                                            <option value="1" <?= (int) $product['is_active'] === 1 ? 'selected' : '' ?>>Aktif</option>
                                            <option value="0" <?= (int) $product['is_active'] === 0 ? 'selected' : '' ?>>Nonaktif</option>
                                        </select>
                                </td>
                                <td>
                                    <?php
                                    // Extract filename from path
                                    $imageFilename = '';
                                    if (!empty($product['gambar'])) {
                                        // Jika path adalah uploads/products/namafile.jpg, ambil namafile.jpg
                                        if (strpos($product['gambar'], 'uploads/products/') === 0) {
                                            $imageFilename = substr($product['gambar'], strlen('uploads/products/'));
                                        } else {
                                            // Jika format berbeda, ambil basename saja
                                            $imageFilename = basename($product['gambar']);
                                        }
                                    }
                                    ?>
                                    <div style="display: flex; align-items: center; gap: 0.5rem;">
                                        <span style="color: var(--muted); font-size: 0.85rem; white-space: nowrap;">uploads/products/</span>
                                        <input type="text" name="products[<?= $productId ?>][image_filename]" value="<?= htmlspecialchars($imageFilename) ?>" class="edit-input" placeholder="namafile.jpg" style="flex: 1; min-width: 120px;">
                                    </div>
                                </td>
                                <td>
                                    <span class="variant-toggle" onclick="toggleVariants(<?= $productId ?>)">
                                        <?php if ($hasVariants) : ?>
                                            <?= count($variantsMap[$productId]) ?> variant
                                        <?php else : ?>
                                            Tambah variant
                                        <?php endif; ?>
                                        <span id="arrow_<?= $productId ?>"><?= $hasVariants ? '▼' : '▶' ?></span>
                                    </span>
                                </td>
                                <td>
                                    <button type="button" onclick="deleteProduct(<?= $productId ?>)" class="btn btn-danger btn-small">Hapus</button>
                                </td>
                            </tr>
                            
                            <tr class="variant-row">
                                <td colspan="11">
                                    <div class="variants-container" id="variants_<?= $productId ?>" style="<?= $hasVariants ? '' : 'display: none;' ?>">
                                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.75rem;">
                                            <h3 style="margin: 0; font-size: 1rem; color: var(--text);">Variant Produk</h3>
                                            <button type="button" onclick="addNewVariant(<?= $productId ?>)" class="btn btn-primary btn-small" style="font-size: 0.85rem;">
                                                ➕ Tambah Variant
                                            </button>
                                        </div>
                                        <table style="width: 100%; border-collapse: collapse;">
                                            <thead>
                                                <tr style="background: #e2e8f0;">
                                                    <th style="padding: 0.5rem; text-align: left; font-size: 0.85rem;">Nama Variant</th>
                                                    <th style="padding: 0.5rem; text-align: left; font-size: 0.85rem;">Harga</th>
                                                    <th style="padding: 0.5rem; text-align: left; font-size: 0.85rem;">SKU</th>
                                                    <th style="padding: 0.5rem; text-align: left; font-size: 0.85rem;">Stok</th>
                                                    <th style="padding: 0.5rem; text-align: left; font-size: 0.85rem;">Status</th>
                                                    <th style="padding: 0.5rem; text-align: left; font-size: 0.85rem;">Aksi</th>
                                                </tr>
                                            </thead>
                                            <tbody id="variants_tbody_<?= $productId ?>">
                                                <?php if ($hasVariants) : ?>
                                                    <?php foreach ($variantsMap[$productId] as $variant) : ?>
                                                        <tr>
                                                            <td style="padding: 0.5rem;">
                                                                    <input type="hidden" name="variants[<?= (int) $variant['id'] ?>][id]" value="<?= (int) $variant['id'] ?>">
                                                                    <input type="text" name="variants[<?= (int) $variant['id'] ?>][name]" value="<?= htmlspecialchars($variant['variant_name']) ?>" class="edit-input" required>
                                                            </td>
                                                            <td style="padding: 0.5rem;">
                                                                    <input type="number" name="variants[<?= (int) $variant['id'] ?>][price]" value="<?= $variant['price'] !== null ? (int) $variant['price'] : '' ?>" class="edit-input" min="0" placeholder="Gunakan harga produk">
                                                            </td>
                                                            <td style="padding: 0.5rem;">
                                                                    <input type="text" name="variants[<?= (int) $variant['id'] ?>][sku]" value="<?= htmlspecialchars($variant['sku'] ?? '') ?>" class="edit-input">
                                                            </td>
                                                            <td style="padding: 0.5rem;">
                                                                    <input type="number" name="variants[<?= (int) $variant['id'] ?>][stock]" value="<?= $variant['stock'] !== null ? (int) $variant['stock'] : '' ?>" class="edit-input" min="0" placeholder="Unlimited">
                                                            </td>
                                                            <td style="padding: 0.5rem;">
                                                                    <select name="variants[<?= (int) $variant['id'] ?>][is_active]" class="edit-select">
                                                                        <option value="1" <?= (int) $variant['is_active'] === 1 ? 'selected' : '' ?>>Aktif</option>
                                                                        <option value="0" <?= (int) $variant['is_active'] === 0 ? 'selected' : '' ?>>Nonaktif</option>
                                                                    </select>
                                                            </td>
                                                            <td style="padding: 0.5rem;">
                                                                    <button type="button" onclick="deleteVariant(<?= (int) $variant['id'] ?>)" class="btn btn-danger btn-small">Hapus</button>
                                                            </td>
                                                        </tr>
                                                    <?php endforeach; ?>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
                <div style="margin-top: 1.5rem; padding-top: 1.5rem; border-top: 2px solid var(--border); display: flex; justify-content: space-between; align-items: center;">
                    <p style="margin: 0; color: var(--muted); font-size: 0.9rem;">Setelah selesai mengedit, klik tombol di bawah untuk menyimpan semua perubahan.</p>
                    <button type="submit" name="batch_update_products" class="btn btn-primary" style="font-size: 1rem; padding: 0.75rem 1.5rem;">
                        💾 Simpan Semua Perubahan
                    </button>
                </div>
            </form>
        </section>
    </div>

    <a href="new_product.php" class="fab" id="fabButton" title="Tambah Produk Baru">➕</a>
    <div class="fab-menu" id="fabMenu">
        <a class="fab-item dashboard" href="index.php" title="Dashboard">🏠</a>
        <a class="fab-item new-guest" href="new_guest.php" title="New Guest">➕</a>
        <a class="fab-item products" href="new_product.php" title="New Product">🛍️</a>
        <a class="fab-item edit-products" href="editproduct.php" title="Edit Products">✏️</a>
    </div>

    <script>
        (function() {
            var fabButton = document.getElementById('fabButton');
            var fabMenu = document.getElementById('fabMenu');

            var toggleMenu = function() {
                if (!fabMenu || !fabButton) {
                    return;
                }
                fabMenu.classList.toggle('open');
                fabButton.classList.toggle('open');
            };

            if (fabButton) {
                fabButton.addEventListener('click', toggleMenu);
            }

            // Toggle variants
            window.toggleVariants = function(productId) {
                var container = document.getElementById('variants_' + productId);
                var arrow = document.getElementById('arrow_' + productId);
                if (container && arrow) {
                    var isShowing = container.style.display !== 'none';
                    if (isShowing) {
                        container.style.display = 'none';
                        arrow.textContent = '▶';
                    } else {
                        container.style.display = 'block';
                        arrow.textContent = '▼';
                    }
                }
            };
            
            // Handle batch form submit - include variants
            var batchForm = document.getElementById('batchEditForm');
            if (batchForm) {
                batchForm.addEventListener('submit', function(e) {
                    // Form akan submit dengan semua data products dan variants
                    // Variants akan di-handle terpisah di backend
                });
            }
            
            // Handle delete product
            window.deleteProduct = function(productId) {
                if (!confirm('Yakin hapus produk ini? Variant juga akan terhapus.')) {
                    return;
                }
                var form = document.createElement('form');
                form.method = 'POST';
                form.style.display = 'none';
                var inputId = document.createElement('input');
                inputId.type = 'hidden';
                inputId.name = 'product_id';
                inputId.value = productId;
                var inputAction = document.createElement('input');
                inputAction.type = 'hidden';
                inputAction.name = 'delete_product';
                inputAction.value = '1';
                form.appendChild(inputId);
                form.appendChild(inputAction);
                document.body.appendChild(form);
                form.submit();
            };
            
            // Handle delete variant
            window.deleteVariant = function(variantId) {
                if (!confirm('Yakin hapus variant ini?')) {
                    return;
                }
                var form = document.createElement('form');
                form.method = 'POST';
                form.style.display = 'none';
                var inputId = document.createElement('input');
                inputId.type = 'hidden';
                inputId.name = 'variant_id';
                inputId.value = variantId;
                var inputAction = document.createElement('input');
                inputAction.type = 'hidden';
                inputAction.name = 'delete_variant';
                inputAction.value = '1';
                form.appendChild(inputId);
                form.appendChild(inputAction);
                document.body.appendChild(form);
                form.submit();
            };
            
            // Handle add new variant
            window.addNewVariant = function(productId) {
                var tbody = document.getElementById('variants_tbody_' + productId);
                var container = document.getElementById('variants_' + productId);
                if (!tbody || !container) {
                    return;
                }
                
                // Show container if hidden
                container.style.display = 'block';
                
                // Generate unique index for new variant
                var newIndex = Date.now();
                
                // Create new row
                var newRow = document.createElement('tr');
                newRow.style.background = '#fef3c7';
                newRow.innerHTML = 
                    '<td style="padding: 0.5rem;">' +
                        '<input type="hidden" name="new_variants[' + newIndex + '][product_id]" value="' + productId + '">' +
                        '<input type="text" name="new_variants[' + newIndex + '][name]" class="edit-input" placeholder="Nama variant" required>' +
                    '</td>' +
                    '<td style="padding: 0.5rem;">' +
                        '<input type="number" name="new_variants[' + newIndex + '][price]" class="edit-input" min="0" placeholder="Gunakan harga produk">' +
                    '</td>' +
                    '<td style="padding: 0.5rem;">' +
                        '<input type="text" name="new_variants[' + newIndex + '][sku]" class="edit-input" placeholder="SKU">' +
                    '</td>' +
                    '<td style="padding: 0.5rem;">' +
                        '<input type="number" name="new_variants[' + newIndex + '][stock]" class="edit-input" min="0" placeholder="Unlimited">' +
                    '</td>' +
                    '<td style="padding: 0.5rem;">' +
                        '<select name="new_variants[' + newIndex + '][is_active]" class="edit-select">' +
                            '<option value="1" selected>Aktif</option>' +
                            '<option value="0">Nonaktif</option>' +
                        '</select>' +
                    '</td>' +
                    '<td style="padding: 0.5rem;">' +
                        '<button type="button" onclick="removeNewVariant(this)" class="btn btn-danger btn-small">Hapus</button>' +
                    '</td>';
                
                tbody.appendChild(newRow);
                
                // Scroll to new row
                newRow.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
            };
            
            // Handle remove new variant row
            window.removeNewVariant = function(button) {
                var row = button.closest('tr');
                if (row) {
                    row.remove();
                }
            };
        })();
    </script>
</body>
</html>

